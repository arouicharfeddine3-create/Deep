import AsyncStorage from '@react-native-async-storage/async-storage';

export interface ProjectFile {
  id: string;
  name: string;
  language: string;
  content: string;
  createdAt: string;
  updatedAt: string;
  sourceMessageId?: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  files: ProjectFile[];
  createdAt: string;
  updatedAt: string;
  color: string;
}

const STORAGE_KEY = 'deepcode_projects';
const PROJECT_COLORS = ['#2f81f7', '#3fb950', '#d29922', '#bc8cff', '#f85149', '#39d353', '#4d6aff'];

const generateId = () => `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

export const projectService = {
  async getAll(): Promise<Project[]> {
    try {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  },

  async save(projects: Project[]): Promise<void> {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
  },

  async create(name: string, description = ''): Promise<Project> {
    const projects = await projectService.getAll();
    const color = PROJECT_COLORS[projects.length % PROJECT_COLORS.length];
    const project: Project = {
      id: generateId(),
      name,
      description,
      files: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      color,
    };
    await projectService.save([project, ...projects]);
    return project;
  },

  async update(project: Project): Promise<void> {
    const projects = await projectService.getAll();
    const idx = projects.findIndex(p => p.id === project.id);
    if (idx !== -1) {
      projects[idx] = { ...project, updatedAt: new Date().toISOString() };
      await projectService.save(projects);
    }
  },

  async delete(id: string): Promise<void> {
    const projects = await projectService.getAll();
    await projectService.save(projects.filter(p => p.id !== id));
  },

  async addFile(projectId: string, file: Omit<ProjectFile, 'id' | 'createdAt' | 'updatedAt'>): Promise<ProjectFile> {
    const projects = await projectService.getAll();
    const project = projects.find(p => p.id === projectId);
    if (!project) throw new Error('Project not found');

    const newFile: ProjectFile = {
      ...file,
      id: generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    project.files.push(newFile);
    project.updatedAt = new Date().toISOString();
    await projectService.save(projects);
    return newFile;
  },

  async updateFile(projectId: string, fileId: string, content: string): Promise<void> {
    const projects = await projectService.getAll();
    const project = projects.find(p => p.id === projectId);
    if (!project) return;
    const file = project.files.find(f => f.id === fileId);
    if (!file) return;
    file.content = content;
    file.updatedAt = new Date().toISOString();
    project.updatedAt = new Date().toISOString();
    await projectService.save(projects);
  },

  async deleteFile(projectId: string, fileId: string): Promise<void> {
    const projects = await projectService.getAll();
    const project = projects.find(p => p.id === projectId);
    if (!project) return;
    project.files = project.files.filter(f => f.id !== fileId);
    project.updatedAt = new Date().toISOString();
    await projectService.save(projects);
  },

  exportProject(project: Project): string {
    return JSON.stringify(project, null, 2);
  },

  async importProject(json: string): Promise<Project> {
    const imported = JSON.parse(json) as Project;
    imported.id = generateId();
    imported.createdAt = new Date().toISOString();
    imported.updatedAt = new Date().toISOString();
    const projects = await projectService.getAll();
    await projectService.save([imported, ...projects]);
    return imported;
  },
};
