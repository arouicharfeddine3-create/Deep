export type ExtractedArtifactKind = 'code' | 'markdown' | 'text';

export interface ExtractedCodeBlock {
  id: string;
  language: string;
  code: string;
  suggestedFilename: string;
  context: string;
  kind?: ExtractedArtifactKind;
  strategy?: string;
  confidence?: number;
  detectedFilename?: string;
}

export interface InjectedBlockHint {
  lang?: string;
  code?: string;
  context?: string;
  filename?: string;
}

const LANG_EXTENSIONS: Record<string, string> = {
  javascript: 'js',
  js: 'js',
  typescript: 'ts',
  ts: 'ts',
  python: 'py',
  py: 'py',
  html: 'html',
  css: 'css',
  scss: 'scss',
  json: 'json',
  tsx: 'tsx',
  jsx: 'jsx',
  bash: 'sh',
  shell: 'sh',
  sh: 'sh',
  markdown: 'md',
  md: 'md',
  sql: 'sql',
  yaml: 'yml',
  yml: 'yml',
  toml: 'toml',
  java: 'java',
  cpp: 'cpp',
  c: 'c',
  h: 'h',
  hpp: 'hpp',
  rust: 'rs',
  rs: 'rs',
  go: 'go',
  swift: 'swift',
  kotlin: 'kt',
  kt: 'kt',
  ruby: 'rb',
  rb: 'rb',
  php: 'php',
  dart: 'dart',
  text: 'txt',
  plaintext: 'txt',
  txt: 'txt',
  env: 'env',
  ini: 'ini',
  xml: 'xml',
};

const EXT_LANGUAGE_MAP: Record<string, string> = Object.entries(LANG_EXTENSIONS)
  .reduce((acc, [lang, ext]) => {
    if (!acc[ext]) acc[ext] = lang;
    return acc;
  }, {} as Record<string, string>);

const FILE_PATH_REGEX = /(?:^|[^A-Za-z0-9_./-])([A-Za-z0-9@._/-]+\.(?:tsx?|jsx?|py|html?|css|scss|sass|less|json|md|markdown|sh|bash|zsh|sql|ya?ml|toml|go|rs|dart|kt|swift|java|c(?:pp)?|h|hpp|php|rb|vue|svelte|astro|xml|txt|env|ini))(?![A-Za-z0-9_./-])/ig;
const EXPLICIT_FILE_LINE_REGEX = /(?:^|\n)\s*(?:#{1,6}\s*|(?:file|filename|path|ملف|المسار)\s*[:：\-]\s*)`?([A-Za-z0-9@._/-]+\.[A-Za-z0-9]+)`?\s*(?=\n|$)/gi;

function normalizeLanguage(language: string): string {
  const raw = (language || '').trim().toLowerCase();
  if (!raw) return 'text';
  if (raw === 'js' || raw === 'node') return 'javascript';
  if (raw === 'ts') return 'typescript';
  if (raw === 'py') return 'python';
  if (raw === 'md') return 'markdown';
  if (raw === 'plaintext' || raw === 'plain') return 'text';
  if (raw === 'shell' || raw === 'bash' || raw === 'zsh') return 'bash';
  if (raw === 'yml') return 'yaml';
  if (raw === 'rs') return 'rust';
  if (raw === 'kt') return 'kotlin';
  if (raw === 'rb') return 'ruby';
  return raw;
}

function stripControlChars(input: string): string {
  return input
    .replace(/\r\n?/g, '\n')
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .replace(/\t/g, '  ');
}

function inferLanguageFromFilename(filename?: string): string {
  if (!filename) return 'text';
  const match = filename.toLowerCase().match(/\.([a-z0-9]+)$/);
  if (!match) return 'text';
  const ext = match[1];
  if (ext === 'md' || ext === 'markdown') return 'markdown';
  if (ext === 'js') return 'javascript';
  if (ext === 'ts') return 'typescript';
  if (ext === 'py') return 'python';
  if (ext === 'yml') return 'yaml';
  if (ext === 'sh' || ext === 'bash' || ext === 'zsh') return 'bash';
  if (ext === 'rs') return 'rust';
  if (ext === 'kt') return 'kotlin';
  if (ext === 'rb') return 'ruby';
  return EXT_LANGUAGE_MAP[ext] || ext || 'text';
}

function languageToExtension(language: string): string {
  return LANG_EXTENSIONS[normalizeLanguage(language)] || normalizeLanguage(language) || 'txt';
}

function sanitizeFilename(filename: string, language = 'text', kind: ExtractedArtifactKind = 'code'): string {
  let value = (filename || '').trim();
  if (!value) return kind === 'markdown' ? 'deepseek-response.md' : `file.${languageToExtension(language)}`;

  value = value
    .replace(/^[`"'\s]+|[`"'\s]+$/g, '')
    .replace(/^\.?\//, '')
    .replace(/\\/g, '/')
    .replace(/\s+/g, ' ')
    .replace(/[?#].*$/, '')
    .replace(/:+$/, '')
    .trim();

  const parts = value
    .split('/')
    .map(part => part.trim().replace(/[<>:"|?*]/g, '-'))
    .filter(Boolean);

  value = parts.join('/');
  if (!value) return kind === 'markdown' ? 'deepseek-response.md' : `file.${languageToExtension(language)}`;

  if (!/\.[A-Za-z0-9]+$/.test(value)) {
    value += `.${languageToExtension(language)}`;
  }

  return value;
}

function suggestFilename(language: string, code: string, index: number, kind: ExtractedArtifactKind = 'code'): string {
  const normalizedLang = normalizeLanguage(language);
  const ext = languageToExtension(normalizedLang);

  if (kind === 'markdown') {
    if (/\b(readme|overview|installation|usage|setup|quick start)\b/i.test(code) || /\b(مقدمة|التثبيت|الاستخدام|التشغيل)\b/i.test(code)) {
      return 'README.md';
    }
    if (/\b(changelog|release notes|changes)\b/i.test(code)) return 'CHANGELOG.md';
    return index === 0 ? 'deepseek-response.md' : `deepseek-response-${index + 1}.md`;
  }

  const classMatch = code.match(/(?:class|interface|enum|type)\s+([A-Za-z][A-Za-z0-9_]*)/);
  if (classMatch) return `${classMatch[1]}.${ext}`;

  const funcMatch = code.match(/(?:function|def|fn|func)\s+([A-Za-z][A-Za-z0-9_]*)/);
  if (funcMatch) return `${funcMatch[1]}.${ext}`;

  const constMatch = code.match(/(?:const|let|var)\s+([A-Za-z][A-Za-z0-9_]*)\s*=/);
  if (constMatch) return `${constMatch[1]}.${ext}`;

  const exportMatch = code.match(/export\s+default\s+(?:function|class)?\s*([A-Za-z][A-Za-z0-9_]*)/);
  if (exportMatch && exportMatch[1]) return `${exportMatch[1]}.${ext}`;

  if (/^<!doctype html>|<html[\s>]/i.test(code)) return 'index.html';
  if (/^\s*\{[\s\S]*\}\s*$/m.test(code) && normalizedLang === 'json') return 'data.json';
  if (/^\s*---[\s\S]*$/m.test(code) && normalizedLang === 'yaml') return 'config.yml';

  const langNames: Record<string, string> = {
    html: 'index',
    css: 'styles',
    javascript: 'script',
    typescript: 'index',
    python: 'main',
    sql: 'query',
    json: 'data',
    markdown: 'README',
    bash: 'script',
    yaml: 'config',
  };

  const baseName = langNames[normalizedLang] || (kind === 'markdown' ? 'deepseek-response' : 'file');
  return index === 0 ? `${baseName}.${ext}` : `${baseName}_${index + 1}.${ext}`;
}

function takeLastMeaningfulLines(text: string, maxLines = 6): string {
  return text
    .split('\n')
    .map(line => line.trim())
    .filter(Boolean)
    .slice(-maxLines)
    .join('\n')
    .slice(-260);
}

function detectAllFilenames(text: string): string[] {
  const matches: string[] = [];
  if (!text) return matches;
  let match: RegExpExecArray | null;
  FILE_PATH_REGEX.lastIndex = 0;
  while ((match = FILE_PATH_REGEX.exec(text)) !== null) {
    if (match[1]) matches.push(match[1]);
  }
  return matches;
}

function detectFilenameFromText(context: string, suggestedFilename: string): string {
  if (!context) return suggestedFilename;

  const explicitPatterns = [
    /(?:file|filename|path|save to|create|update|named|ملف|المسار|احفظ(?:ه|ها)?\s+في|أنشئ(?:ه|ها)?\s+في|حدّث(?:ه|ها)?\s+في)\s+[`"']?([A-Za-z0-9@._/-]+\.[A-Za-z0-9]{1,10})[`"']?/i,
    /[`"']([A-Za-z0-9@._/-]+\.[A-Za-z0-9]{1,10})[`"']/,
  ];

  for (const pattern of explicitPatterns) {
    const match = context.match(pattern);
    if (match?.[1]) return sanitizeFilename(match[1]);
  }

  const all = detectAllFilenames(context);
  if (all.length > 0) return sanitizeFilename(all[all.length - 1]);
  return sanitizeFilename(suggestedFilename);
}

interface NamedSection {
  filename: string;
  body: string;
  start: number;
  end: number;
  headingStart: number;
  headingEnd: number;
}

function collectNamedSections(text: string): NamedSection[] {
  const hits: { filename: string; headingStart: number; headingEnd: number }[] = [];
  let match: RegExpExecArray | null;
  EXPLICIT_FILE_LINE_REGEX.lastIndex = 0;
  while ((match = EXPLICIT_FILE_LINE_REGEX.exec(text)) !== null) {
    const filename = sanitizeFilename(match[1]);
    if (!filename) continue;
    hits.push({
      filename,
      headingStart: match.index,
      headingEnd: match.index + match[0].length,
    });
  }

  const sections: NamedSection[] = [];
  for (let i = 0; i < hits.length; i++) {
    const current = hits[i];
    const next = hits[i + 1];
    const start = current.headingEnd;
    const end = next ? next.headingStart : text.length;
    const body = text.slice(start, end).trim();
    if (!body) continue;
    sections.push({
      filename: current.filename,
      body,
      start,
      end,
      headingStart: current.headingStart,
      headingEnd: current.headingEnd,
    });
  }

  return sections;
}

interface ParsedArtifact extends ExtractedCodeBlock {
  _order: number;
}

function buildArtifact(params: {
  language: string;
  code: string;
  index: number;
  context?: string;
  suggestedFilename?: string;
  detectedFilename?: string;
  kind?: ExtractedArtifactKind;
  strategy?: string;
  confidence?: number;
  order?: number;
}): ParsedArtifact {
  const kind = params.kind || (normalizeLanguage(params.language) === 'markdown' ? 'markdown' : 'code');
  const detected = params.detectedFilename ? sanitizeFilename(params.detectedFilename, params.language, kind) : undefined;
  const suggested = sanitizeFilename(
    params.suggestedFilename || detected || suggestFilename(params.language, params.code, params.index, kind),
    params.language,
    kind,
  );

  return {
    id: `block_${Date.now()}_${params.index}_${Math.random().toString(36).slice(2, 8)}`,
    language: normalizeLanguage(detected ? inferLanguageFromFilename(detected) || params.language : params.language),
    code: params.code.trim(),
    suggestedFilename: suggested,
    context: (params.context || '').trim().slice(-260),
    kind,
    strategy: params.strategy,
    confidence: params.confidence,
    detectedFilename: detected,
    _order: params.order ?? params.index,
  };
}

function stripOuterFence(text: string): string {
  const trimmed = text.trim();
  const match = trimmed.match(/^```[a-zA-Z0-9_+#\-.]*\n([\s\S]*?)\n```$/);
  return match ? match[1].trim() : trimmed;
}

function extractHintedBlocks(hints: InjectedBlockHint[]): ParsedArtifact[] {
  return hints
    .filter(h => !!(h.code || '').trim())
    .map((hint, index) => {
      const detected = hint.filename ? sanitizeFilename(hint.filename, hint.lang || 'text') : undefined;
      const language = normalizeLanguage(hint.lang || inferLanguageFromFilename(detected) || 'text');
      return buildArtifact({
        language,
        code: (hint.code || '').trim(),
        index,
        context: hint.context || '',
        suggestedFilename: detected || suggestFilename(language, hint.code || '', index),
        detectedFilename: detected,
        kind: language === 'markdown' ? 'markdown' : 'code',
        strategy: detected ? 'dom-hint-filename' : 'dom-hint',
        confidence: detected ? 0.98 : 0.88,
        order: index,
      });
    });
}

function extractFenceBlocks(text: string, namedSections: NamedSection[], startIndex: number): ParsedArtifact[] {
  const blocks: ParsedArtifact[] = [];
  const regex = /```([a-zA-Z0-9_+#\-.]*)\n([\s\S]*?)```/g;
  let match: RegExpExecArray | null;
  let index = startIndex;

  while ((match = regex.exec(text)) !== null) {
    const rawLang = match[1].trim();
    const code = match[2].trim();
    if (!code || code.length < 3) continue;

    const contextStart = Math.max(0, match.index - 320);
    const context = takeLastMeaningfulLines(text.slice(contextStart, match.index), 8);
    const containingSection = namedSections.find(section => match.index >= section.start && match.index <= section.end);
    const explicitFilename = containingSection?.filename || detectFilenameFromText(context, '');
    const inferredFromFilename = inferLanguageFromFilename(explicitFilename);
    const language = normalizeLanguage(rawLang || inferredFromFilename || 'text');
    const suggestedFilename = explicitFilename || suggestFilename(language, code, index);

    blocks.push(buildArtifact({
      language,
      code,
      index,
      context,
      suggestedFilename,
      detectedFilename: explicitFilename || undefined,
      kind: language === 'markdown' ? 'markdown' : 'code',
      strategy: containingSection?.filename ? 'named-section-fence' : (explicitFilename ? 'context-fence' : 'plain-fence'),
      confidence: containingSection?.filename ? 0.99 : (explicitFilename ? 0.9 : 0.75),
      order: match.index,
    }));
    index += 1;
  }

  return blocks;
}

function extractNamedDocumentSections(text: string, namedSections: NamedSection[], fenceBlocks: ParsedArtifact[], startIndex: number): ParsedArtifact[] {
  const docs: ParsedArtifact[] = [];
  let index = startIndex;

  for (const section of namedSections) {
    const extLang = normalizeLanguage(inferLanguageFromFilename(section.filename));
    const containsFence = /```[\s\S]*?```/.test(section.body);
    const isDocLike = ['markdown', 'text', 'json', 'yaml', 'toml', 'html'].includes(extLang);

    if (!isDocLike && containsFence) continue;

    const bodyContent = extLang === 'markdown'
      ? section.body.trim()
      : (containsFence ? stripOuterFence(section.body) : section.body.trim());

    if (!bodyContent || bodyContent.length < 8) continue;

    const alreadyCovered = fenceBlocks.some(block =>
      block.detectedFilename === section.filename &&
      block.code.trim() === bodyContent.trim(),
    );

    if (alreadyCovered) continue;

    docs.push(buildArtifact({
      language: extLang || 'markdown',
      code: bodyContent,
      index,
      context: `section:${section.filename}`,
      suggestedFilename: section.filename,
      detectedFilename: section.filename,
      kind: extLang === 'markdown' || extLang === 'html' ? 'markdown' : 'text',
      strategy: containsFence ? 'named-section-document' : 'named-section-text',
      confidence: 0.97,
      order: section.headingStart,
    }));
    index += 1;
  }

  return docs;
}

function stripCodeFences(text: string): string {
  return text
    .replace(/```[a-zA-Z0-9_+#\-.]*\n[\s\S]*?```/g, '')
    .replace(/(?:^|\n)\s*(?:#{1,6}\s*|(?:file|filename|path|ملف|المسار)\s*[:：\-]\s*)`?[A-Za-z0-9@._/-]+\.[A-Za-z0-9]+`?\s*(?=\n|$)/gi, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function chooseNarrativeFilename(text: string, codeBlockCount: number): string {
  const lower = text.toLowerCase();
  if (/\b(readme|overview|installation|usage|setup|quick start)\b/.test(lower) || /\b(مقدمة|التثبيت|الاستخدام|التشغيل)\b/.test(text)) {
    return 'README.md';
  }
  if (/\b(changelog|release notes|changes)\b/.test(lower) || /سجل التغييرات/.test(text)) {
    return 'CHANGELOG.md';
  }
  if (/\b(requirements|spec|specification)\b/.test(lower) || /\b(المتطلبات|المواصفات)\b/.test(text)) {
    return 'docs/requirements.md';
  }
  if (codeBlockCount > 0) return 'docs/deepseek-notes.md';
  return 'deepseek-response.md';
}

function extractNarrativeDocument(text: string, fenceBlocks: ParsedArtifact[], startIndex: number): ParsedArtifact[] {
  const narrative = stripCodeFences(text);
  const lineCount = narrative.split('\n').filter(line => line.trim()).length;
  if (narrative.length < 120 && lineCount < 4) return [];

  return [buildArtifact({
    language: 'markdown',
    code: narrative,
    index: startIndex,
    context: takeLastMeaningfulLines(narrative, 4),
    suggestedFilename: chooseNarrativeFilename(narrative, fenceBlocks.length),
    kind: 'markdown',
    strategy: fenceBlocks.length > 0 ? 'narrative-companion' : 'full-response-markdown',
    confidence: fenceBlocks.length > 0 ? 0.6 : 0.72,
    order: Number.MAX_SAFE_INTEGER - 1,
  })];
}

function dedupeArtifacts(items: ParsedArtifact[]): ExtractedCodeBlock[] {
  const seen = new Set<string>();
  return items
    .filter(item => !!item.code.trim())
    .sort((a, b) => a._order - b._order)
    .filter(item => {
      const key = [
        item.detectedFilename || item.suggestedFilename,
        item.language,
        item.code.length,
        item.code.slice(0, 160),
      ].join('|');
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .map(({ _order, ...rest }) => rest);
}

export function parseCodeBlocks(responseText: string, hintedBlocks: InjectedBlockHint[] = []): ExtractedCodeBlock[] {
  const normalizedText = stripControlChars(responseText || '').trim();
  const hinted = extractHintedBlocks(hintedBlocks);
  if (!normalizedText && hinted.length === 0) return [];

  const namedSections = collectNamedSections(normalizedText);
  const fenceBlocks = extractFenceBlocks(normalizedText, namedSections, hinted.length);
  const namedDocs = extractNamedDocumentSections(normalizedText, namedSections, fenceBlocks, hinted.length + fenceBlocks.length);
  const narrativeDocs = extractNarrativeDocument(normalizedText, [...hinted, ...fenceBlocks], hinted.length + fenceBlocks.length + namedDocs.length);

  return dedupeArtifacts([
    ...hinted,
    ...fenceBlocks,
    ...namedDocs,
    ...narrativeDocs,
  ]);
}

export function computeDiff(oldContent: string, newContent: string): { added: number; removed: number; changed: boolean } {
  if (oldContent === newContent) return { added: 0, removed: 0, changed: false };

  const oldLines = oldContent.split('\n');
  const newLines = newContent.split('\n');
  const oldSet = new Set(oldLines);
  const newSet = new Set(newLines);
  const added = newLines.filter(line => !oldSet.has(line)).length;
  const removed = oldLines.filter(line => !newSet.has(line)).length;

  return { added, removed, changed: true };
}

export interface SelectorConfig {
  sendBtn: string;
  stopBtn: string;
  codeBlock: string;
  responseContainer: string;
}

export const DEFAULT_SELECTORS: SelectorConfig = {
  sendBtn: 'div[role="button"].ds-icon-button, button[aria-label="Send message"], button[type="submit"]',
  stopBtn: 'div[role="button"].ds-icon-button._7436101, div.ds-icon-button[class*="stop"], [aria-label*="Stop"], [aria-label*="stop"]',
  codeBlock: 'pre code, pre',
  responseContainer: '.markdown-body, .ds-markdown, [class*="markdown"], [class*="message-content"], [data-testid*="message"]',
};

export function buildInjectedJS(cfg: SelectorConfig = DEFAULT_SELECTORS): string {
  const esc = (s: string) => s.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
  const sendSel = esc(cfg.sendBtn);
  const stopSel = esc(cfg.stopBtn);
  const codeSel = esc(cfg.codeBlock);
  const containerSel = esc(cfg.responseContainer);

  return `
(function() {
  if (window.__deepcodeV5) return;
  window.__deepcodeV5 = true;

  var SEL_SEND = '${sendSel}';
  var SEL_STOP = '${stopSel}';
  var SEL_CODE = '${codeSel}';
  var SEL_CONTAINER = '${containerSel}';

  var lastHash = '';
  var isGenerating = false;
  var generationStartTime = 0;
  var stopWasVisible = false;

  function notify(type, payload) {
    try {
      window.ReactNativeWebView.postMessage(JSON.stringify(Object.assign({ type: type, timestamp: Date.now() }, payload || {})));
    } catch (e) {}
  }

  function normalizeText(text) {
    return String(text || '')
      .replace(/\r\n?/g, '\n')
      .replace(/[\u200B-\u200D\uFEFF]/g, '')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  function isVisible(el) {
    if (!el) return false;
    var rect = el.getBoundingClientRect();
    var style = window.getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none';
  }

  function findFilenameInText(text) {
    var match = String(text || '').match(/([A-Za-z0-9@._/-]+\.(?:tsx?|jsx?|py|html?|css|scss|sass|less|json|md|markdown|sh|bash|zsh|sql|ya?ml|toml|go|rs|dart|kt|swift|java|c(?:pp)?|h|hpp|php|rb|vue|svelte|astro|xml|txt|env|ini))/i);
    return match ? match[1] : '';
  }

  function inferLangFromFilename(filename) {
    if (!filename) return '';
    var ext = filename.split('.').pop().toLowerCase();
    var map = {
      js: 'javascript', ts: 'typescript', py: 'python', md: 'markdown', markdown: 'markdown',
      yml: 'yaml', sh: 'bash', bash: 'bash', rs: 'rust', kt: 'kotlin', rb: 'ruby'
    };
    return map[ext] || ext || '';
  }

  function collectContainers() {
    var nodes = [];
    try {
      nodes = Array.from(document.querySelectorAll(SEL_CONTAINER));
    } catch (e) {}

    var uniq = [];
    var seen = {};
    nodes.forEach(function(el) {
      if (!el || !isVisible(el)) return;
      var text = normalizeText(el.innerText || el.textContent || '');
      if (text.length < 20) return;
      var key = text.slice(0, 180) + '|' + text.length;
      if (seen[key]) return;
      seen[key] = true;
      uniq.push(el);
    });

    uniq = uniq.filter(function(el) {
      return !uniq.some(function(other) {
        if (other === el) return false;
        if (!other.contains(el)) return false;
        var outer = normalizeText(other.innerText || other.textContent || '');
        var inner = normalizeText(el.innerText || el.textContent || '');
        return outer === inner;
      });
    });

    return uniq.slice(-2);
  }

  function extractFilenameNearCode(el, container) {
    var candidates = [];
    var parent = el;
    for (var depth = 0; depth < 4 && parent; depth++) {
      if (parent.previousElementSibling) {
        candidates.push(parent.previousElementSibling.textContent || '');
      }
      var header = parent.querySelector ? parent.querySelector('[data-testid*="filename"], [class*="filename"], [class*="code-header"], button, span') : null;
      if (header) candidates.push(header.textContent || '');
      parent = parent.parentElement;
    }
    if (container) {
      candidates.push(container.textContent || '');
    }
    for (var i = 0; i < candidates.length; i++) {
      var file = findFilenameInText(candidates[i]);
      if (file) return file;
    }
    return '';
  }

  function detectLang(el, filename) {
    var cls = ((el.className || '') + ' ' + (el.getAttribute && el.getAttribute('class') || '')).trim();
    var match = cls.match(/language-([a-zA-Z0-9_+#\-.]+)/i);
    if (match && match[1]) return match[1].toLowerCase();
    if (el.parentElement) {
      var pCls = String(el.parentElement.className || '');
      var pMatch = pCls.match(/language-([a-zA-Z0-9_+#\-.]+)/i);
      if (pMatch && pMatch[1]) return pMatch[1].toLowerCase();
    }
    return inferLangFromFilename(filename) || 'text';
  }

  function collectBlocks(containers) {
    var results = [];
    var seen = {};

    containers.forEach(function(container) {
      var codeNodes = [];
      try {
        codeNodes = Array.from(container.querySelectorAll(SEL_CODE));
      } catch (e) {}
      if (codeNodes.length === 0) {
        codeNodes = Array.from(container.querySelectorAll('pre code, pre'));
      }

      codeNodes.forEach(function(node) {
        var target = node.tagName === 'CODE' ? node : (node.querySelector && node.querySelector('code')) || node;
        var code = normalizeText(target.textContent || '');
        if (!code || code.length < 5) return;
        var filename = extractFilenameNearCode(target, container);
        var lang = detectLang(target, filename);
        var context = '';
        var pre = target.closest ? target.closest('pre') : target.parentElement;
        if (pre && pre.previousElementSibling) {
          context = normalizeText(pre.previousElementSibling.textContent || '').slice(-220);
        }
        if (!context) {
          context = normalizeText(container.innerText || container.textContent || '').slice(0, 220);
        }
        var key = (filename || '') + '|' + lang + '|' + code.length + '|' + code.slice(0, 120);
        if (seen[key]) return;
        seen[key] = true;
        results.push({ lang: lang, code: code, context: context, filename: filename || undefined });
      });
    });

    return results;
  }

  function tableToMarkdown(table) {
    var rows = Array.from(table.querySelectorAll('tr')).map(function(tr) {
      return Array.from(tr.children).map(function(cell) {
        return normalizeText(cell.textContent || '').replace(/\|/g, '\\|');
      });
    }).filter(function(row) { return row.length > 0 && row.join('').trim().length > 0; });

    if (rows.length === 0) return '';
    var head = rows[0];
    var sep = head.map(function() { return '---'; });
    var body = rows.slice(1);
    var lines = [];
    lines.push('| ' + head.join(' | ') + ' |');
    lines.push('| ' + sep.join(' | ') + ' |');
    body.forEach(function(row) {
      lines.push('| ' + row.join(' | ') + ' |');
    });
    return lines.join('\n') + '\n\n';
  }

  function nodesToMarkdown(node) {
    if (!node) return '';
    if (node.nodeType === 3) {
      return String(node.textContent || '').replace(/\s+/g, ' ');
    }
    if (node.nodeType !== 1) return '';

    var tag = node.tagName.toLowerCase();
    var children = Array.from(node.childNodes).map(nodesToMarkdown).join('');
    var text = normalizeText(node.textContent || '');

    if (tag === 'pre') {
      var codeEl = node.querySelector('code') || node;
      var code = normalizeText(codeEl.textContent || '');
      if (!code) return '';
      var filename = extractFilenameNearCode(codeEl, node.closest ? node.closest(SEL_CONTAINER) : null);
      var lang = detectLang(codeEl, filename);
      return (filename ? 'File: ' + filename + '\n' : '') + '\x60\x60\x60' + lang + '\n' + code + '\n\x60\x60\x60\n\n';
    }

    if (tag === 'code') {
      if (node.parentElement && node.parentElement.tagName && node.parentElement.tagName.toLowerCase() === 'pre') return '';
      return '\x60' + text + '\x60';
    }

    if (/^h[1-6]$/.test(tag)) {
      var level = parseInt(tag.slice(1), 10) || 1;
      return Array(level + 1).join('#') + ' ' + text + '\n\n';
    }

    if (tag === 'li') {
      var parentTag = node.parentElement && node.parentElement.tagName ? node.parentElement.tagName.toLowerCase() : 'ul';
      var prefix = parentTag === 'ol' ? '1. ' : '- ';
      return prefix + text + '\n';
    }

    if (tag === 'ul' || tag === 'ol') {
      var list = Array.from(node.children).map(nodesToMarkdown).join('');
      return list ? list + '\n' : '';
    }

    if (tag === 'blockquote') {
      return text.split('\n').map(function(line) { return line ? '> ' + line : '>'; }).join('\n') + '\n\n';
    }

    if (tag === 'table') {
      return tableToMarkdown(node);
    }

    if (tag === 'a') {
      var href = node.getAttribute('href');
      if (href && href !== '#' && text) return text + ' (' + href + ')';
      return text;
    }

    if (tag === 'br') return '\n';
    if (tag === 'hr') return '\n---\n\n';

    if (tag === 'p' || tag === 'div' || tag === 'section' || tag === 'article') {
      return children.trim() ? children.trim() + '\n\n' : '';
    }

    return children;
  }

  function buildMarkdown(containers, blocks) {
    var markdown = containers.map(function(container) {
      return normalizeText(nodesToMarkdown(container));
    }).filter(Boolean).join('\n\n');

    if (!markdown && blocks.length > 0) {
      markdown = blocks.map(function(block) {
        return (block.filename ? 'File: ' + block.filename + '\n' : '') + '\x60\x60\x60' + block.lang + '\n' + block.code + '\n\x60\x60\x60';
      }).join('\n\n');
    }

    return normalizeText(markdown);
  }

  function buildHash(markdown, blocks, plainText) {
    return [
      markdown.length,
      plainText.length,
      blocks.length,
      blocks.map(function(block) {
        return (block.filename || '') + ':' + block.lang + ':' + block.code.length + ':' + block.code.slice(0, 80);
      }).join('||'),
      markdown.slice(0, 240)
    ].join('|');
  }

  function attachSendListener() {
    document.addEventListener('click', function(e) {
      var target = e.target;
      for (var i = 0; i < 5; i++) {
        if (!target || target === document.body) break;
        try {
          if (target.matches && target.matches(SEL_SEND)) {
            var stopEl = document.querySelector(SEL_STOP);
            if (stopEl && stopEl !== target) break;
            isGenerating = true;
            generationStartTime = Date.now();
            notify('GENERATION_START', { selector: SEL_SEND });
            break;
          }
        } catch (err) {}
        target = target.parentElement;
      }
    }, true);
  }

  function checkStopButton() {
    var stopEls = [];
    try {
      stopEls = Array.from(document.querySelectorAll(SEL_STOP));
    } catch (e) {}

    if (stopEls.length === 0) {
      var iconBtns = document.querySelectorAll('div[role="button"].ds-icon-button, button');
      Array.from(iconBtns).forEach(function(btn) {
        var label = (btn.getAttribute('aria-label') || '').toLowerCase();
        if (label.indexOf('stop') !== -1) stopEls.push(btn);
      });
    }

    var isVisibleNow = stopEls.some(isVisible);

    if (stopWasVisible && !isVisibleNow && isGenerating) {
      isGenerating = false;
      notify('GENERATION_END', { elapsed: Date.now() - generationStartTime });
      setTimeout(scanAndSend, 650);
    }

    stopWasVisible = isVisibleNow;
    if (isVisibleNow !== window.__deepcodeStopVisible) {
      window.__deepcodeStopVisible = isVisibleNow;
      notify('GENERATION_STATUS', { generating: isVisibleNow });
    }
  }

  function scanAndSend() {
    var containers = collectContainers();
    var blocks = collectBlocks(containers);
    var markdown = buildMarkdown(containers, blocks);
    var plainText = normalizeText(containers.map(function(container) {
      return normalizeText(container.innerText || container.textContent || '');
    }).join('\n\n'));

    if (!markdown && !plainText && blocks.length === 0) return;

    var hash = buildHash(markdown, blocks, plainText);
    if (hash === lastHash) return;
    lastHash = hash;

    notify('AI_RESPONSE', {
      text: markdown || plainText,
      markdown: markdown,
      plainText: plainText,
      blocks: blocks,
      blockCount: blocks.length,
      containerCount: containers.length,
      strategy: blocks.length > 0 ? 'markdown+code' : 'markdown-only'
    });
  }

  function debouncedScan() {
    clearTimeout(window.__deepcodeTimer);
    window.__deepcodeTimer = setTimeout(scanAndSend, isGenerating ? 1800 : 900);
  }

  var observer = new MutationObserver(debouncedScan);
  observer.observe(document.body, { childList: true, subtree: true, characterData: true });

  window.__deepcodeInspect = function(sel) {
    try {
      var els = document.querySelectorAll(sel);
      var info = Array.from(els).slice(0, 5).map(function(el) {
        var r = el.getBoundingClientRect();
        return {
          tag: el.tagName,
          cls: String(el.className || '').slice(0, 80),
          text: normalizeText(el.textContent || '').slice(0, 60),
          visible: r.width > 0 && r.height > 0,
        };
      });
      notify('INSPECT_RESULT', { selector: sel, count: els.length, elements: info });
    } catch (e) {
      notify('INSPECT_RESULT', { selector: sel, count: -1, error: e.message });
    }
  };

  attachSendListener();
  setTimeout(scanAndSend, 1800);
  setInterval(function() {
    checkStopButton();
    scanAndSend();
  }, 2500);
})();
`;
}

export const DEEPSEEK_INJECTED_JS = buildInjectedJS(DEFAULT_SELECTORS);
