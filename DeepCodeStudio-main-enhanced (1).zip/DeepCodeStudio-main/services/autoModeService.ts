import { ExtractedCodeBlock } from './responseParser';
import { Project, ProjectFile, projectService } from './projectService';

export interface AutoSaveResult {
  file: ProjectFile;
  action: 'created' | 'updated';
  blockId: string;
  filename: string;
}

export interface AutoModeLog {
  id: string;
  timestamp: number;
  action: 'saved' | 'updated' | 'skipped' | 'error';
  filename: string;
  language: string;
  message: string;
}

const FILE_PATH_REGEX = /([A-Za-z0-9@._/-]+\.(?:tsx?|jsx?|py|html?|css|scss|sass|less|json|md|markdown|sh|bash|zsh|sql|ya?ml|toml|go|rs|dart|kt|swift|java|c(?:pp)?|h|hpp|php|rb|vue|svelte|astro|xml|txt|env|ini))/i;

function languageToExtension(language: string): string {
  const map: Record<string, string> = {
    javascript: 'js',
    typescript: 'ts',
    python: 'py',
    markdown: 'md',
    html: 'html',
    css: 'css',
    json: 'json',
    bash: 'sh',
    shell: 'sh',
    sql: 'sql',
    yaml: 'yml',
    yml: 'yml',
    toml: 'toml',
    java: 'java',
    cpp: 'cpp',
    c: 'c',
    h: 'h',
    hpp: 'hpp',
    rust: 'rs',
    go: 'go',
    swift: 'swift',
    kotlin: 'kt',
    ruby: 'rb',
    php: 'php',
    dart: 'dart',
    xml: 'xml',
    text: 'txt',
  };
  return map[(language || '').toLowerCase()] || (language || 'txt').toLowerCase();
}

function sanitizeFilename(filename: string, language: string, kind: ExtractedCodeBlock['kind'] = 'code'): string {
  let value = (filename || '').trim();
  if (!value) {
    return kind === 'markdown' ? 'deepseek-response.md' : `file.${languageToExtension(language)}`;
  }

  value = value
    .replace(/^[`"'\s]+|[`"'\s]+$/g, '')
    .replace(/^\.?\//, '')
    .replace(/\\/g, '/')
    .replace(/[?#].*$/, '')
    .replace(/:+$/, '')
    .trim();

  value = value
    .split('/')
    .map(part => part.trim().replace(/[<>:"|?*]/g, '-'))
    .filter(Boolean)
    .join('/');

  if (!value) {
    return kind === 'markdown' ? 'deepseek-response.md' : `file.${languageToExtension(language)}`;
  }

  if (!/\.[A-Za-z0-9]+$/.test(value)) {
    value += `.${languageToExtension(language)}`;
  }

  return value;
}

function detectFilenameCandidates(text: string): string[] {
  const candidates: string[] = [];
  if (!text) return candidates;

  const explicitPatterns = [
    /(?:file|filename|path|save to|create|update|named|ملف|المسار|احفظ(?:ه|ها)?\s+في|أنشئ(?:ه|ها)?\s+في|حدّث(?:ه|ها)?\s+في)\s+[`"']?([A-Za-z0-9@._/-]+\.[A-Za-z0-9]{1,10})[`"']?/ig,
    /[`"']([A-Za-z0-9@._/-]+\.[A-Za-z0-9]{1,10})[`"']/g,
  ];

  for (const pattern of explicitPatterns) {
    let match: RegExpExecArray | null;
    pattern.lastIndex = 0;
    while ((match = pattern.exec(text)) !== null) {
      if (match[1]) candidates.push(match[1]);
    }
  }

  const fallbackMatch = text.match(FILE_PATH_REGEX);
  if (fallbackMatch?.[1]) candidates.push(fallbackMatch[1]);
  return candidates;
}

// Attempt to detect a filename from surrounding context text
export function detectFilenameFromContext(context: string, suggestedFilename: string): string {
  if (!context) return suggestedFilename;
  const candidates = detectFilenameCandidates(context);
  if (candidates.length > 0) return sanitizeFilename(candidates[candidates.length - 1], 'text');
  return suggestedFilename;
}

function splitFilename(filename: string): { dir: string; base: string; ext: string } {
  const normalized = filename.replace(/\\/g, '/');
  const lastSlash = normalized.lastIndexOf('/');
  const dir = lastSlash >= 0 ? normalized.slice(0, lastSlash + 1) : '';
  const leaf = lastSlash >= 0 ? normalized.slice(lastSlash + 1) : normalized;
  const dot = leaf.lastIndexOf('.');
  if (dot <= 0) return { dir, base: leaf, ext: '' };
  return { dir, base: leaf.slice(0, dot), ext: leaf.slice(dot) };
}

function ensureUniqueFilename(filename: string, usedNames: Set<string>, files: ProjectFile[]): string {
  const normalized = filename;
  if (!usedNames.has(normalized) && !files.some(f => f.name === normalized)) return normalized;

  const { dir, base, ext } = splitFilename(normalized);
  let counter = 2;
  let candidate = `${dir}${base}_${counter}${ext}`;
  while (usedNames.has(candidate) || files.some(f => f.name === candidate)) {
    counter += 1;
    candidate = `${dir}${base}_${counter}${ext}`;
  }
  return candidate;
}

function isGenericDocumentName(filename: string): boolean {
  const leaf = filename.split('/').pop()?.toLowerCase() || filename.toLowerCase();
  return ['readme.md', 'deepseek-response.md', 'deepseek-notes.md', 'notes.md', 'answer.md'].includes(leaf);
}

function resolveFilename(
  block: ExtractedCodeBlock,
  project: Project,
  usedNames: Set<string>,
): { filename: string; explicit: boolean } {
  const explicitCandidate = sanitizeFilename(
    block.detectedFilename || detectFilenameFromContext(block.context, ''),
    block.language,
    block.kind,
  );

  const explicit = !!explicitCandidate && explicitCandidate !== `file.${languageToExtension(block.language)}`;
  const preferred = sanitizeFilename(
    explicitCandidate || block.suggestedFilename,
    block.language,
    block.kind,
  );

  const existing = project.files.find(f => f.name === preferred);
  const shouldAvoidOverwrite =
    block.kind === 'markdown' &&
    !explicit &&
    isGenericDocumentName(preferred) &&
    existing &&
    existing.content !== block.code &&
    (block.confidence ?? 0) < 0.8;

  const filename = shouldAvoidOverwrite
    ? ensureUniqueFilename(preferred, usedNames, project.files)
    : preferred;

  return { filename, explicit };
}

export async function autoSaveBlocks(
  project: Project,
  blocks: ExtractedCodeBlock[],
): Promise<{ results: AutoSaveResult[]; logs: AutoModeLog[] }> {
  const results: AutoSaveResult[] = [];
  const logs: AutoModeLog[] = [];
  const usedNames = new Set<string>();

  // Reload fresh project data
  const allProjects = await projectService.getAll();
  const freshProject = allProjects.find(p => p.id === project.id);
  if (!freshProject) return { results, logs };

  const orderedBlocks = [...blocks].sort((a, b) => {
    const aDoc = a.kind === 'markdown' ? 1 : 0;
    const bDoc = b.kind === 'markdown' ? 1 : 0;
    return aDoc - bDoc;
  });

  for (const block of orderedBlocks) {
    try {
      const { filename } = resolveFilename(block, freshProject, usedNames);
      usedNames.add(filename);
      const existingFile = freshProject.files.find(f => f.name === filename);

      if (existingFile) {
        if (existingFile.content === block.code) {
          logs.push({
            id: `log_${Date.now()}_${Math.random()}`,
            timestamp: Date.now(),
            action: 'skipped',
            filename,
            language: block.language,
            message: 'المحتوى متطابق، لا داعي للتحديث',
          });
          continue;
        }

        await projectService.updateFile(freshProject.id, existingFile.id, block.code);
        const updatedFile = { ...existingFile, content: block.code, updatedAt: new Date().toISOString() };
        results.push({ file: updatedFile, action: 'updated', blockId: block.id, filename });
        logs.push({
          id: `log_${Date.now()}_${Math.random()}`,
          timestamp: Date.now(),
          action: 'updated',
          filename,
          language: block.language,
          message: block.kind === 'markdown'
            ? `تم تحديث ملف الوثائق ${filename}`
            : `تم تحديث ${filename}`,
        });

        const fileIndex = freshProject.files.findIndex(f => f.id === existingFile.id);
        if (fileIndex !== -1) freshProject.files[fileIndex] = updatedFile;
      } else {
        const newFile = await projectService.addFile(freshProject.id, {
          name: filename,
          language: block.language,
          content: block.code,
          sourceMessageId: block.id,
        });
        results.push({ file: newFile, action: 'created', blockId: block.id, filename });
        logs.push({
          id: `log_${Date.now()}_${Math.random()}`,
          timestamp: Date.now(),
          action: 'saved',
          filename,
          language: block.language,
          message: block.kind === 'markdown'
            ? `تم إنشاء ملف وثائق ذكي ${filename}`
            : `تم إنشاء ${filename}`,
        });
        freshProject.files.push(newFile);
      }
    } catch (err) {
      logs.push({
        id: `log_${Date.now()}_${Math.random()}`,
        timestamp: Date.now(),
        action: 'error',
        filename: block.suggestedFilename,
        language: block.language,
        message: `خطأ: ${err instanceof Error ? err.message : 'فشل الحفظ'}`,
      });
    }
  }

  return { results, logs };
}
