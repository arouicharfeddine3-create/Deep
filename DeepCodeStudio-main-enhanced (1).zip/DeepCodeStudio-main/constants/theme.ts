// DeepCode Studio Theme
export const Colors = {
  // Base
  bg: '#0d1117',
  bgSecondary: '#161b22',
  bgTertiary: '#21262d',
  bgCard: '#1c2128',
  bgHover: '#2d333b',

  // Brand
  primary: '#2f81f7',
  primaryDim: '#1a4a8a',
  accent: '#58a6ff',
  accentGlow: 'rgba(88, 166, 255, 0.15)',

  // DeepSeek Blue
  deepseek: '#4d6aff',
  deepseekDim: 'rgba(77, 106, 255, 0.2)',

  // Syntax colors
  green: '#3fb950',
  yellow: '#d29922',
  orange: '#db6d28',
  red: '#f85149',
  purple: '#bc8cff',
  cyan: '#39d353',

  // Text
  textPrimary: '#e6edf3',
  textSecondary: '#8b949e',
  textMuted: '#484f58',
  textLink: '#58a6ff',

  // Borders
  border: '#30363d',
  borderSubtle: '#21262d',
  borderEmphasis: '#388bfd',

  // States
  success: '#3fb950',
  warning: '#d29922',
  error: '#f85149',
  info: '#58a6ff',
};

export const Typography = {
  fontMono: 'monospace' as const,
  sizes: {
    xs: 11,
    sm: 12,
    base: 14,
    md: 16,
    lg: 18,
    xl: 20,
    xxl: 24,
    xxxl: 30,
  },
  weights: {
    regular: '400' as const,
    medium: '500' as const,
    semibold: '600' as const,
    bold: '700' as const,
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 20,
  xl: 24,
  xxl: 32,
  xxxl: 48,
};

export const Radius = {
  sm: 4,
  md: 6,
  lg: 10,
  xl: 14,
  full: 999,
};

export const Shadow = {
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  glow: {
    shadowColor: '#2f81f7',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 6,
  },
};
