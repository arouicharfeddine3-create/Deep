import React, { useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, Pressable,
  TextInput, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { Image } from 'expo-image';
import { Colors, Typography, Spacing, Radius, Shadow } from '@/constants/theme';
import { useProjects } from '@/hooks/useProjects';
import { Project } from '@/services/projectService';
import { projectService } from '@/services/projectService';
import { useAlert } from '@/template';

function ProjectCard({ project, onPress, onDelete, onExport }: {
  project: Project;
  onPress: () => void;
  onDelete: () => void;
  onExport: () => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const date = new Date(project.updatedAt).toLocaleDateString('ar-SA', { month: 'short', day: 'numeric' });

  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.card, pressed && styles.cardPressed]}>
      {/* Accent line */}
      <View style={[styles.cardAccent, { backgroundColor: project.color }]} />

      <View style={styles.cardBody}>
        <View style={styles.cardHeader}>
          <View style={[styles.projectIcon, { backgroundColor: project.color + '22' }]}>
            <MaterialIcons name="folder" size={20} color={project.color} />
          </View>
          <View style={styles.cardTitles}>
            <Text style={styles.projectName} numberOfLines={1}>{project.name}</Text>
            {project.description ? (
              <Text style={styles.projectDesc} numberOfLines={1}>{project.description}</Text>
            ) : null}
          </View>
          <Pressable onPress={() => setMenuOpen(!menuOpen)} hitSlop={8} style={styles.menuBtn}>
            <MaterialIcons name="more-vert" size={18} color={Colors.textSecondary} />
          </Pressable>
        </View>

        {menuOpen ? (
          <View style={styles.menu}>
            <Pressable onPress={() => { setMenuOpen(false); onExport(); }} style={styles.menuItem}>
              <MaterialIcons name="download" size={15} color={Colors.accent} />
              <Text style={styles.menuItemText}>تصدير</Text>
            </Pressable>
            <Pressable onPress={() => { setMenuOpen(false); onDelete(); }} style={styles.menuItem}>
              <MaterialIcons name="delete" size={15} color={Colors.error} />
              <Text style={[styles.menuItemText, { color: Colors.error }]}>حذف</Text>
            </Pressable>
          </View>
        ) : null}

        <View style={styles.cardFooter}>
          <View style={styles.statPill}>
            <MaterialIcons name="insert-drive-file" size={12} color={Colors.textMuted} />
            <Text style={styles.statText}>{project.files.length} ملف</Text>
          </View>
          <Text style={styles.dateText}>{date}</Text>
        </View>
      </View>
    </Pressable>
  );
}

export default function ProjectsScreen() {
  const router = useRouter();
  const { projects, loading, deleteProject, setActiveProject } = useProjects();
  const { showAlert } = useAlert();
  const [search, setSearch] = useState('');

  const filtered = projects.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleOpenProject = (project: Project) => {
    setActiveProject(project);
    router.push('/(tabs)/workspace');
  };

  const handleDelete = (project: Project) => {
    showAlert('حذف المشروع', `هل تريد حذف "${project.name}" وجميع ملفاته؟`, [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: () => deleteProject(project.id) },
    ]);
  };

  const handleExport = (project: Project) => {
    const json = projectService.exportProject(project);
    showAlert('تصدير المشروع', `تم تصدير "${project.name}" (${json.length} بايت)\n\nانسخ JSON من المحرر لحفظه.`);
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>DeepCode Studio</Text>
          <Text style={styles.headerSub}>مشاريعك مع DeepSeek AI</Text>
        </View>
        <View style={styles.headerActions}>
          <Pressable
            onPress={() => router.push('/import-project')}
            style={({ pressed }) => [styles.headerBtn, pressed && { opacity: 0.7 }]}
          >
            <MaterialIcons name="upload" size={20} color={Colors.textSecondary} />
          </Pressable>
          <Pressable
            onPress={() => router.push('/new-project')}
            style={({ pressed }) => [styles.headerBtn, styles.headerBtnPrimary, pressed && { opacity: 0.8 }]}
          >
            <MaterialIcons name="add" size={20} color="#fff" />
          </Pressable>
        </View>
      </View>

      {/* Search */}
      <View style={styles.searchBar}>
        <MaterialIcons name="search" size={18} color={Colors.textMuted} />
        <TextInput
          style={styles.searchInput}
          value={search}
          onChangeText={setSearch}
          placeholder="بحث في المشاريع..."
          placeholderTextColor={Colors.textMuted}
        />
        {search ? (
          <Pressable onPress={() => setSearch('')} hitSlop={8}>
            <MaterialIcons name="close" size={16} color={Colors.textMuted} />
          </Pressable>
        ) : null}
      </View>

      {/* Stats bar */}
      <View style={styles.statsBar}>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{projects.length}</Text>
          <Text style={styles.statLabel}>مشروع</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{projects.reduce((acc, p) => acc + p.files.length, 0)}</Text>
          <Text style={styles.statLabel}>ملف</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={[styles.statValue, { color: Colors.green }]}>نشط</Text>
          <Text style={styles.statLabel}>الحالة</Text>
        </View>
      </View>

      {/* List */}
      {filtered.length === 0 ? (
        <View style={styles.empty}>
          <Image
            source={require('@/assets/images/empty-projects.png')}
            style={styles.emptyImg}
            contentFit="contain"
          />
          <Text style={styles.emptyTitle}>
            {projects.length === 0 ? 'لا توجد مشاريع بعد' : 'لا توجد نتائج'}
          </Text>
          <Text style={styles.emptyHint}>
            {projects.length === 0
              ? 'أنشئ مشروعاً جديداً أو استورد مشروعاً موجوداً'
              : 'جرب كلمة بحث مختلفة'
            }
          </Text>
          {projects.length === 0 ? (
            <Pressable
              onPress={() => router.push('/new-project')}
              style={({ pressed }) => [styles.emptyBtn, pressed && { opacity: 0.8 }]}
            >
              <MaterialIcons name="add" size={18} color="#fff" />
              <Text style={styles.emptyBtnText}>مشروع جديد</Text>
            </Pressable>
          ) : null}
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <ProjectCard
              project={item}
              onPress={() => handleOpenProject(item)}
              onDelete={() => handleDelete(item)}
              onExport={() => handleExport(item)}
            />
          )}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
  },
  headerTitle: { color: Colors.textPrimary, fontSize: Typography.sizes.xl, fontWeight: Typography.weights.bold },
  headerSub: { color: Colors.textMuted, fontSize: Typography.sizes.sm, marginTop: 2 },
  headerActions: { flexDirection: 'row', gap: Spacing.sm },
  headerBtn: {
    width: 38, height: 38, alignItems: 'center', justifyContent: 'center',
    backgroundColor: Colors.bgTertiary, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border,
  },
  headerBtnPrimary: { backgroundColor: Colors.primary, borderColor: Colors.primary },

  searchBar: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    marginHorizontal: Spacing.base, marginBottom: Spacing.sm,
    backgroundColor: Colors.bgSecondary, borderRadius: Radius.md,
    paddingHorizontal: Spacing.sm, borderWidth: 1, borderColor: Colors.border,
    height: 42,
  },
  searchInput: { flex: 1, color: Colors.textPrimary, fontSize: Typography.sizes.base },

  statsBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    marginHorizontal: Spacing.base, marginBottom: Spacing.md,
    backgroundColor: Colors.bgCard, borderRadius: Radius.lg,
    paddingVertical: Spacing.sm, borderWidth: 1, borderColor: Colors.border,
  },
  statItem: { flex: 1, alignItems: 'center' },
  statValue: { color: Colors.accent, fontSize: Typography.sizes.lg, fontWeight: Typography.weights.bold },
  statLabel: { color: Colors.textMuted, fontSize: Typography.sizes.xs },
  statDivider: { width: 1, height: 28, backgroundColor: Colors.border },

  list: { paddingHorizontal: Spacing.base, paddingBottom: Spacing.xxl },
  card: {
    backgroundColor: Colors.bgCard, borderRadius: Radius.lg,
    marginBottom: Spacing.sm, overflow: 'hidden',
    borderWidth: 1, borderColor: Colors.border,
    flexDirection: 'row',
    ...Shadow.card,
  },
  cardPressed: { opacity: 0.85, transform: [{ scale: 0.99 }] },
  cardAccent: { width: 4 },
  cardBody: { flex: 1, padding: Spacing.md },
  cardHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: Spacing.sm },
  projectIcon: { width: 40, height: 40, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center', marginRight: Spacing.sm },
  cardTitles: { flex: 1 },
  projectName: { color: Colors.textPrimary, fontSize: Typography.sizes.md, fontWeight: Typography.weights.semibold },
  projectDesc: { color: Colors.textMuted, fontSize: Typography.sizes.sm, marginTop: 1 },
  menuBtn: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
  menu: {
    backgroundColor: Colors.bgTertiary, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.sm, overflow: 'hidden',
  },
  menuItem: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, padding: Spacing.sm },
  menuItemText: { color: Colors.textSecondary, fontSize: Typography.sizes.base },
  cardFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  statPill: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  statText: { color: Colors.textMuted, fontSize: Typography.sizes.xs },
  dateText: { color: Colors.textMuted, fontSize: Typography.sizes.xs },

  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, padding: Spacing.xxl },
  emptyImg: { width: 160, height: 160 },
  emptyTitle: { color: Colors.textSecondary, fontSize: Typography.sizes.lg, fontWeight: Typography.weights.semibold },
  emptyHint: { color: Colors.textMuted, fontSize: Typography.sizes.base, textAlign: 'center' },
  emptyBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: Colors.primary, borderRadius: Radius.md,
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm,
    marginTop: Spacing.sm,
  },
  emptyBtnText: { color: '#fff', fontSize: Typography.sizes.base, fontWeight: Typography.weights.semibold },
});
