import React, { useState, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, TextInput, Switch,
  Platform, Animated, Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import * as Clipboard from 'expo-clipboard';
import { Colors, Typography, Spacing, Radius, Shadow } from '@/constants/theme';
import { parseCodeBlocks, DEEPSEEK_INJECTED_JS } from '@/services/responseParser';
import { useProjects } from '@/hooks/useProjects';
import { projectService } from '@/services/projectService';
import { autoSaveBlocks } from '@/services/autoModeService';
import { useAlert } from '@/template';

// ─── Extraction Tester WebView Panel ─────────────────────────────────────────

// Test HTML with multiple code blocks in different languages
const TEST_HTML = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body { background: #0d1117; color: #e6edf3; font-family: -apple-system, sans-serif; padding: 16px; }
  h2 { color: #58a6ff; margin-bottom: 8px; font-size: 15px; }
  p { color: #8b949e; font-size: 13px; margin: 4px 0 12px; }
  pre { background: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 12px; margin-bottom: 16px; overflow-x: auto; }
  code { font-family: monospace; font-size: 12px; line-height: 1.6; }
  .lang-badge { display: inline-block; background: #2f81f722; color: #58a6ff; border: 1px solid #2f81f744; border-radius: 4px; font-size: 10px; padding: 2px 6px; margin-bottom: 6px; font-family: monospace; }
  .status { position: fixed; bottom: 12px; right: 12px; background: #3fb95022; border: 1px solid #3fb95044; border-radius: 20px; padding: 6px 12px; font-size: 11px; color: #3fb950; }
</style>
</head>
<body>
<h2>🧪 صفحة اختبار الاستخراج</h2>
<p>هذه الصفحة تحتوي على كتل كود متعددة للتحقق من عمل نظام الاستخراج التلقائي.</p>

<div class="lang-badge">python</div>
<pre><code class="language-python">def fibonacci(n):
    if n <= 1:
        return n
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

print(fibonacci(10))  # 55
</code></pre>

<div class="lang-badge">typescript</div>
<pre><code class="language-typescript">interface ApiResponse {
  data: unknown;
  status: number;
  message: string;
}

async function fetchData(url: string): Promise<ApiResponse> {
  const res = await fetch(url);
  const data = await res.json();
  return { data, status: res.status, message: 'OK' };
}
</code></pre>

<div class="lang-badge">javascript</div>
<pre><code class="language-javascript">const debounce = (fn, delay) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
};

const search = debounce((query) => {
  console.log('Searching:', query);
}, 300);
</code></pre>

<div class="lang-badge">css</div>
<pre><code class="language-css">.card {
  background: linear-gradient(135deg, #1c2128, #161b22);
  border: 1px solid #30363d;
  border-radius: 12px;
  padding: 16px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
  transition: transform 0.2s ease;
}

.card:hover {
  transform: translateY(-2px);
  border-color: #58a6ff44;
}
</code></pre>

<div class="lang-badge">sql</div>
<pre><code class="language-sql">SELECT
  u.id,
  u.name,
  COUNT(p.id) AS post_count,
  MAX(p.created_at) AS last_post
FROM users u
LEFT JOIN posts p ON p.user_id = u.id
WHERE u.active = true
GROUP BY u.id, u.name
ORDER BY post_count DESC
LIMIT 10;
</code></pre>

<div class="status" id="status">جاهز للاختبار</div>
</body>
</html>`;

interface ScanResult {
  lang: string;
  codePreview: string;
  size: number;
}

interface ExtractionTesterProps {
  visible: boolean;
  onClose: () => void;
}

function ExtractionTester({ visible, onClose }: ExtractionTesterProps) {
  const [scanResults, setScanResults] = useState<ScanResult[]>([]);
  const [scanCount, setScanCount] = useState(0);
  const [lastScanTime, setLastScanTime] = useState<string>('');
  const [webLoaded, setWebLoaded] = useState(false);
  const webviewRef = useRef<any>(null);
  const slideAnim = useRef(new Animated.Value(0)).current;

  React.useEffect(() => {
    if (visible) {
      setScanResults([]);
      setScanCount(0);
      setLastScanTime('');
      setWebLoaded(false);
      Animated.spring(slideAnim, { toValue: 1, useNativeDriver: true, tension: 120, friction: 9 }).start();
    } else {
      slideAnim.setValue(0);
    }
  }, [visible]);

  const handleMessage = useCallback((event: any) => {
    try {
      const data = JSON.parse(event.nativeEvent.data);
      if (data.type === 'AI_RESPONSE' && data.text) {
        const blocks = parseCodeBlocks(data.markdown || data.text, data.blocks || []);
        const results: ScanResult[] = blocks.map(b => ({
          lang: b.language,
          codePreview: b.code.slice(0, 80).replace(/\n/g, ' '),
          size: b.code.length,
        }));
        setScanResults(results);
        setScanCount(prev => prev + 1);
        setLastScanTime(new Date().toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      }
    } catch {}
  }, []);

  const triggerManualScan = () => {
    if (webviewRef.current) {
      webviewRef.current.injectJavaScript(`
        (function() {
          var blocks = [];
          document.querySelectorAll('pre code').forEach(function(el) {
            var code = (el.textContent || '').trim();
            if (!code) return;
            var cls = el.className || '';
            var m = cls.match(/language-([a-zA-Z0-9]+)/);
            var lang = m ? m[1] : 'text';
            blocks.push({ lang: lang, code: code, context: '' });
          });
          if (blocks.length === 0) return;
          var text = '';
          blocks.forEach(function(b) {
            text += '\x60\x60\x60' + b.lang + '\\n' + b.code + '\\n\x60\x60\x60\\n\\n';
          });
          window.ReactNativeWebView.postMessage(JSON.stringify({
            type: 'AI_RESPONSE', text: text,
            blockCount: blocks.length, timestamp: Date.now()
          }));
        })();
        true;
      `);
    }
  };

  if (!visible) return null;

  const translateY = slideAnim.interpolate({ inputRange: [0, 1], outputRange: [300, 0] });

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={testerStyles.overlay}>
        <Pressable style={testerStyles.backdrop} onPress={onClose} />
        <Animated.View style={[testerStyles.panel, { transform: [{ translateY }] }]}>
          {/* Header */}
          <View style={testerStyles.header}>
            <View style={testerStyles.headerLeft}>
              <View style={testerStyles.headerIcon}>
                <MaterialIcons name="science" size={16} color={Colors.green} />
              </View>
              <View>
                <Text style={testerStyles.headerTitle}>اختبار الاستخراج</Text>
                <Text style={testerStyles.headerSub}>
                  {webLoaded ? `${scanResults.length} عنصر مكتشف · فحص #${scanCount}` : 'جاري التحميل...'}
                </Text>
              </View>
            </View>
            <View style={testerStyles.headerRight}>
              <Pressable
                onPress={triggerManualScan}
                style={({ pressed }) => [testerStyles.scanBtn, pressed && { opacity: 0.7 }]}
              >
                <MaterialIcons name="radar" size={13} color="#fff" />
                <Text style={testerStyles.scanBtnText}>فحص يدوي</Text>
              </Pressable>
              <Pressable onPress={onClose} hitSlop={8} style={({ pressed }) => [pressed && { opacity: 0.6 }]}>
                <MaterialIcons name="close" size={20} color={Colors.textSecondary} />
              </Pressable>
            </View>
          </View>

          {/* WebView area */}
          {Platform.OS !== 'web' ? (
            <View style={testerStyles.webviewWrap}>
              {(() => {
                const { WebView } = require('react-native-webview');
                return (
                  <WebView
                    ref={webviewRef}
                    source={{ html: TEST_HTML }}
                    style={testerStyles.webview}
                    injectedJavaScript={DEEPSEEK_INJECTED_JS}
                    onMessage={handleMessage}
                    onLoadEnd={() => setWebLoaded(true)}
                    javaScriptEnabled
                    scrollEnabled
                  />
                );
              })()}
            </View>
          ) : (
            <View style={testerStyles.webFallback}>
              <MaterialIcons name="phone-iphone" size={28} color={Colors.textMuted} />
              <Text style={testerStyles.webFallbackText}>الاختبار يعمل على الهاتف فقط</Text>
            </View>
          )}

          {/* Results area */}
          <View style={testerStyles.results}>
            <View style={testerStyles.resultsHeader}>
              <MaterialIcons name="analytics" size={13} color={Colors.accent} />
              <Text style={testerStyles.resultsTitle}>نتائج المسح</Text>
              {lastScanTime ? (
                <Text style={testerStyles.resultsTime}>آخر فحص: {lastScanTime}</Text>
              ) : null}
              <View style={[testerStyles.statusDot, { backgroundColor: webLoaded ? Colors.green : Colors.yellow }]} />
              <Text style={[testerStyles.statusLabel, { color: webLoaded ? Colors.green : Colors.yellow }]}>
                {webLoaded ? 'نشط' : 'تحميل'}
              </Text>
            </View>

            {scanResults.length === 0 ? (
              <View style={testerStyles.noResults}>
                <Text style={testerStyles.noResultsText}>
                  {webLoaded
                    ? 'لم يتم الكشف بعد — الصفحة تحتوي على ردود وكُتل كود جاهزة للاختبار. انتظر الكشف التلقائي أو اضغط "فحص يدوي"'
                    : 'جاري تحميل صفحة الاختبار...'}
                </Text>
              </View>
            ) : (
              <ScrollView style={testerStyles.resultsList} showsVerticalScrollIndicator={false}>
                {scanResults.map((r, i) => (
                  <View key={i} style={testerStyles.resultItem}>
                    <View style={testerStyles.resultLangBadge}>
                      <Text style={testerStyles.resultLang}>{r.lang.toUpperCase()}</Text>
                    </View>
                    <Text style={testerStyles.resultPreview} numberOfLines={1}>{r.codePreview}</Text>
                    <Text style={testerStyles.resultSize}>{r.size}c</Text>
                  </View>
                ))}
              </ScrollView>
            )}

            {/* Stats row */}
            {scanResults.length > 0 ? (
              <View style={testerStyles.statsRow}>
                <View style={testerStyles.statChip}>
                  <MaterialIcons name="check-circle" size={11} color={Colors.green} />
                  <Text style={[testerStyles.statText, { color: Colors.green }]}>
                    {scanResults.length} عنصر مكتشف
                  </Text>
                </View>
                <View style={testerStyles.statChip}>
                  <MaterialIcons name="code" size={11} color={Colors.accent} />
                  <Text style={[testerStyles.statText, { color: Colors.accent }]}>
                    {[...new Set(scanResults.map(r => r.lang))].join(', ')}
                  </Text>
                </View>
                <View style={testerStyles.statChip}>
                  <MaterialIcons name="sync" size={11} color={Colors.textMuted} />
                  <Text style={testerStyles.statText}>{scanCount} فحص</Text>
                </View>
              </View>
            ) : null}
          </View>
        </Animated.View>
      </View>
    </Modal>
  );
}

const testerStyles = StyleSheet.create({
  overlay: { flex: 1, justifyContent: 'flex-end' },
  backdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.7)' },
  panel: {
    backgroundColor: Colors.bg,
    borderTopLeftRadius: 20, borderTopRightRadius: 20,
    borderWidth: 1, borderColor: Colors.border, borderBottomWidth: 0,
    maxHeight: '88%',
    overflow: 'hidden',
  },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    backgroundColor: Colors.bgSecondary,
  },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  headerIcon: {
    width: 32, height: 32, borderRadius: 8,
    backgroundColor: Colors.green + '22',
    alignItems: 'center', justifyContent: 'center',
  },
  headerTitle: { color: Colors.textPrimary, fontSize: 14, fontWeight: '700' },
  headerSub: { color: Colors.textMuted, fontSize: 11, marginTop: 1 },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  scanBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: Colors.accent,
    borderRadius: Radius.md, paddingHorizontal: 10, paddingVertical: 5,
  },
  scanBtnText: { color: '#fff', fontSize: 11, fontWeight: '700' },

  webviewWrap: {
    height: 220, borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  webview: { flex: 1 },
  webFallback: {
    height: 100, alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: Colors.bgSecondary,
  },
  webFallbackText: { color: Colors.textMuted, fontSize: 12 },

  results: { backgroundColor: Colors.bgSecondary },
  resultsHeader: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: Spacing.md, paddingVertical: 8,
    borderBottomWidth: 1, borderBottomColor: Colors.borderSubtle,
  },
  resultsTitle: { color: Colors.textSecondary, fontSize: 12, fontWeight: '600', flex: 1 },
  resultsTime: { color: Colors.textMuted, fontSize: 10, fontFamily: 'monospace' },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  statusLabel: { fontSize: 10, fontWeight: '700' },

  noResults: { padding: Spacing.md },
  noResultsText: {
    color: Colors.textMuted, fontSize: 11,
    textAlign: 'center', lineHeight: 16,
  },

  resultsList: { maxHeight: 130 },
  resultItem: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    paddingHorizontal: Spacing.md, paddingVertical: 6,
    borderBottomWidth: 1, borderBottomColor: Colors.borderSubtle,
  },
  resultLangBadge: {
    backgroundColor: Colors.deepseek + '22',
    borderRadius: 4, paddingHorizontal: 5, paddingVertical: 2,
    borderWidth: 1, borderColor: Colors.deepseek + '44',
    minWidth: 44, alignItems: 'center',
  },
  resultLang: { color: Colors.deepseek, fontSize: 9, fontWeight: '700', fontFamily: 'monospace' },
  resultPreview: {
    flex: 1, color: Colors.textSecondary,
    fontSize: 11, fontFamily: 'monospace',
  },
  resultSize: { color: Colors.textMuted, fontSize: 10, fontFamily: 'monospace' },

  statsRow: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    paddingHorizontal: Spacing.md, paddingVertical: 8,
    flexWrap: 'wrap',
  },
  statChip: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: Colors.bgTertiary, borderRadius: Radius.sm,
    paddingHorizontal: 7, paddingVertical: 3,
  },
  statText: { color: Colors.textMuted, fontSize: 10, fontWeight: '600' },
});

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function ToolsScreen() {
  const { activeProject, importProject, autoMode, setAutoMode, autoLogs, clearLogs, autoSavedCount, addAutoLog, incrementAutoSaved, refreshProjects } = useProjects();
  const { showAlert } = useAlert();
  const [importText, setImportText] = useState('');
  const [parseInput, setParseInput] = useState('');
  const [parseResult, setParseResult] = useState('');
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [autoSaving, setAutoSaving] = useState(false);
  const [showTester, setShowTester] = useState(false);

  const handleParseResponse = () => {
    if (!parseInput.trim()) {
      showAlert('تنبيه', 'أدخل نص الرد أولاً');
      return;
    }
    const blocks = parseCodeBlocks(parseInput);
    if (blocks.length === 0) {
      setParseResult('لم يتم العثور على عناصر قابلة للتحويل إلى ملفات في النص المدخل.');
    } else {
      setParseResult(
        blocks.map((b, i) =>
          `[${i + 1}] ${b.suggestedFilename} (${b.language})\n${b.code.slice(0, 100)}...`
        ).join('\n\n')
      );
    }
  };

  const handleAutoSaveFromText = async () => {
    if (!parseInput.trim()) {
      showAlert('تنبيه', 'أدخل نص الرد أولاً');
      return;
    }
    if (!activeProject) {
      showAlert('تنبيه', 'اختر مشروعاً نشطاً أولاً');
      return;
    }
    const blocks = parseCodeBlocks(parseInput);
    if (blocks.length === 0) {
      showAlert('لا يوجد محتوى قابل للحفظ', 'لم يتم العثور على عناصر قابلة للتحويل إلى ملفات');
      return;
    }
    setAutoSaving(true);
    try {
      const { results, logs } = await autoSaveBlocks(activeProject, blocks);
      logs.forEach(log => addAutoLog(log));
      await refreshProjects();
      incrementAutoSaved(results.length);
      const created = results.filter(r => r.action === 'created').length;
      const updated = results.filter(r => r.action === 'updated').length;
      showAlert(
        'تم الحفظ التلقائي',
        `تم إنشاء ${created} ملف جديد\nتم تحديث ${updated} ملف\n\nإجمالي: ${results.length} ملف في "${activeProject.name}"`
      );
      setParseInput('');
      setParseResult('');
    } catch {
      showAlert('خطأ', 'فشل في الحفظ التلقائي');
    } finally {
      setAutoSaving(false);
    }
  };

  const handleImportProject = async () => {
    if (!importText.trim()) {
      showAlert('تنبيه', 'أدخل JSON المشروع');
      return;
    }
    try {
      const project = await importProject(importText);
      showAlert('تم الاستيراد', `تم استيراد مشروع "${project.name}" بنجاح مع ${project.files.length} ملف`);
      setImportText('');
    } catch {
      showAlert('خطأ', 'فشل في استيراد المشروع. تأكد من صحة JSON');
    }
  };

  const handleExportProject = async () => {
    if (!activeProject) {
      showAlert('تنبيه', 'اختر مشروعاً أولاً من تبويب المشاريع');
      return;
    }
    const json = projectService.exportProject(activeProject);
    await Clipboard.setStringAsync(json);
    showAlert('تم التصدير', `تم نسخ JSON المشروع "${activeProject.name}" إلى الحافظة\n\n${activeProject.files.length} ملف، ${json.length} حرف`);
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>الأدوات</Text>
        <Text style={styles.headerSub}>أدوات تطوير مدمجة</Text>
      </View>

      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>

        {/* ── Extraction Tester ──────────────────────────────────────────── */}
        <Pressable
          onPress={() => setShowTester(true)}
          style={({ pressed }) => [styles.testerCard, pressed && { opacity: 0.85 }]}
        >
          <View style={styles.testerGlow} />
          <View style={styles.testerLeft}>
            <View style={styles.testerIconWrap}>
              <MaterialIcons name="science" size={26} color={Colors.green} />
            </View>
            <View style={styles.testerInfo}>
              <Text style={styles.testerTitle}>اختبار الاستخراج التلقائي</Text>
              <Text style={styles.testerDesc}>
                تحقق من عمل الـ injection — صفحة مع 5 كتل كود جاهزة للاختبار
              </Text>
              <View style={styles.testerBadges}>
                {['Python', 'TypeScript', 'JS', 'CSS', 'SQL'].map(lang => (
                  <View key={lang} style={styles.testerBadge}>
                    <Text style={styles.testerBadgeText}>{lang}</Text>
                  </View>
                ))}
              </View>
            </View>
          </View>
          <MaterialIcons name="arrow-forward-ios" size={14} color={Colors.green} />
        </Pressable>

        {/* ── Auto Mode Card ────────────────────────────────────────────── */}
        <View style={[styles.autoModeCard, autoMode && styles.autoModeCardActive]}>
          <View style={styles.autoModeTop}>
            <View style={[styles.autoModeIconWrap, autoMode && styles.autoModeIconWrapActive]}>
              <MaterialIcons name="bolt" size={24} color={autoMode ? Colors.green : Colors.textSecondary} />
            </View>
            <View style={styles.autoModeInfo}>
              <Text style={[styles.autoModeTitle, autoMode && { color: Colors.green }]}>المود التلقائي</Text>
              <Text style={styles.autoModeDesc}>
                {autoMode
                  ? 'نشط — يحفظ الملفات والوثائق تلقائياً من ردود DeepSeek'
                  : 'معطّل — حفظ يدوي'}
              </Text>
            </View>
            <Switch
              value={autoMode}
              onValueChange={setAutoMode}
              trackColor={{ false: Colors.bgTertiary, true: Colors.green + '88' }}
              thumbColor={autoMode ? Colors.green : Colors.textSecondary}
            />
          </View>

          {autoMode ? (
            <View style={styles.autoModeStats}>
              <View style={styles.autoStatItem}>
                <Text style={styles.autoStatVal}>{autoSavedCount}</Text>
                <Text style={styles.autoStatLabel}>محفوظ</Text>
              </View>
              <View style={styles.autoStatDivider} />
              <View style={styles.autoStatItem}>
                <Text style={styles.autoStatVal}>{autoLogs.filter(l => l.action === 'updated').length}</Text>
                <Text style={styles.autoStatLabel}>محدّث</Text>
              </View>
              <View style={styles.autoStatDivider} />
              <View style={styles.autoStatItem}>
                <Text style={styles.autoStatVal}>{autoLogs.filter(l => l.action === 'error').length}</Text>
                <Text style={[styles.autoStatLabel, { color: Colors.error }]}>خطأ</Text>
              </View>
            </View>
          ) : (
            <Text style={styles.autoModeHint}>
              عند التفعيل، سيراقب التطبيق ردود DeepSeek ويحفظ الكود أو الوثائق أو ملفات markdown تلقائياً في المشروع النشط حسب السياق.
            </Text>
          )}
        </View>

        {/* ── Activity Log ──────────────────────────────────────────────── */}
        <View style={styles.toolCard}>
          <Pressable
            onPress={() => setActiveSection(activeSection === 'log' ? null : 'log')}
            style={({ pressed }) => [styles.toolHeader, pressed && { opacity: 0.8 }]}
          >
            <View style={[styles.toolIcon, { backgroundColor: Colors.purple + '22' }]}>
              <MaterialIcons name="history" size={22} color={Colors.purple} />
            </View>
            <View style={styles.toolInfo}>
              <Text style={styles.toolTitle}>سجل النشاط</Text>
              <Text style={styles.toolDesc}>{autoLogs.length} عملية مسجلة</Text>
            </View>
            <MaterialIcons
              name={activeSection === 'log' ? 'keyboard-arrow-up' : 'keyboard-arrow-down'}
              size={18} color={Colors.textSecondary}
            />
          </Pressable>
          {activeSection === 'log' ? (
            <View style={styles.toolBody}>
              {autoLogs.length === 0 ? (
                <Text style={styles.emptyLogText}>لا توجد عمليات بعد. فعّل المود التلقائي وابدأ المحادثة.</Text>
              ) : (
                <>
                  <Pressable onPress={clearLogs} style={({ pressed }) => [styles.clearBtn, pressed && { opacity: 0.7 }]}>
                    <MaterialIcons name="delete-sweep" size={14} color={Colors.error} />
                    <Text style={styles.clearBtnText}>مسح السجل</Text>
                  </Pressable>
                  {autoLogs.slice(0, 30).map(log => {
                    const iconMap = {
                      saved: { icon: 'save' as const, color: Colors.green },
                      updated: { icon: 'sync' as const, color: Colors.accent },
                      skipped: { icon: 'skip-next' as const, color: Colors.textMuted },
                      error: { icon: 'error' as const, color: Colors.error },
                    };
                    const { icon, color } = iconMap[log.action];
                    const time = new Date(log.timestamp).toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' });
                    return (
                      <View key={log.id} style={styles.logItem}>
                        <MaterialIcons name={icon} size={13} color={color} />
                        <View style={styles.logItemInfo}>
                          <Text style={styles.logFilename}>{log.filename}</Text>
                          <Text style={styles.logMessage}>{log.message}</Text>
                        </View>
                        <Text style={styles.logTime}>{time}</Text>
                      </View>
                    );
                  })}
                </>
              )}
            </View>
          ) : null}
        </View>

        {/* ── Manual Parser + Auto Save ─────────────────────────────────── */}
        <View style={styles.toolCard}>
          <Pressable
            onPress={() => setActiveSection(activeSection === 'parser' ? null : 'parser')}
            style={({ pressed }) => [styles.toolHeader, pressed && { opacity: 0.8 }]}
          >
            <View style={[styles.toolIcon, { backgroundColor: Colors.deepseek + '22' }]}>
              <MaterialIcons name="auto-fix-high" size={22} color={Colors.deepseek} />
            </View>
            <View style={styles.toolInfo}>
              <Text style={styles.toolTitle}>محلل الردود + الحفظ التلقائي</Text>
              <Text style={styles.toolDesc}>الصق رداً واحفظ كوده مباشرة</Text>
            </View>
            <MaterialIcons
              name={activeSection === 'parser' ? 'keyboard-arrow-up' : 'keyboard-arrow-down'}
              size={18} color={Colors.textSecondary}
            />
          </Pressable>
          {activeSection === 'parser' ? (
            <View style={styles.toolBody}>
              <Text style={styles.inputLabel}>الصق رد DeepSeek:</Text>
              <TextInput
                style={styles.textarea}
                value={parseInput}
                onChangeText={setParseInput}
                multiline
                numberOfLines={6}
                placeholder={'مثال:\nهذا هو الكود:\n```python\nprint("hello")\n```'}
                placeholderTextColor={Colors.textMuted}
                textAlignVertical="top"
              />
              <View style={styles.parserBtns}>
                <Pressable
                  onPress={handleParseResponse}
                  style={({ pressed }) => [styles.runBtn, { backgroundColor: Colors.bgTertiary, borderWidth: 1, borderColor: Colors.border }, pressed && { opacity: 0.8 }]}
                >
                  <MaterialIcons name="search" size={14} color={Colors.textSecondary} />
                  <Text style={[styles.runBtnText, { color: Colors.textSecondary }]}>تحليل فقط</Text>
                </Pressable>
                <Pressable
                  onPress={handleAutoSaveFromText}
                  disabled={autoSaving || !parseInput.trim() || !activeProject}
                  style={({ pressed }) => [
                    styles.runBtn, { backgroundColor: Colors.green },
                    pressed && { opacity: 0.8 },
                    (autoSaving || !parseInput.trim() || !activeProject) && { opacity: 0.4 },
                  ]}
                >
                  <MaterialIcons name="bolt" size={14} color="#fff" />
                  <Text style={styles.runBtnText}>{autoSaving ? 'جاري الحفظ...' : 'حفظ تلقائي'}</Text>
                </Pressable>
              </View>
              {parseResult ? (
                <View style={styles.resultBox}>
                  <Text style={styles.resultText}>{parseResult}</Text>
                </View>
              ) : null}
            </View>
          ) : null}
        </View>

        {/* ── Import ────────────────────────────────────────────────────── */}
        <View style={styles.toolCard}>
          <Pressable
            onPress={() => setActiveSection(activeSection === 'import' ? null : 'import')}
            style={({ pressed }) => [styles.toolHeader, pressed && { opacity: 0.8 }]}
          >
            <View style={[styles.toolIcon, { backgroundColor: Colors.green + '22' }]}>
              <MaterialIcons name="upload" size={22} color={Colors.green} />
            </View>
            <View style={styles.toolInfo}>
              <Text style={styles.toolTitle}>استيراد مشروع</Text>
              <Text style={styles.toolDesc}>استورد من JSON</Text>
            </View>
            <MaterialIcons
              name={activeSection === 'import' ? 'keyboard-arrow-up' : 'keyboard-arrow-down'}
              size={18} color={Colors.textSecondary}
            />
          </Pressable>
          {activeSection === 'import' ? (
            <View style={styles.toolBody}>
              <Text style={styles.inputLabel}>الصق JSON المشروع:</Text>
              <TextInput
                style={styles.textarea}
                value={importText}
                onChangeText={setImportText}
                multiline
                numberOfLines={5}
                placeholder='{"id": "...", "name": "مشروعي", "files": [...]}'
                placeholderTextColor={Colors.textMuted}
                textAlignVertical="top"
                autoCapitalize="none"
                autoCorrect={false}
              />
              <Pressable
                onPress={handleImportProject}
                style={({ pressed }) => [styles.runBtn, { backgroundColor: Colors.green }, pressed && { opacity: 0.8 }]}
              >
                <MaterialIcons name="upload" size={16} color="#fff" />
                <Text style={styles.runBtnText}>استيراد المشروع</Text>
              </Pressable>
            </View>
          ) : null}
        </View>

        {/* ── Export ────────────────────────────────────────────────────── */}
        <Pressable
          onPress={handleExportProject}
          style={({ pressed }) => [styles.toolCard, styles.toolCardRow, pressed && { opacity: 0.8 }]}
        >
          <View style={[styles.toolIcon, { backgroundColor: Colors.yellow + '22' }]}>
            <MaterialIcons name="download" size={22} color={Colors.yellow} />
          </View>
          <View style={styles.toolInfo}>
            <Text style={styles.toolTitle}>تصدير المشروع</Text>
            <Text style={styles.toolDesc}>نسخ JSON إلى الحافظة</Text>
          </View>
          <MaterialIcons name="content-copy" size={16} color={Colors.textSecondary} />
        </Pressable>

        {/* ── Active project ────────────────────────────────────────────── */}
        {activeProject ? (
          <View style={styles.activeProjectCard}>
            <View style={[styles.activeProjectDot, { backgroundColor: activeProject.color }]} />
            <View style={styles.activeProjectInfo}>
              <Text style={styles.activeProjectLabel}>المشروع النشط</Text>
              <Text style={styles.activeProjectName}>{activeProject.name}</Text>
            </View>
            <Text style={styles.activeProjectFiles}>{activeProject.files.length} ملف</Text>
          </View>
        ) : (
          <View style={styles.noActiveProject}>
            <MaterialIcons name="info-outline" size={14} color={Colors.textMuted} />
            <Text style={styles.noActiveProjectText}>لا يوجد مشروع نشط — اختر مشروعاً من تبويب المشاريع</Text>
          </View>
        )}
      </ScrollView>

      {/* Extraction Tester Modal */}
      <ExtractionTester visible={showTester} onClose={() => setShowTester(false)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: {
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.borderSubtle,
  },
  headerTitle: { color: Colors.textPrimary, fontSize: Typography.sizes.xl, fontWeight: '700' },
  headerSub: { color: Colors.textMuted, fontSize: Typography.sizes.sm, marginTop: 2 },
  scroll: { flex: 1 },
  content: { padding: Spacing.base, paddingBottom: 60, gap: Spacing.sm },

  // Extraction tester card
  testerCard: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.bgCard, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.green + '44',
    padding: Spacing.md, overflow: 'hidden',
    ...Shadow.card,
  },
  testerGlow: {
    position: 'absolute', top: 0, left: 0, right: 0, height: 2,
    backgroundColor: Colors.green + '55',
  },
  testerLeft: { flex: 1, flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  testerIconWrap: {
    width: 48, height: 48, borderRadius: 12,
    backgroundColor: Colors.green + '22',
    alignItems: 'center', justifyContent: 'center',
    flexShrink: 0,
  },
  testerInfo: { flex: 1 },
  testerTitle: { color: Colors.green, fontSize: Typography.sizes.base, fontWeight: '700' },
  testerDesc: {
    color: Colors.textMuted, fontSize: Typography.sizes.xs,
    marginTop: 3, lineHeight: 16,
  },
  testerBadges: {
    flexDirection: 'row', flexWrap: 'wrap', gap: 4, marginTop: 6,
  },
  testerBadge: {
    backgroundColor: Colors.bgTertiary, borderRadius: 4,
    paddingHorizontal: 5, paddingVertical: 2,
    borderWidth: 1, borderColor: Colors.border,
  },
  testerBadgeText: { color: Colors.textMuted, fontSize: 9, fontFamily: 'monospace', fontWeight: '600' },

  // Auto mode card
  autoModeCard: {
    backgroundColor: Colors.bgCard, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border,
    overflow: 'hidden', ...Shadow.card,
  },
  autoModeCardActive: { borderColor: Colors.green + '55' },
  autoModeTop: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    padding: Spacing.md,
  },
  autoModeIconWrap: {
    width: 48, height: 48, borderRadius: 12,
    backgroundColor: Colors.bgTertiary,
    alignItems: 'center', justifyContent: 'center',
  },
  autoModeIconWrapActive: { backgroundColor: Colors.green + '22' },
  autoModeInfo: { flex: 1 },
  autoModeTitle: { color: Colors.textPrimary, fontSize: Typography.sizes.md, fontWeight: '700' },
  autoModeDesc: { color: Colors.textMuted, fontSize: Typography.sizes.sm, marginTop: 2 },
  autoModeStats: {
    flexDirection: 'row', alignItems: 'center',
    borderTopWidth: 1, borderTopColor: Colors.green + '33',
    backgroundColor: Colors.green + '0a', paddingVertical: Spacing.sm,
  },
  autoStatItem: { flex: 1, alignItems: 'center' },
  autoStatVal: { color: Colors.green, fontSize: Typography.sizes.lg, fontWeight: '700' },
  autoStatLabel: { color: Colors.textMuted, fontSize: Typography.sizes.xs },
  autoStatDivider: { width: 1, height: 24, backgroundColor: Colors.green + '33' },
  autoModeHint: {
    color: Colors.textMuted, fontSize: Typography.sizes.sm,
    paddingHorizontal: Spacing.md, paddingBottom: Spacing.md, lineHeight: 20,
  },

  // Tool cards
  toolCard: {
    backgroundColor: Colors.bgCard, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border, overflow: 'hidden', ...Shadow.card,
  },
  toolCardRow: { flexDirection: 'row', alignItems: 'center', padding: Spacing.md, gap: Spacing.sm },
  toolHeader: {
    flexDirection: 'row', alignItems: 'center',
    padding: Spacing.md, gap: Spacing.sm,
  },
  toolIcon: { width: 44, height: 44, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  toolInfo: { flex: 1 },
  toolTitle: { color: Colors.textPrimary, fontSize: Typography.sizes.base, fontWeight: '600' },
  toolDesc: { color: Colors.textMuted, fontSize: Typography.sizes.sm, marginTop: 2 },
  toolBody: {
    padding: Spacing.md, paddingTop: 0,
    borderTopWidth: 1, borderTopColor: Colors.borderSubtle, gap: Spacing.sm,
  },
  inputLabel: { color: Colors.textSecondary, fontSize: Typography.sizes.sm },
  textarea: {
    backgroundColor: Colors.bg, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border,
    color: Colors.textPrimary, fontSize: Typography.sizes.sm,
    fontFamily: 'monospace', padding: Spacing.sm, minHeight: 100,
  },
  parserBtns: { flexDirection: 'row', gap: Spacing.sm },
  runBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: Colors.primary, borderRadius: Radius.md,
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.sm,
    alignSelf: 'flex-start',
  },
  runBtnText: { color: '#fff', fontWeight: '600', fontSize: Typography.sizes.sm },
  resultBox: {
    backgroundColor: Colors.bg, borderRadius: Radius.sm,
    padding: Spacing.sm, borderWidth: 1, borderColor: Colors.border,
  },
  resultText: { color: Colors.textSecondary, fontFamily: 'monospace', fontSize: Typography.sizes.xs, lineHeight: 18 },

  // Log
  emptyLogText: { color: Colors.textMuted, fontSize: Typography.sizes.sm, fontStyle: 'italic', paddingVertical: Spacing.sm },
  clearBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-end' },
  clearBtnText: { color: Colors.error, fontSize: Typography.sizes.xs },
  logItem: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 7,
    paddingVertical: 5, borderBottomWidth: 1, borderBottomColor: Colors.borderSubtle,
  },
  logItemInfo: { flex: 1 },
  logFilename: { color: Colors.textPrimary, fontSize: 11, fontFamily: 'monospace', fontWeight: '500' },
  logMessage: { color: Colors.textMuted, fontSize: 10 },
  logTime: { color: Colors.textMuted, fontSize: 10, fontFamily: 'monospace' },

  // Active project
  activeProjectCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.bgCard, borderRadius: Radius.md,
    padding: Spacing.md, gap: Spacing.sm,
    borderWidth: 1, borderColor: Colors.border,
  },
  activeProjectDot: { width: 10, height: 10, borderRadius: 5 },
  activeProjectInfo: { flex: 1 },
  activeProjectLabel: { color: Colors.textMuted, fontSize: Typography.sizes.xs },
  activeProjectName: { color: Colors.textPrimary, fontSize: Typography.sizes.base, fontWeight: '600' },
  activeProjectFiles: { color: Colors.textSecondary, fontSize: Typography.sizes.sm },
  noActiveProject: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: Colors.bgSecondary, borderRadius: Radius.md,
    padding: Spacing.sm, borderWidth: 1, borderColor: Colors.borderSubtle,
  },
  noActiveProjectText: { color: Colors.textMuted, fontSize: Typography.sizes.sm, flex: 1 },
});
