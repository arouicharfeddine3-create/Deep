import React, { useState } from 'react';
import {
  View, Text, StyleSheet, Pressable, Dimensions, Switch, ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, Radius } from '@/constants/theme';
import { useProjects } from '@/hooks/useProjects';
import { FileExplorer } from '@/components/FileExplorer';
import { CodeEditor } from '@/components/CodeEditor';
import { DeepSeekView } from '@/components/DeepSeekView';

type PanelMode = 'deepseek' | 'editor' | 'split';

const { width } = Dimensions.get('window');
const isTablet = width >= 768;

export default function WorkspaceScreen() {
  const {
    activeProject, autoMode, setAutoMode,
    autoLogs, clearLogs, autoSavedCount,
  } = useProjects();
  const [panelMode, setPanelMode] = useState<PanelMode>('deepseek');
  const [showExplorer, setShowExplorer] = useState(true);
  const [showActivityLog, setShowActivityLog] = useState(false);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Toolbar */}
      <View style={styles.toolbar}>
        {/* Left: Project name */}
        <View style={styles.toolbarLeft}>
          {activeProject ? (
            <View style={styles.projectPill}>
              <View style={[styles.projectDot, { backgroundColor: activeProject.color }]} />
              <Text style={styles.projectPillText} numberOfLines={1}>{activeProject.name}</Text>
            </View>
          ) : (
            <Text style={styles.noProjectText}>اختر مشروعاً</Text>
          )}
        </View>

        {/* Center: Panel switcher */}
        <View style={styles.panelSwitcher}>
          {([
            { id: 'deepseek', icon: 'chat', label: 'AI' },
            { id: 'split', icon: 'view-column', label: '⊟' },
            { id: 'editor', icon: 'code', label: 'كود' },
          ] as const).map(tab => (
            <Pressable
              key={tab.id}
              onPress={() => setPanelMode(tab.id)}
              style={({ pressed }) => [
                styles.panelTab,
                panelMode === tab.id && styles.panelTabActive,
                pressed && { opacity: 0.8 },
              ]}
            >
              <MaterialIcons
                name={tab.icon}
                size={14}
                color={panelMode === tab.id ? Colors.accent : Colors.textMuted}
              />
            </Pressable>
          ))}
        </View>

        {/* Right: Auto mode + Explorer + Log */}
        <View style={styles.toolbarRight}>
          {/* Auto Mode Toggle */}
          <Pressable
            onPress={() => setAutoMode(!autoMode)}
            style={({ pressed }) => [
              styles.autoModeBtn,
              autoMode && styles.autoModeBtnActive,
              pressed && { opacity: 0.8 },
            ]}
            hitSlop={4}
          >
            <MaterialIcons
              name="bolt"
              size={14}
              color={autoMode ? Colors.green : Colors.textMuted}
            />
            <Text style={[styles.autoModeBtnText, autoMode && { color: Colors.green }]}>
              {autoMode ? 'تلقائي' : 'يدوي'}
            </Text>
          </Pressable>

          {/* Activity log */}
          <Pressable
            onPress={() => setShowActivityLog(!showActivityLog)}
            style={({ pressed }) => [
              styles.toolbarIconBtn,
              showActivityLog && styles.toolbarIconBtnActive,
              pressed && { opacity: 0.7 },
            ]}
            hitSlop={8}
          >
            <MaterialIcons
              name="history"
              size={17}
              color={showActivityLog ? Colors.accent : Colors.textSecondary}
            />
            {autoLogs.length > 0 ? (
              <View style={styles.logBadge}>
                <Text style={styles.logBadgeText}>
                  {autoLogs.length > 9 ? '9+' : autoLogs.length}
                </Text>
              </View>
            ) : null}
          </Pressable>

          {/* Explorer toggle */}
          <Pressable
            onPress={() => setShowExplorer(!showExplorer)}
            style={({ pressed }) => [
              styles.toolbarIconBtn,
              showExplorer && styles.toolbarIconBtnActive,
              pressed && { opacity: 0.7 },
            ]}
            hitSlop={8}
          >
            <MaterialIcons
              name="account-tree"
              size={17}
              color={showExplorer ? Colors.accent : Colors.textSecondary}
            />
          </Pressable>
        </View>
      </View>

      {/* Auto Mode Banner */}
      {autoMode && activeProject ? (
        <View style={styles.autoBanner}>
          <View style={styles.autoBannerDot} />
          <Text style={styles.autoBannerText}>
            المود التلقائي نشط — سيتم حفظ كل كود من DeepSeek تلقائياً في <Text style={{ color: activeProject.color }}>{activeProject.name}</Text>
          </Text>
          {autoSavedCount > 0 ? (
            <View style={styles.autoBannerCount}>
              <Text style={styles.autoBannerCountText}>{autoSavedCount}</Text>
            </View>
          ) : null}
        </View>
      ) : null}

      {/* Activity Log Panel */}
      {showActivityLog ? (
        <View style={styles.activityLog}>
          <View style={styles.activityLogHeader}>
            <MaterialIcons name="history" size={14} color={Colors.accent} />
            <Text style={styles.activityLogTitle}>سجل النشاط</Text>
            <Text style={styles.activityLogCount}>{autoLogs.length} عملية</Text>
            <Pressable onPress={clearLogs} hitSlop={8} style={({ pressed }) => [pressed && { opacity: 0.7 }]}>
              <Text style={styles.clearLogsText}>مسح</Text>
            </Pressable>
          </View>
          {autoLogs.length === 0 ? (
            <Text style={styles.activityLogEmpty}>لا توجد عمليات بعد</Text>
          ) : (
            <ScrollView style={styles.activityLogList} showsVerticalScrollIndicator={false}>
              {autoLogs.slice(0, 20).map(log => {
                const iconMap = {
                  saved: { icon: 'save' as const, color: Colors.green },
                  updated: { icon: 'sync' as const, color: Colors.accent },
                  skipped: { icon: 'skip-next' as const, color: Colors.textMuted },
                  error: { icon: 'error' as const, color: Colors.error },
                };
                const { icon, color } = iconMap[log.action];
                const time = new Date(log.timestamp).toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                return (
                  <View key={log.id} style={styles.activityLogItem}>
                    <MaterialIcons name={icon} size={13} color={color} />
                    <View style={styles.activityLogItemInfo}>
                      <Text style={styles.activityLogItemFile} numberOfLines={1}>{log.filename}</Text>
                      <Text style={styles.activityLogItemMsg}>{log.message}</Text>
                    </View>
                    <Text style={styles.activityLogItemTime}>{time}</Text>
                  </View>
                );
              })}
            </ScrollView>
          )}
        </View>
      ) : null}

      {/* Main area */}
      <View style={styles.mainArea}>
        {showExplorer ? (
          <View style={styles.explorerPanel}>
            <FileExplorer />
          </View>
        ) : null}

        <View style={styles.contentArea}>
          {panelMode === 'deepseek' && <DeepSeekView />}
          {panelMode === 'editor' && <CodeEditor />}
          {panelMode === 'split' && (
            <View style={styles.splitView}>
              <View style={styles.splitLeft}><DeepSeekView /></View>
              <View style={styles.splitDivider} />
              <View style={styles.splitRight}><CodeEditor /></View>
            </View>
          )}
        </View>
      </View>

      {/* No project banner */}
      {!activeProject ? (
        <View style={styles.noProjectBanner}>
          <MaterialIcons name="info-outline" size={16} color={Colors.yellow} />
          <Text style={styles.noProjectBannerText}>اختر مشروعاً من تبويب المشاريع لحفظ الملفات</Text>
        </View>
      ) : null}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },

  toolbar: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.bgSecondary,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    paddingHorizontal: Spacing.sm, paddingVertical: 6,
    gap: Spacing.sm, height: 44,
  },
  toolbarLeft: { flex: 1 },
  toolbarRight: { flexDirection: 'row', alignItems: 'center', gap: 4 },

  projectPill: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: Colors.bgTertiary, borderRadius: Radius.full,
    paddingHorizontal: Spacing.sm, paddingVertical: 3,
    borderWidth: 1, borderColor: Colors.border, alignSelf: 'flex-start',
  },
  projectDot: { width: 7, height: 7, borderRadius: 3.5 },
  projectPillText: {
    color: Colors.textSecondary, fontSize: Typography.sizes.xs,
    fontWeight: '500', maxWidth: 90,
  },
  noProjectText: { color: Colors.textMuted, fontSize: Typography.sizes.xs },

  panelSwitcher: {
    flexDirection: 'row',
    backgroundColor: Colors.bgTertiary, borderRadius: Radius.md,
    padding: 2, borderWidth: 1, borderColor: Colors.borderSubtle,
  },
  panelTab: {
    alignItems: 'center', justifyContent: 'center',
    width: 30, height: 26, borderRadius: Radius.sm,
  },
  panelTabActive: { backgroundColor: Colors.bgCard },

  autoModeBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: Colors.bgTertiary, borderRadius: Radius.md,
    paddingHorizontal: 7, paddingVertical: 4,
    borderWidth: 1, borderColor: Colors.borderSubtle,
  },
  autoModeBtnActive: {
    backgroundColor: Colors.green + '18',
    borderColor: Colors.green + '55',
  },
  autoModeBtnText: { color: Colors.textMuted, fontSize: 10, fontWeight: '600' },

  toolbarIconBtn: {
    width: 30, height: 30, alignItems: 'center', justifyContent: 'center',
    borderRadius: Radius.sm,
  },
  toolbarIconBtnActive: { backgroundColor: Colors.accentGlow },

  logBadge: {
    position: 'absolute', top: 2, right: 2,
    backgroundColor: Colors.accent, borderRadius: 6,
    minWidth: 12, height: 12, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 2,
  },
  logBadgeText: { color: '#fff', fontSize: 8, fontWeight: '700' },

  // Auto banner
  autoBanner: {
    flexDirection: 'row', alignItems: 'center', gap: 7,
    backgroundColor: Colors.green + '14',
    borderBottomWidth: 1, borderBottomColor: Colors.green + '33',
    paddingHorizontal: Spacing.base, paddingVertical: 5,
  },
  autoBannerDot: {
    width: 7, height: 7, borderRadius: 3.5,
    backgroundColor: Colors.green,
  },
  autoBannerText: { color: Colors.green, fontSize: 11, flex: 1, lineHeight: 16 },
  autoBannerCount: {
    backgroundColor: Colors.green, borderRadius: 10,
    paddingHorizontal: 7, paddingVertical: 1,
  },
  autoBannerCountText: { color: '#fff', fontSize: 10, fontWeight: '700' },

  // Activity log
  activityLog: {
    maxHeight: 180,
    backgroundColor: Colors.bgSecondary,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  activityLogHeader: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: Spacing.sm, paddingVertical: 6,
    borderBottomWidth: 1, borderBottomColor: Colors.borderSubtle,
  },
  activityLogTitle: { color: Colors.textSecondary, fontSize: Typography.sizes.sm, fontWeight: '600', flex: 1 },
  activityLogCount: { color: Colors.textMuted, fontSize: Typography.sizes.xs },
  clearLogsText: { color: Colors.error, fontSize: Typography.sizes.xs },
  activityLogEmpty: {
    color: Colors.textMuted, fontSize: Typography.sizes.sm,
    textAlign: 'center', padding: Spacing.md,
  },
  activityLogList: { maxHeight: 130 },
  activityLogItem: {
    flexDirection: 'row', alignItems: 'center', gap: 7,
    paddingHorizontal: Spacing.sm, paddingVertical: 5,
    borderBottomWidth: 1, borderBottomColor: Colors.borderSubtle,
  },
  activityLogItemInfo: { flex: 1 },
  activityLogItemFile: {
    color: Colors.textPrimary, fontSize: 11,
    fontFamily: 'monospace', fontWeight: '500',
  },
  activityLogItemMsg: { color: Colors.textMuted, fontSize: 10 },
  activityLogItemTime: { color: Colors.textMuted, fontSize: 10, fontFamily: 'monospace' },

  // Main layout
  mainArea: { flex: 1, flexDirection: 'row' },
  explorerPanel: { width: 175, borderRightWidth: 1, borderRightColor: Colors.border },
  contentArea: { flex: 1 },

  splitView: { flex: 1, flexDirection: 'row' },
  splitLeft: { flex: 1 },
  splitDivider: { width: 2, backgroundColor: Colors.border },
  splitRight: { flex: 1 },

  noProjectBanner: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: Colors.yellow + '18',
    borderTopWidth: 1, borderTopColor: Colors.yellow + '44',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.sm,
  },
  noProjectBannerText: { color: Colors.yellow, fontSize: Typography.sizes.xs, flex: 1 },
});
