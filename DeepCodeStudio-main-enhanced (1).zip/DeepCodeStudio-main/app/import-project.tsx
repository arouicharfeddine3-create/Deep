import React, { useState } from 'react';
import {
  View, Text, TextInput, StyleSheet, Pressable,
  KeyboardAvoidingView, Platform, ScrollView,
} from 'react-native';
import { useRouter } from 'expo-router';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, Radius } from '@/constants/theme';
import { useProjects } from '@/hooks/useProjects';
import { useAlert } from '@/template';

export default function ImportProjectScreen() {
  const router = useRouter();
  const { importProject, setActiveProject } = useProjects();
  const { showAlert } = useAlert();
  const [jsonText, setJsonText] = useState('');
  const [loading, setLoading] = useState(false);

  const handleImport = async () => {
    if (!jsonText.trim()) {
      showAlert('تنبيه', 'أدخل JSON المشروع');
      return;
    }
    setLoading(true);
    try {
      const project = await importProject(jsonText.trim());
      setActiveProject(project);
      showAlert('تم الاستيراد', `تم استيراد "${project.name}" بنجاح`, [
        { text: 'فتح المشروع', onPress: () => router.replace('/(tabs)/workspace') },
        { text: 'حسناً', onPress: () => router.back() },
      ]);
    } catch {
      showAlert('خطأ في الاستيراد', 'تأكد من صحة JSON وأن الملف مصدر من DeepCode Studio');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.iconWrap}>
          <MaterialIcons name="upload-file" size={48} color={Colors.green} />
        </View>
        <Text style={styles.title}>استيراد مشروع</Text>
        <Text style={styles.subtitle}>الصق JSON مشروع مُصدَّر من DeepCode Studio</Text>

        {/* Info box */}
        <View style={styles.infoBox}>
          <MaterialIcons name="info-outline" size={16} color={Colors.accent} />
          <Text style={styles.infoText}>
            يمكنك تصدير مشروع من تبويب "الأدوات" ثم استيراده هنا أو مشاركته مع الآخرين
          </Text>
        </View>

        {/* JSON Input */}
        <View style={styles.fieldGroup}>
          <Text style={styles.label}>JSON المشروع</Text>
          <TextInput
            style={styles.textarea}
            value={jsonText}
            onChangeText={setJsonText}
            multiline
            numberOfLines={12}
            placeholder={'{\n  "name": "اسم المشروع",\n  "files": [...]\n}'}
            placeholderTextColor={Colors.textMuted}
            textAlignVertical="top"
            autoCapitalize="none"
            autoCorrect={false}
            fontFamily="monospace"
          />
        </View>

        <Pressable
          onPress={handleImport}
          disabled={loading || !jsonText.trim()}
          style={({ pressed }) => [
            styles.importBtn,
            pressed && { opacity: 0.85 },
            (!jsonText.trim() || loading) && styles.importBtnDisabled,
          ]}
        >
          <MaterialIcons name="upload" size={20} color="#fff" />
          <Text style={styles.importBtnText}>{loading ? 'جاري الاستيراد...' : 'استيراد المشروع'}</Text>
        </Pressable>

        <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.cancelBtn, pressed && { opacity: 0.7 }]}>
          <Text style={styles.cancelBtnText}>إلغاء</Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  content: { padding: Spacing.base, paddingBottom: Spacing.xxxl },

  iconWrap: {
    width: 80, height: 80, borderRadius: 20,
    backgroundColor: Colors.green + '22',
    alignItems: 'center', justifyContent: 'center',
    alignSelf: 'center', marginTop: Spacing.lg, marginBottom: Spacing.md,
  },
  title: {
    color: Colors.textPrimary, fontSize: Typography.sizes.xxl,
    fontWeight: Typography.weights.bold, textAlign: 'center', marginBottom: 6,
  },
  subtitle: {
    color: Colors.textMuted, fontSize: Typography.sizes.base,
    textAlign: 'center', marginBottom: Spacing.lg,
  },

  infoBox: {
    flexDirection: 'row', gap: Spacing.sm, alignItems: 'flex-start',
    backgroundColor: Colors.accentGlow, borderRadius: Radius.md,
    padding: Spacing.md, marginBottom: Spacing.lg,
    borderWidth: 1, borderColor: Colors.accent + '44',
  },
  infoText: { color: Colors.textSecondary, fontSize: Typography.sizes.sm, flex: 1, lineHeight: 20 },

  fieldGroup: { marginBottom: Spacing.lg },
  label: { color: Colors.textSecondary, fontSize: Typography.sizes.sm, marginBottom: 8, fontWeight: Typography.weights.medium },
  textarea: {
    backgroundColor: Colors.bgSecondary, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border,
    color: Colors.textPrimary, fontSize: Typography.sizes.sm,
    fontFamily: 'monospace', padding: Spacing.sm,
    minHeight: 200,
  },

  importBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: Colors.green, borderRadius: Radius.md,
    paddingVertical: Spacing.md, marginBottom: Spacing.sm,
  },
  importBtnDisabled: { opacity: 0.45 },
  importBtnText: { color: '#fff', fontSize: Typography.sizes.md, fontWeight: Typography.weights.bold },
  cancelBtn: { alignItems: 'center', paddingVertical: Spacing.sm },
  cancelBtnText: { color: Colors.textMuted, fontSize: Typography.sizes.base },
});
