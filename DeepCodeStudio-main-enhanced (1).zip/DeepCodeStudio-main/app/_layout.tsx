import { AlertProvider } from '@/template';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Stack } from 'expo-router';
import { ProjectProvider } from '@/contexts/ProjectContext';
import { StatusBar } from 'expo-status-bar';

export default function RootLayout() {
  return (
    <AlertProvider>
      <SafeAreaProvider>
        <ProjectProvider>
          <StatusBar style="light" backgroundColor="#0d1117" />
          <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: '#0d1117' } }}>
            <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
            <Stack.Screen
              name="new-project"
              options={{
                headerShown: true,
                headerTitle: 'مشروع جديد',
                headerStyle: { backgroundColor: '#161b22' },
                headerTintColor: '#e6edf3',
                headerTitleStyle: { fontWeight: '600' },
                presentation: 'modal',
              }}
            />
            <Stack.Screen
              name="import-project"
              options={{
                headerShown: true,
                headerTitle: 'استيراد مشروع',
                headerStyle: { backgroundColor: '#161b22' },
                headerTintColor: '#e6edf3',
                presentation: 'modal',
              }}
            />
          </Stack>
        </ProjectProvider>
      </SafeAreaProvider>
    </AlertProvider>
  );
}
