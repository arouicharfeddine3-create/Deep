import React, { useState } from 'react';
import {
  View, Text, TextInput, StyleSheet, Pressable, ScrollView,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, Radius } from '@/constants/theme';
import { useProjects } from '@/hooks/useProjects';
import { useAlert } from '@/template';

const TEMPLATES = [
  { id: 'blank', name: 'مشروع فارغ', icon: 'insert-drive-file' as const, desc: 'ابدأ من الصفر' },
  { id: 'web', name: 'تطبيق ويب', icon: 'web' as const, desc: 'HTML/CSS/JS' },
  { id: 'python', name: 'Python Script', icon: 'code' as const, desc: 'نصوص Python' },
  { id: 'api', name: 'REST API', icon: 'api' as const, desc: 'نقاط نهاية API' },
  { id: 'mobile', name: 'تطبيق موبايل', icon: 'smartphone' as const, desc: 'React Native' },
];

const PROJECT_COLORS = ['#2f81f7', '#3fb950', '#d29922', '#bc8cff', '#f85149', '#4d6aff', '#39d353'];

export default function NewProjectScreen() {
  const router = useRouter();
  const { createProject, setActiveProject } = useProjects();
  const { showAlert } = useAlert();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState('blank');
  const [loading, setLoading] = useState(false);

  const handleCreate = async () => {
    if (!name.trim()) {
      showAlert('تنبيه', 'أدخل اسم المشروع');
      return;
    }
    setLoading(true);
    try {
      const project = await createProject(name.trim(), description.trim());
      setActiveProject(project);
      router.replace('/(tabs)/workspace');
    } catch {
      showAlert('خطأ', 'فشل في إنشاء المشروع');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Icon */}
        <View style={styles.iconWrap}>
          <MaterialIcons name="create-new-folder" size={48} color={Colors.accent} />
        </View>
        <Text style={styles.title}>مشروع جديد</Text>
        <Text style={styles.subtitle}>أنشئ مشروعاً لحفظ ملفات DeepSeek</Text>

        {/* Name */}
        <View style={styles.fieldGroup}>
          <Text style={styles.label}>اسم المشروع *</Text>
          <TextInput
            style={styles.input}
            value={name}
            onChangeText={setName}
            placeholder="مثال: تطبيق المهام"
            placeholderTextColor={Colors.textMuted}
            autoFocus
            returnKeyType="next"
          />
        </View>

        {/* Description */}
        <View style={styles.fieldGroup}>
          <Text style={styles.label}>وصف المشروع (اختياري)</Text>
          <TextInput
            style={[styles.input, styles.textarea]}
            value={description}
            onChangeText={setDescription}
            placeholder="وصف مختصر للمشروع..."
            placeholderTextColor={Colors.textMuted}
            multiline
            numberOfLines={3}
            textAlignVertical="top"
          />
        </View>

        {/* Template */}
        <View style={styles.fieldGroup}>
          <Text style={styles.label}>النوع</Text>
          <View style={styles.templatesGrid}>
            {TEMPLATES.map(tmpl => (
              <Pressable
                key={tmpl.id}
                onPress={() => setSelectedTemplate(tmpl.id)}
                style={({ pressed }) => [
                  styles.templateCard,
                  selectedTemplate === tmpl.id && styles.templateCardSelected,
                  pressed && { opacity: 0.8 },
                ]}
              >
                <MaterialIcons
                  name={tmpl.icon}
                  size={20}
                  color={selectedTemplate === tmpl.id ? Colors.accent : Colors.textSecondary}
                />
                <Text style={[styles.templateName, selectedTemplate === tmpl.id && styles.templateNameSelected]}>
                  {tmpl.name}
                </Text>
                <Text style={styles.templateDesc}>{tmpl.desc}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Create button */}
        <Pressable
          onPress={handleCreate}
          disabled={loading || !name.trim()}
          style={({ pressed }) => [
            styles.createBtn,
            pressed && { opacity: 0.85 },
            (!name.trim() || loading) && styles.createBtnDisabled,
          ]}
        >
          <MaterialIcons name="add-circle" size={20} color="#fff" />
          <Text style={styles.createBtnText}>{loading ? 'جاري الإنشاء...' : 'إنشاء المشروع'}</Text>
        </Pressable>

        <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.cancelBtn, pressed && { opacity: 0.7 }]}>
          <Text style={styles.cancelBtnText}>إلغاء</Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  content: { padding: Spacing.base, paddingBottom: Spacing.xxxl },

  iconWrap: {
    width: 80, height: 80, borderRadius: 20,
    backgroundColor: Colors.accentGlow,
    alignItems: 'center', justifyContent: 'center',
    alignSelf: 'center', marginTop: Spacing.lg, marginBottom: Spacing.md,
  },
  title: {
    color: Colors.textPrimary, fontSize: Typography.sizes.xxl,
    fontWeight: Typography.weights.bold, textAlign: 'center', marginBottom: 6,
  },
  subtitle: {
    color: Colors.textMuted, fontSize: Typography.sizes.base,
    textAlign: 'center', marginBottom: Spacing.xl,
  },

  fieldGroup: { marginBottom: Spacing.lg },
  label: { color: Colors.textSecondary, fontSize: Typography.sizes.sm, marginBottom: 8, fontWeight: Typography.weights.medium },
  input: {
    backgroundColor: Colors.bgSecondary, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border,
    color: Colors.textPrimary, fontSize: Typography.sizes.base,
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md, height: 48,
  },
  textarea: { height: 80, paddingTop: Spacing.sm },

  templatesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  templateCard: {
    width: '30%', backgroundColor: Colors.bgSecondary,
    borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border,
    padding: Spacing.sm, alignItems: 'center', gap: 4,
  },
  templateCardSelected: { borderColor: Colors.accent, backgroundColor: Colors.accentGlow },
  templateName: { color: Colors.textSecondary, fontSize: Typography.sizes.xs, fontWeight: Typography.weights.medium, textAlign: 'center' },
  templateNameSelected: { color: Colors.accent },
  templateDesc: { color: Colors.textMuted, fontSize: 10, textAlign: 'center' },

  createBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: Colors.primary, borderRadius: Radius.md,
    paddingVertical: Spacing.md, marginBottom: Spacing.sm,
  },
  createBtnDisabled: { opacity: 0.45 },
  createBtnText: { color: '#fff', fontSize: Typography.sizes.md, fontWeight: Typography.weights.bold },
  cancelBtn: { alignItems: 'center', paddingVertical: Spacing.sm },
  cancelBtnText: { color: Colors.textMuted, fontSize: Typography.sizes.base },
});
