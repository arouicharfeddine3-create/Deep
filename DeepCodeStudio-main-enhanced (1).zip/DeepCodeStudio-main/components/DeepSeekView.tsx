import React, { useRef, useState, useCallback, useEffect } from 'react';
import {
  View, Text, StyleSheet, Platform, Pressable,
  TextInput, Animated, ScrollView,
} from 'react-native';
import { WebView } from 'react-native-webview';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius } from '@/constants/theme';
import { parseCodeBlocks, buildInjectedJS, DEFAULT_SELECTORS, SelectorConfig, ExtractedCodeBlock } from '@/services/responseParser';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ResponsePanel } from '@/components/ResponsePanel';
import { useProjects } from '@/hooks/useProjects';
import { autoSaveBlocks } from '@/services/autoModeService';

const HOME_URL = 'https://chat.deepseek.com';
const SELECTORS_KEY = '@deepcode_selectors_v1';

// ─── Element Picker JS ────────────────────────────────────────────────────────
function buildPickerJS(fieldKey: string): string {
  return `
(function() {
  if (window.__deepcodePicker) {
    window.__deepcodePicker.cancel();
  }

  var overlay = null;
  var tooltip = null;
  var lastEl = null;

  function generateSelector(el) {
    try {
      if (el.id && !/^[0-9]/.test(el.id)) {
        return '#' + CSS.escape(el.id);
      }
      var tag = el.tagName.toLowerCase();
      var role = el.getAttribute('role');
      var roleAttr = role ? '[role="' + role + '"]' : '';
      var classes = Array.from(el.classList)
        .filter(function(c) {
          return c.length > 1 && !/^_[a-z0-9]{5,}$/.test(c) && !/^[0-9]/.test(c);
        })
        .slice(0, 3)
        .map(function(c) { return '.' + c; })
        .join('');
      var aria = el.getAttribute('aria-label');
      var ariaAttr = aria ? '[aria-label*="' + aria.slice(0, 20).replace(/"/g, '') + '"]' : '';
      var type = el.getAttribute('type');
      var typeAttr = type ? '[type="' + type + '"]' : '';
      var placeholder = el.getAttribute('placeholder');
      var placeholderAttr = placeholder ? '[placeholder*="' + placeholder.slice(0, 20).replace(/"/g, '') + '"]' : '';
      var sel = tag + classes + roleAttr + ariaAttr + typeAttr + placeholderAttr;
      var matches = document.querySelectorAll(sel);
      if (matches.length === 1) return sel;
      var parent = el.parentElement;
      if (parent) {
        var parentCls = Array.from(parent.classList)
          .filter(function(c) { return c.length > 1 && !/^_[a-z0-9]{5,}$/.test(c); })
          .slice(0, 2).map(function(c) { return '.' + c; }).join('');
        var parentRole = parent.getAttribute('role');
        var parentTag = parent.tagName.toLowerCase();
        var parentSel = parent.id ? '#' + CSS.escape(parent.id) : parentTag + parentCls + (parentRole ? '[role="' + parentRole + '"]' : '');
        var combined = parentSel + ' > ' + sel;
        if (document.querySelectorAll(combined).length <= 3) return combined;
      }
      if (parent) {
        var siblings = Array.from(parent.children).filter(function(c) { return c.tagName === el.tagName; });
        var idx = siblings.indexOf(el) + 1;
        return sel + ':nth-of-type(' + idx + ')';
      }
      return sel;
    } catch(e) {
      return el.tagName.toLowerCase();
    }
  }

  function createOverlay() {
    overlay = document.createElement('div');
    overlay.id = '__deepcode_picker_overlay';
    overlay.style.cssText = [
      'position:fixed', 'top:0', 'left:0', 'right:0', 'bottom:0',
      'z-index:2147483646', 'cursor:crosshair', 'pointer-events:none',
    ].join(';');
    tooltip = document.createElement('div');
    tooltip.style.cssText = [
      'position:fixed', 'top:8px', 'left:50%', 'transform:translateX(-50%)',
      'background:rgba(13,17,23,0.95)',
      'border:1.5px solid #4d6aff',
      'border-radius:20px',
      'padding:6px 16px',
      'font-family:monospace',
      'font-size:12px',
      'color:#e6edf3',
      'white-space:nowrap',
      'z-index:2147483647',
      'pointer-events:none',
      'box-shadow:0 4px 20px rgba(77,106,255,0.4)',
      'max-width:90vw',
      'overflow:hidden',
      'text-overflow:ellipsis',
    ].join(';');
    tooltip.textContent = 'انقر على عنصر لاختياره';
    document.body.appendChild(overlay);
    document.body.appendChild(tooltip);
  }

  function highlight(el) {
    if (lastEl) {
      lastEl.style.outline = lastEl.__prevOutline || '';
      lastEl.style.outlineOffset = lastEl.__prevOutlineOffset || '';
    }
    lastEl = el;
    el.__prevOutline = el.style.outline;
    el.__prevOutlineOffset = el.style.outlineOffset;
    el.style.outline = '2px solid #4d6aff';
    el.style.outlineOffset = '2px';
    var sel = generateSelector(el);
    tooltip.textContent = sel;
  }

  function removeHighlight() {
    if (lastEl) {
      lastEl.style.outline = lastEl.__prevOutline || '';
      lastEl.style.outlineOffset = lastEl.__prevOutlineOffset || '';
      lastEl = null;
    }
  }

  function onMouseMove(e) {
    var el = e.target;
    if (!el || el === overlay || el === tooltip) return;
    highlight(el);
  }

  function onTouchMove(e) {
    var touch = e.touches[0];
    overlay.style.display = 'none';
    var el = document.elementFromPoint(touch.clientX, touch.clientY);
    overlay.style.display = '';
    if (!el || el === tooltip) return;
    highlight(el);
  }

  function onClick(e) {
    e.preventDefault();
    e.stopPropagation();
    var el = e.target;
    if (!el || el === overlay || el === tooltip) return;
    var sel = generateSelector(el);
    window.ReactNativeWebView.postMessage(JSON.stringify({
      type: 'SELECTOR_PICKED',
      fieldKey: '${fieldKey}',
      selector: sel,
      tag: el.tagName,
      timestamp: Date.now()
    }));
    cancel();
  }

  function onTouchEnd(e) {
    e.preventDefault();
    e.stopPropagation();
    var touch = e.changedTouches[0];
    overlay.style.display = 'none';
    var el = document.elementFromPoint(touch.clientX, touch.clientY);
    overlay.style.display = '';
    if (!el || el === tooltip) return;
    var sel = generateSelector(el);
    window.ReactNativeWebView.postMessage(JSON.stringify({
      type: 'SELECTOR_PICKED',
      fieldKey: '${fieldKey}',
      selector: sel,
      tag: el.tagName,
      timestamp: Date.now()
    }));
    cancel();
  }

  function onKeyDown(e) {
    if (e.key === 'Escape') cancel();
  }

  function cancel() {
    removeHighlight();
    if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
    if (tooltip && tooltip.parentNode) tooltip.parentNode.removeChild(tooltip);
    document.removeEventListener('mousemove', onMouseMove, true);
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('touchmove', onTouchMove, { capture: true });
    document.removeEventListener('touchend', onTouchEnd, { capture: true });
    document.removeEventListener('keydown', onKeyDown, true);
    window.__deepcodePicker = null;
    window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'PICKER_CANCELLED', fieldKey: '${fieldKey}' }));
  }

  createOverlay();
  document.addEventListener('mousemove', onMouseMove, true);
  document.addEventListener('click', onClick, true);
  document.addEventListener('touchmove', onTouchMove, { capture: true, passive: false });
  document.addEventListener('touchend', onTouchEnd, { capture: true, passive: false });
  document.addEventListener('keydown', onKeyDown, true);

  window.__deepcodePicker = { cancel: cancel };
})();
true;
`;
}

// ─── Selector Settings Panel ──────────────────────────────────────────────────

interface SelectorSettingsProps {
  config: SelectorConfig;
  onSave: (cfg: SelectorConfig) => void;
  onClose: () => void;
  onInspect: (sel: string, label: string) => void;
  onStartPick: (fieldKey: keyof SelectorConfig) => void;
  onCancelPick: () => void;
  inspectResult: InspectResult | null;
  pickingField: keyof SelectorConfig | null;
  pickedValues: Partial<SelectorConfig>;
}

interface InspectResult {
  selector: string;
  count: number;
  elements?: { tag: string; cls: string; text: string; visible: boolean }[];
  error?: string;
}

const SEL_FIELDS: { key: keyof SelectorConfig; label: string; hint: string; icon: keyof typeof MaterialIcons.glyphMap; color: string }[] = [
  { key: 'sendBtn',           label: 'زر الإرسال (بداية التوليد)', hint: 'مثال: div[role="button"].ds-icon-button', icon: 'send',       color: Colors.green },
  { key: 'stopBtn',           label: 'زر الإيقاف (نهاية التوليد)', hint: 'مثال: div.ds-icon-button._7436101',      icon: 'stop',       color: Colors.red },
  { key: 'codeBlock',         label: 'كتل الكود (الاستخراج)',      hint: 'مثال: pre code',                         icon: 'code',       color: Colors.accent },
  { key: 'responseContainer', label: 'حاوية الرد (السياق)',         hint: 'مثال: .markdown-body',                   icon: 'smart-toy',  color: Colors.deepseek },
];

function SelectorSettings({
  config, onSave, onClose, onInspect, onStartPick, onCancelPick,
  inspectResult, pickingField, pickedValues,
}: SelectorSettingsProps) {
  const [draft, setDraft] = React.useState<SelectorConfig>({ ...config });
  const slideAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!pickedValues) return;
    const key = Object.keys(pickedValues)[0] as keyof SelectorConfig | undefined;
    if (key && pickedValues[key]) {
      setDraft(prev => ({ ...prev, [key]: pickedValues[key]! }));
    }
  }, [pickedValues]);

  useEffect(() => {
    Animated.spring(slideAnim, { toValue: 1, useNativeDriver: true, tension: 130, friction: 10 }).start();
  }, []);

  const close = () => {
    Animated.timing(slideAnim, { toValue: 0, duration: 180, useNativeDriver: true }).start(onClose);
  };

  const save = () => { onSave(draft); close(); };
  const reset = () => setDraft({ ...DEFAULT_SELECTORS });

  const translateY = slideAnim.interpolate({ inputRange: [0, 1], outputRange: [60, 0] });

  return (
    <Animated.View style={[ssStyles.container, { opacity: slideAnim, transform: [{ translateY }] }]}>
      {/* Header */}
      <View style={ssStyles.header}>
        <MaterialIcons name="tune" size={15} color={Colors.accent} />
        <Text style={ssStyles.title}>ضبط Selectors</Text>
        <Pressable onPress={reset} hitSlop={8} style={({ pressed }) => [ssStyles.resetBtn, pressed && { opacity: 0.7 }]}>
          <MaterialIcons name="restore" size={13} color={Colors.yellow} />
          <Text style={ssStyles.resetText}>إعادة تعيين</Text>
        </Pressable>
        <Pressable onPress={close} hitSlop={8} style={({ pressed }) => [pressed && { opacity: 0.6 }]}>
          <MaterialIcons name="close" size={18} color={Colors.textSecondary} />
        </Pressable>
      </View>

      <ScrollView style={ssStyles.scroll} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        {/* Info */}
        <View style={ssStyles.infoBox}>
          <MaterialIcons name="touch-app" size={12} color={Colors.accent} />
          <Text style={ssStyles.infoText}>
            اضغط 👆 لاختيار عنصر بلمسه في الصفحة مباشرة (ستُخفى هذه اللوحة تلقائياً). اضغط 🔍 لاختبار selector يدوياً.
          </Text>
        </View>

        {SEL_FIELDS.map(f => {
          const isInspected = inspectResult?.selector === draft[f.key];
          const isPicking = pickingField === f.key;

          return (
            <View key={f.key} style={[ssStyles.field, isPicking && ssStyles.fieldPicking]}>
              <View style={ssStyles.fieldLabel}>
                <MaterialIcons name={f.icon} size={12} color={f.color} />
                <Text style={[ssStyles.fieldLabelText, { color: f.color }]}>{f.label}</Text>
                {isPicking ? (
                  <View style={ssStyles.pickingBadge}>
                    <Text style={ssStyles.pickingBadgeText}>جاري الاختيار...</Text>
                  </View>
                ) : null}
              </View>
              <View style={ssStyles.inputRow}>
                <TextInput
                  style={ssStyles.input}
                  value={draft[f.key]}
                  onChangeText={v => setDraft(prev => ({ ...prev, [f.key]: v }))}
                  placeholder={f.hint}
                  placeholderTextColor={Colors.textMuted}
                  autoCapitalize="none"
                  autoCorrect={false}
                  multiline
                />
                {/* Pick button — hides panel and opens WebView for picking */}
                <Pressable
                  onPress={() => onStartPick(f.key)}
                  hitSlop={6}
                  style={({ pressed }) => [
                    ssStyles.pickBtn,
                    isPicking && ssStyles.pickBtnActive,
                    pressed && { opacity: 0.7 },
                  ]}
                >
                  <MaterialIcons name="touch-app" size={15} color={isPicking ? Colors.yellow : f.color} />
                </Pressable>
                {/* Inspect button */}
                <Pressable
                  onPress={() => onInspect(draft[f.key], f.label)}
                  hitSlop={6}
                  style={({ pressed }) => [ssStyles.inspectBtn, pressed && { opacity: 0.7 }]}
                >
                  <Text style={ssStyles.inspectBtnText}>🔍</Text>
                </Pressable>
              </View>

              {isInspected ? (
                <View style={[
                  ssStyles.inspectResult,
                  { borderColor: (inspectResult!.count > 0 ? Colors.green : Colors.red) + '44' },
                ]}>
                  {inspectResult!.error ? (
                    <Text style={[ssStyles.inspectCount, { color: Colors.red }]}>⛔ خطأ: {inspectResult!.error}</Text>
                  ) : (
                    <>
                      <Text style={[
                        ssStyles.inspectCount,
                        { color: inspectResult!.count > 0 ? Colors.green : Colors.red },
                      ]}>
                        {inspectResult!.count > 0 ? `✅ ${inspectResult!.count} عنصر` : '❌ لا يوجد عنصر'}
                      </Text>
                      {(inspectResult!.elements || []).map((el, i) => (
                        <Text key={i} style={ssStyles.inspectEl}>
                          {'<'}{el.tag.toLowerCase()}{el.cls ? ` class="${el.cls}"` : ''}{'>'} {el.text || '(فارغ)'} {el.visible ? '👁' : '🙈'}
                        </Text>
                      ))}
                    </>
                  )}
                </View>
              ) : null}
            </View>
          );
        })}

        {/* Legend */}
        <View style={ssStyles.legend}>
          <Text style={ssStyles.legendTitle}>دليل الأحداث</Text>
          <View style={ssStyles.legendItem}><View style={[ssStyles.legendDot, { backgroundColor: Colors.green }]}/><Text style={ssStyles.legendText}>GENERATION_START — بعد ضغط زر الإرسال</Text></View>
          <View style={ssStyles.legendItem}><View style={[ssStyles.legendDot, { backgroundColor: Colors.red }]}/><Text style={ssStyles.legendText}>GENERATION_END — عند اختفاء زر الإيقاف</Text></View>
          <View style={ssStyles.legendItem}><View style={[ssStyles.legendDot, { backgroundColor: Colors.accent }]}/><Text style={ssStyles.legendText}>AI_RESPONSE — كتل كود مكتشفة</Text></View>
        </View>

        <View style={{ height: 20 }} />
      </ScrollView>

      <Pressable
        onPress={save}
        style={({ pressed }) => [ssStyles.saveBtn, pressed && { opacity: 0.85 }]}
      >
        <MaterialIcons name="check-circle" size={16} color="#fff" />
        <Text style={ssStyles.saveBtnText}>حفظ وإعادة تحميل الـ injection</Text>
      </Pressable>
    </Animated.View>
  );
}

const ssStyles = StyleSheet.create({
  container: {
    position: 'absolute', top: 0, bottom: 0, left: 0, right: 0,
    backgroundColor: Colors.bg, zIndex: 300,
  },
  header: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    paddingHorizontal: 12, paddingVertical: 10,
    backgroundColor: Colors.bgSecondary,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  title: { flex: 1, color: Colors.textPrimary, fontSize: 13, fontWeight: '700' },
  resetBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, marginRight: 4 },
  resetText: { color: Colors.yellow, fontSize: 11, fontWeight: '600' },
  scroll: { flex: 1 },
  infoBox: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 6,
    margin: 10, padding: 8,
    backgroundColor: Colors.accentGlow,
    borderRadius: 8, borderWidth: 1, borderColor: Colors.accent + '33',
  },
  infoText: { flex: 1, color: Colors.textSecondary, fontSize: 10, lineHeight: 15 },
  field: {
    marginHorizontal: 10, marginBottom: 10,
    backgroundColor: Colors.bgCard,
    borderRadius: 8, padding: 10,
    borderWidth: 1, borderColor: Colors.border,
  },
  fieldPicking: {
    borderColor: Colors.yellow + '88',
    backgroundColor: Colors.yellow + '0a',
  },
  fieldLabel: { flexDirection: 'row', alignItems: 'center', gap: 5, marginBottom: 6 },
  fieldLabelText: { fontSize: 11, fontWeight: '700' },
  pickingBadge: {
    backgroundColor: Colors.yellow + '22', borderRadius: 99,
    paddingHorizontal: 6, paddingVertical: 2,
    borderWidth: 1, borderColor: Colors.yellow + '44',
    marginLeft: 'auto',
  },
  pickingBadgeText: { color: Colors.yellow, fontSize: 9, fontWeight: '700' },
  inputRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 5 },
  input: {
    flex: 1, backgroundColor: Colors.bg,
    borderWidth: 1, borderColor: Colors.borderSubtle,
    borderRadius: 6, padding: 7,
    color: Colors.textPrimary, fontSize: 11,
    fontFamily: 'monospace', minHeight: 36,
  },
  pickBtn: {
    width: 32, height: 32, borderRadius: 6,
    backgroundColor: Colors.bgTertiary,
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
  pickBtnActive: {
    backgroundColor: Colors.yellow + '22',
    borderColor: Colors.yellow + '88',
  },
  inspectBtn: {
    width: 32, height: 32, borderRadius: 6,
    backgroundColor: Colors.bgTertiary,
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
  inspectBtnText: { fontSize: 14 },
  inspectResult: {
    marginTop: 6, padding: 6,
    backgroundColor: Colors.bgTertiary,
    borderRadius: 5, borderWidth: 1,
  },
  inspectCount: { fontSize: 11, fontWeight: '700', marginBottom: 3 },
  inspectEl: { color: Colors.textMuted, fontSize: 9, fontFamily: 'monospace', lineHeight: 14 },
  legend: {
    marginHorizontal: 10, marginBottom: 8, padding: 10,
    backgroundColor: Colors.bgSecondary, borderRadius: 8,
    borderWidth: 1, borderColor: Colors.borderSubtle, gap: 5,
  },
  legendTitle: { color: Colors.textSecondary, fontSize: 11, fontWeight: '700', marginBottom: 4 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  legendDot: { width: 7, height: 7, borderRadius: 3.5 },
  legendText: { color: Colors.textMuted, fontSize: 10, lineHeight: 15 },
  saveBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7,
    backgroundColor: Colors.green,
    margin: 10, borderRadius: 10,
    paddingVertical: 12,
  },
  saveBtnText: { color: '#fff', fontSize: 13, fontWeight: '700' },
});

// ─── Generation Status Chip ───────────────────────────────────────────────────
function GenerationChip({ status }: { status: 'idle' | 'generating' | 'done' }) {
  const pulseAnim = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    if (status === 'generating') {
      const a = Animated.loop(Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 0.3, duration: 500, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 500, useNativeDriver: true }),
      ]));
      a.start();
      return () => a.stop();
    }
    pulseAnim.setValue(1);
  }, [status]);
  if (status === 'idle') return null;
  const color = status === 'generating' ? Colors.yellow : Colors.green;
  const label = status === 'generating' ? 'يُولِّد...' : 'اكتمل ✓';
  return (
    <View style={[genChipStyles.chip, { borderColor: color + '44', backgroundColor: color + '15' }]}>
      <Animated.View style={[genChipStyles.dot, { backgroundColor: color, opacity: status === 'generating' ? pulseAnim : 1 }]} />
      <Text style={[genChipStyles.label, { color }]}>{label}</Text>
    </View>
  );
}

const genChipStyles = StyleSheet.create({
  chip: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 7, paddingVertical: 3, borderRadius: 99, borderWidth: 1 },
  dot: { width: 6, height: 6, borderRadius: 3 },
  label: { fontSize: 10, fontWeight: '700' },
});

// ─── Web Platform Fallback ────────────────────────────────────────────────────
function WebFallback() {
  return (
    <View style={wfStyles.container}>
      <View style={wfStyles.iconWrap}>
        <MaterialIcons name="phone-iphone" size={50} color={Colors.deepseek} />
      </View>
      <Text style={wfStyles.title}>متاح على الهاتف فقط</Text>
      <Text style={wfStyles.sub}>افتح التطبيق على هاتفك للوصول إلى واجهة DeepSeek المدمجة</Text>
      <View style={wfStyles.badge}>
        <MaterialIcons name="smart-toy" size={14} color={Colors.deepseek} />
        <Text style={wfStyles.badgeText}>chat.deepseek.com</Text>
      </View>
    </View>
  );
}

const wfStyles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 14, padding: 32, backgroundColor: Colors.bg },
  iconWrap: { width: 88, height: 88, borderRadius: 22, backgroundColor: Colors.deepseekDim, alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  title: { color: Colors.textPrimary, fontSize: 18, fontWeight: '700' },
  sub: { color: Colors.textMuted, fontSize: 13, textAlign: 'center', lineHeight: 22, maxWidth: 280 },
  badge: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: Colors.deepseekDim, borderRadius: 99, paddingHorizontal: 14, paddingVertical: 6, borderWidth: 1, borderColor: Colors.deepseek + '44', marginTop: 4 },
  badgeText: { color: Colors.deepseek, fontSize: 12, fontWeight: '600' },
});

// ─── Page Chip ────────────────────────────────────────────────────────────────
function PageChip({ url }: { url: string }) {
  if (!url) return null;
  let label = '', bgColor = '', textColor = '', borderColor = '';
  let icon: keyof typeof MaterialIcons.glyphMap = 'language';
  if (url.includes('/login') || url.includes('/auth') || url.includes('/sign')) {
    label = 'تسجيل الدخول'; bgColor = Colors.yellow + '18'; textColor = Colors.yellow; borderColor = Colors.yellow + '44'; icon = 'person';
  } else if (url.includes('chat.deepseek.com')) {
    label = 'محادثة'; bgColor = Colors.green + '18'; textColor = Colors.green; borderColor = Colors.green + '44'; icon = 'chat';
  } else if (url.includes('deepseek.com')) {
    label = 'DeepSeek'; bgColor = Colors.deepseekDim; textColor = Colors.deepseek; borderColor = Colors.deepseek + '44'; icon = 'smart-toy';
  } else {
    label = 'متصفح'; bgColor = Colors.bgTertiary; textColor = Colors.textSecondary; borderColor = Colors.border; icon = 'language';
  }
  return (
    <View style={[chipStyles.chip, { backgroundColor: bgColor, borderColor }]}>
      <MaterialIcons name={icon} size={10} color={textColor} />
      <Text style={[chipStyles.label, { color: textColor }]}>{label}</Text>
    </View>
  );
}

const chipStyles = StyleSheet.create({
  chip: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 99, borderWidth: 1 },
  label: { fontSize: 10, fontWeight: '700' },
});

// ─── Auto Chip ────────────────────────────────────────────────────────────────
function AutoChip({ busy }: { busy: boolean }) {
  const pulseAnim = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    if (busy) {
      const anim = Animated.loop(Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 0.4, duration: 600, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      ]));
      anim.start();
      return () => anim.stop();
    } else {
      pulseAnim.setValue(1);
    }
  }, [busy]);
  return (
    <View style={[autoChipStyles.chip, busy ? autoChipStyles.chipBusy : autoChipStyles.chipActive]}>
      <Animated.View style={[autoChipStyles.dot, busy ? autoChipStyles.dotBusy : autoChipStyles.dotActive, { opacity: pulseAnim }]} />
      <Text style={[autoChipStyles.label, { color: busy ? Colors.accent : Colors.green }]}>
        {busy ? 'حفظ...' : 'تلقائي'}
      </Text>
    </View>
  );
}

const autoChipStyles = StyleSheet.create({
  chip: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 99, borderWidth: 1 },
  chipActive: { backgroundColor: Colors.green + '15', borderColor: Colors.green + '44' },
  chipBusy: { backgroundColor: Colors.accent + '15', borderColor: Colors.accent + '44' },
  dot: { width: 6, height: 6, borderRadius: 3 },
  dotActive: { backgroundColor: Colors.green },
  dotBusy: { backgroundColor: Colors.accent },
  label: { fontSize: 10, fontWeight: '700' },
});

// ─── Progress Bar ─────────────────────────────────────────────────────────────
function ProgressBar({ loading }: { loading: boolean }) {
  const widthAnim = useRef(new Animated.Value(0)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (loading) {
      widthAnim.setValue(0);
      opacityAnim.setValue(1);
      Animated.timing(widthAnim, { toValue: 0.85, duration: 8000, useNativeDriver: false }).start();
    } else {
      Animated.sequence([
        Animated.timing(widthAnim, { toValue: 1, duration: 250, useNativeDriver: false }),
        Animated.timing(opacityAnim, { toValue: 0, duration: 300, useNativeDriver: false }),
      ]).start(() => widthAnim.setValue(0));
    }
  }, [loading]);
  return (
    <Animated.View style={[pbStyles.bar, { opacity: opacityAnim }]}>
      <Animated.View style={[pbStyles.fill, { width: widthAnim.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }) }]} />
    </Animated.View>
  );
}

const pbStyles = StyleSheet.create({
  bar: { height: 2, backgroundColor: 'transparent', overflow: 'hidden' },
  fill: { height: '100%', backgroundColor: Colors.deepseek, shadowColor: Colors.deepseek, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.8, shadowRadius: 4 },
});

// ─── Pick Mode Overlay (shown over WebView when picking) ──────────────────────
function PickOverlay({ fieldKey, onCancel }: { fieldKey: keyof SelectorConfig; onCancel: () => void }) {
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const fieldMeta = SEL_FIELDS.find(f => f.key === fieldKey);
  useEffect(() => {
    const anim = Animated.loop(Animated.sequence([
      Animated.timing(pulseAnim, { toValue: 0.5, duration: 700, useNativeDriver: true }),
      Animated.timing(pulseAnim, { toValue: 1, duration: 700, useNativeDriver: true }),
    ]));
    anim.start();
    return () => anim.stop();
  }, []);
  return (
    <View style={poStyles.overlay} pointerEvents="box-none">
      <View style={poStyles.banner}>
        <Animated.View style={[poStyles.dot, { opacity: pulseAnim }]} />
        <MaterialIcons name="touch-app" size={14} color={Colors.yellow} />
        <Text style={poStyles.bannerText}>انقر على العنصر المطلوب في الصفحة</Text>
        <View style={poStyles.fieldChip}>
          <MaterialIcons name={fieldMeta?.icon || 'code'} size={10} color={fieldMeta?.color || Colors.accent} />
          <Text style={[poStyles.fieldChipText, { color: fieldMeta?.color || Colors.accent }]}>
            {fieldMeta?.label.split(' ')[0]}
          </Text>
        </View>
        <Pressable onPress={onCancel} hitSlop={8} style={({ pressed }) => [poStyles.cancelBtn, pressed && { opacity: 0.7 }]}>
          <MaterialIcons name="close" size={14} color={Colors.yellow} />
          <Text style={poStyles.cancelText}>إلغاء</Text>
        </Pressable>
      </View>
    </View>
  );
}

const poStyles = StyleSheet.create({
  overlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 50 },
  banner: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: 'rgba(13,17,23,0.94)',
    borderBottomWidth: 1.5, borderBottomColor: Colors.yellow + '66',
    paddingHorizontal: 12, paddingVertical: 8, flexWrap: 'wrap',
  },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.yellow, shadowColor: Colors.yellow, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 1, shadowRadius: 6 },
  bannerText: { color: Colors.yellow, fontSize: 11, fontWeight: '600', flex: 1 },
  fieldChip: { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: Colors.bgTertiary, borderRadius: 99, paddingHorizontal: 7, paddingVertical: 3, borderWidth: 1, borderColor: Colors.border },
  fieldChipText: { fontSize: 10, fontWeight: '700' },
  cancelBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: Colors.yellow + '22', borderRadius: 99, paddingHorizontal: 8, paddingVertical: 4, borderWidth: 1, borderColor: Colors.yellow + '44' },
  cancelText: { color: Colors.yellow, fontSize: 10, fontWeight: '700' },
});

// ─── FAB (Extract button) ─────────────────────────────────────────────────────
function ExtractFAB({ count, onPress, visible }: { count: number; onPress: () => void; visible: boolean }) {
  const scaleAnim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.spring(scaleAnim, { toValue: visible ? 1 : 0, useNativeDriver: true, tension: 180, friction: 10 }).start();
  }, [visible]);
  return (
    <Animated.View style={[fabStyles.wrap, { transform: [{ scale: scaleAnim }] }]} pointerEvents={visible ? 'auto' : 'none'}>
      <Pressable onPress={onPress} style={({ pressed }) => [fabStyles.btn, pressed && { opacity: 0.85, transform: [{ scale: 0.96 }] }]}>
        <View style={fabStyles.iconWrap}>
          <MaterialIcons name="auto-awesome" size={18} color="#fff" />
        </View>
        <View style={fabStyles.info}>
          <Text style={fabStyles.count}>{count} كتل كود</Text>
          <Text style={fabStyles.sub}>اضغط للاستخراج</Text>
        </View>
        <MaterialIcons name="keyboard-arrow-up" size={20} color="rgba(255,255,255,0.7)" />
      </Pressable>
    </Animated.View>
  );
}

const fabStyles = StyleSheet.create({
  wrap: { position: 'absolute', bottom: 12, left: 10, right: 10 },
  btn: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: Colors.deepseek, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 10, shadowColor: Colors.deepseek, shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.5, shadowRadius: 14, elevation: 10 },
  iconWrap: { width: 34, height: 34, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.18)', alignItems: 'center', justifyContent: 'center' },
  info: { flex: 1 },
  count: { color: '#fff', fontSize: 14, fontWeight: '700' },
  sub: { color: 'rgba(255,255,255,0.7)', fontSize: 11 },
});

// ─── No Project Banner ────────────────────────────────────────────────────────
function NoProjectBanner() {
  return (
    <View style={npStyles.banner}>
      <MaterialIcons name="warning-amber" size={13} color={Colors.yellow} />
      <Text style={npStyles.text}>المود التلقائي نشط — اختر مشروعاً لحفظ الملفات</Text>
    </View>
  );
}

const npStyles = StyleSheet.create({
  banner: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: Colors.yellow + '12', borderTopWidth: 1, borderTopColor: Colors.yellow + '35', paddingHorizontal: 14, paddingVertical: 6 },
  text: { color: Colors.yellow, fontSize: 11, flex: 1 },
});

// ─── Auto Save Pulse ──────────────────────────────────────────────────────────
function AutoSavePulse({ visible }: { visible: boolean }) {
  const opacityAnim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (visible) {
      opacityAnim.setValue(1);
      Animated.loop(Animated.sequence([
        Animated.timing(opacityAnim, { toValue: 0.4, duration: 700, useNativeDriver: true }),
        Animated.timing(opacityAnim, { toValue: 1, duration: 700, useNativeDriver: true }),
      ])).start();
    } else {
      opacityAnim.setValue(0);
    }
  }, [visible]);
  if (!visible) return null;
  return (
    <Animated.View style={[pulseStyles.wrap, { opacity: opacityAnim }]}>
      <View style={pulseStyles.dot} />
      <Text style={pulseStyles.label}>حفظ تلقائي...</Text>
    </Animated.View>
  );
}

const pulseStyles = StyleSheet.create({
  wrap: { position: 'absolute', top: 8, right: 8, flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: 'rgba(28,33,40,0.92)', borderWidth: 1, borderColor: Colors.green + '50', borderRadius: 99, paddingHorizontal: 10, paddingVertical: 4 },
  dot: { width: 7, height: 7, borderRadius: 3.5, backgroundColor: Colors.green },
  label: { color: Colors.green, fontSize: 11, fontWeight: '700' },
});

// ─── Main Component ───────────────────────────────────────────────────────────
interface DeepSeekViewProps {
  onLogin?: () => void;
}

export function DeepSeekView({ onLogin }: DeepSeekViewProps) {
  const webviewRef = useRef<WebView>(null);
  const { activeProject, autoMode, addAutoLog, incrementAutoSaved, refreshProjects } = useProjects();

  const [currentUrl, setCurrentUrl] = useState(HOME_URL);
  const [urlInput, setUrlInput] = useState('chat.deepseek.com');
  const [editingUrl, setEditingUrl] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [canGoBack, setCanGoBack] = useState(false);
  const [canGoForward, setCanGoForward] = useState(false);
  const [showPanel, setShowPanel] = useState(false);
  const [extractedBlocks, setExtractedBlocks] = useState<ExtractedCodeBlock[]>([]);
  const [processingAuto, setProcessingAuto] = useState(false);

  // Selectors
  const [selectorConfig, setSelectorConfig] = useState<SelectorConfig>(DEFAULT_SELECTORS);
  const [showSelectorSettings, setShowSelectorSettings] = useState(false);
  const [inspectResult, setInspectResult] = useState<{ selector: string; count: number; elements?: any[]; error?: string } | null>(null);
  const [generationStatus, setGenerationStatus] = useState<'idle' | 'generating' | 'done'>('idle');
  const injectedJS = useRef(buildInjectedJS(DEFAULT_SELECTORS));

  // Picker state
  const [pickingField, setPickingField] = useState<keyof SelectorConfig | null>(null);
  const [pickedValues, setPickedValues] = useState<Partial<SelectorConfig>>({});
  // When pick mode starts from settings panel, remember to reopen it after picking
  const pickReturnToSettings = useRef(false);

  // Auto-save concurrency guard using ref (avoids stale closure of processingAuto)
  const autoSaveInFlight = useRef(false);

  useEffect(() => {
    AsyncStorage.getItem(SELECTORS_KEY).then(raw => {
      if (!raw) return;
      try {
        const cfg: SelectorConfig = JSON.parse(raw);
        setSelectorConfig(cfg);
        injectedJS.current = buildInjectedJS(cfg);
      } catch {}
    });
  }, []);

  const handleSaveSelectors = useCallback(async (cfg: SelectorConfig) => {
    setSelectorConfig(cfg);
    injectedJS.current = buildInjectedJS(cfg);
    await AsyncStorage.setItem(SELECTORS_KEY, JSON.stringify(cfg));
    webviewRef.current?.injectJavaScript(injectedJS.current + '; true;');
  }, []);

  const handleInspectSelector = useCallback((selector: string, _label: string) => {
    if (!webviewRef.current) return;
    const escaped = selector.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    webviewRef.current.injectJavaScript(`
      if (window.__deepcodeInspect) {
        window.__deepcodeInspect('${escaped}');
      } else {
        try {
          var els = document.querySelectorAll('${escaped}');
          window.ReactNativeWebView.postMessage(JSON.stringify({
            type: 'INSPECT_RESULT',
            selector: '${escaped}',
            count: els.length,
            timestamp: Date.now()
          }));
        } catch(e) {
          window.ReactNativeWebView.postMessage(JSON.stringify({
            type: 'INSPECT_RESULT',
            selector: '${escaped}',
            count: -1,
            error: e.message,
            timestamp: Date.now()
          }));
        }
      }
      true;
    `);
  }, []);

  // ── Pick mode: hide settings panel so WebView is fully tappable ─────────────
  const handleStartPick = useCallback((fieldKey: keyof SelectorConfig) => {
    if (!webviewRef.current) return;
    // Remember that settings was open so we reopen it after picking
    pickReturnToSettings.current = showSelectorSettings;
    // Hide the settings panel → exposes the full WebView
    setShowSelectorSettings(false);
    setPickingField(fieldKey);
    // Slight delay so panel slides out before injecting picker overlay into page
    setTimeout(() => {
      webviewRef.current?.injectJavaScript(buildPickerJS(fieldKey));
    }, 280);
  }, [showSelectorSettings]);

  const handleCancelPick = useCallback(() => {
    if (webviewRef.current) {
      webviewRef.current.injectJavaScript(`
        if (window.__deepcodePicker) { window.__deepcodePicker.cancel(); }
        true;
      `);
    }
    setPickingField(null);
    // Restore settings panel if it was open before
    if (pickReturnToSettings.current) {
      setTimeout(() => setShowSelectorSettings(true), 100);
    }
  }, []);

  const processedHashes = useRef<Set<string>>(new Set());
  const lastBlockCount = useRef<number>(0);

  const hashText = (text: string) => {
    let h = 0;
    for (let i = 0; i < text.length; i++) h = Math.imul(31, h) + text.charCodeAt(i) | 0;
    return String(h);
  };

  const handleNavigate = useCallback((input: string) => {
    let url = input.trim();
    if (!url) return;
    if (!/^https?:\/\//.test(url)) url = 'https://' + url;
    setCurrentUrl(url);
    setUrlInput(url.replace(/^https?:\/\//, '').replace(/\/$/, ''));
    setEditingUrl(false);
    webviewRef.current?.stopLoading();
    webviewRef.current?.reload();
  }, []);

  const handleAutoSave = useCallback(async (blocks: ExtractedCodeBlock[]) => {
    if (!activeProject || blocks.length === 0) return;
    // Use ref guard to prevent concurrent saves without stale-closure issues
    if (autoSaveInFlight.current) return;
    autoSaveInFlight.current = true;
    setProcessingAuto(true);
    try {
      const { results, logs } = await autoSaveBlocks(activeProject, blocks);
      logs.forEach(log => addAutoLog(log));
      await refreshProjects();
      if (results.length > 0) incrementAutoSaved(results.length);
    } catch (e) {
      console.warn('[AutoSave]', e);
    } finally {
      autoSaveInFlight.current = false;
      setProcessingAuto(false);
    }
  }, [activeProject, addAutoLog, incrementAutoSaved, refreshProjects]);

  const handleMessage = useCallback((event: any) => {
    try {
      const data = JSON.parse(event.nativeEvent.data);

      if (data.type === 'GENERATION_START') {
        setGenerationStatus('generating');
        // Reset dedup state on each new generation
        processedHashes.current.clear();
        lastBlockCount.current = 0;
        return;
      }

      if (data.type === 'GENERATION_END') {
        setGenerationStatus('done');
        setTimeout(() => setGenerationStatus('idle'), 4000);
        return;
      }

      if (data.type === 'GENERATION_STATUS') {
        if (data.generating) setGenerationStatus('generating');
        return;
      }

      if (data.type === 'INSPECT_RESULT') {
        setInspectResult({
          selector: data.selector,
          count: data.count,
          elements: data.elements,
          error: data.error,
        });
        return;
      }

      // ── Element picker picked a selector ──────────────────────────────────
      if (data.type === 'SELECTOR_PICKED') {
        setPickingField(null);
        setPickedValues({ [data.fieldKey]: data.selector });
        // Reopen settings panel so user sees the picked value filled in
        if (pickReturnToSettings.current) {
          setTimeout(() => setShowSelectorSettings(true), 150);
        }
        // Auto-inspect so user sees count immediately
        setTimeout(() => {
          if (webviewRef.current) {
            const esc = data.selector.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
            webviewRef.current.injectJavaScript(`
              if (window.__deepcodeInspect) { window.__deepcodeInspect('${esc}'); }
              true;
            `);
          }
        }, 500);
        return;
      }

      // ── Picker cancelled from inside the page ─────────────────────────────
      if (data.type === 'PICKER_CANCELLED') {
        setPickingField(null);
        if (pickReturnToSettings.current) {
          setTimeout(() => setShowSelectorSettings(true), 100);
        }
        return;
      }

      // ── Code blocks extracted ─────────────────────────────────────────────
      if (data.type === 'AI_RESPONSE' && data.text) {
        const hash = hashText(data.text);
        const inCount: number = data.blockCount || 0;

        const alreadySeen = processedHashes.current.has(hash);
        // Skip only if we've seen this exact content AND block count hasn't grown
        if (alreadySeen && inCount <= lastBlockCount.current) return;

        processedHashes.current.add(hash);
        if (processedHashes.current.size > 300) {
          processedHashes.current.clear();
          processedHashes.current.add(hash);
        }

        const blocks = parseCodeBlocks(data.markdown || data.text, data.blocks || []);
        if (blocks.length === 0) return;

        // Update UI & trigger auto-save whenever we get more blocks or new content
        if (blocks.length > lastBlockCount.current || !alreadySeen) {
          lastBlockCount.current = blocks.length;
          setExtractedBlocks(blocks);
          if (autoMode && activeProject) {
            handleAutoSave(blocks);
          }
        }
      }
    } catch {}
  }, [autoMode, activeProject, handleAutoSave]);

  if (Platform.OS === 'web') return <WebFallback />;

  const displayUrl = currentUrl.replace(/^https?:\/\//, '').replace(/\/$/, '');
  const isSecure = currentUrl.startsWith('https://');

  return (
    <View style={styles.container}>
      {/* ── Toolbar ── */}
      <View style={styles.toolbar}>
        <View style={styles.toolbarRow}>
          <Pressable
            onPress={() => webviewRef.current?.goBack()}
            disabled={!canGoBack}
            hitSlop={6}
            style={({ pressed }) => [styles.navBtn, !canGoBack && styles.navBtnDisabled, pressed && styles.navBtnPressed]}
          >
            <MaterialIcons name="arrow-back-ios" size={16} color={canGoBack ? Colors.textSecondary : Colors.textMuted} />
          </Pressable>

          <Pressable
            onPress={() => webviewRef.current?.goForward()}
            disabled={!canGoForward}
            hitSlop={6}
            style={({ pressed }) => [styles.navBtn, !canGoForward && styles.navBtnDisabled, pressed && styles.navBtnPressed]}
          >
            <MaterialIcons name="arrow-forward-ios" size={16} color={canGoForward ? Colors.textSecondary : Colors.textMuted} />
          </Pressable>

          <Pressable
            onPress={() => { setUrlInput(displayUrl); setEditingUrl(true); }}
            style={[styles.urlBar, editingUrl && styles.urlBarFocused]}
          >
            <MaterialIcons name={isSecure ? 'lock' : 'lock-open'} size={11} color={isSecure ? Colors.green : Colors.yellow} />
            {editingUrl ? (
              <TextInput
                style={styles.urlInput}
                value={urlInput}
                onChangeText={setUrlInput}
                autoFocus
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="url"
                returnKeyType="go"
                selectTextOnFocus
                onSubmitEditing={() => handleNavigate(urlInput)}
                onBlur={() => { setEditingUrl(false); setUrlInput(displayUrl); }}
              />
            ) : (
              <Text style={styles.urlText} numberOfLines={1}>{displayUrl}</Text>
            )}
          </Pressable>

          <GenerationChip status={generationStatus} />
          <PageChip url={currentUrl} />

          <Pressable
            onPress={() => { if (isLoading) webviewRef.current?.stopLoading(); else webviewRef.current?.reload(); }}
            hitSlop={6}
            style={({ pressed }) => [styles.navBtn, pressed && styles.navBtnPressed]}
          >
            <MaterialIcons name={isLoading ? 'close' : 'refresh'} size={18} color={Colors.textSecondary} />
          </Pressable>

          <Pressable
            onPress={() => { setCurrentUrl(HOME_URL); setUrlInput('chat.deepseek.com'); }}
            hitSlop={6}
            style={({ pressed }) => [styles.navBtn, pressed && styles.navBtnPressed]}
          >
            <MaterialIcons name="home" size={18} color={Colors.textSecondary} />
          </Pressable>

          {autoMode ? <AutoChip busy={processingAuto} /> : null}

          <Pressable
            onPress={() => { setInspectResult(null); setPickedValues({}); setShowSelectorSettings(true); }}
            hitSlop={6}
            style={({ pressed }) => [styles.navBtn, pressed && styles.navBtnPressed]}
          >
            <MaterialIcons name="tune" size={16} color={Colors.textMuted} />
          </Pressable>
        </View>

        <ProgressBar loading={isLoading} />
      </View>

      {autoMode && !activeProject ? <NoProjectBanner /> : null}

      {/* ── WebView area ── */}
      <View style={styles.webviewWrap}>
        <WebView
          ref={webviewRef}
          source={{ uri: currentUrl }}
          style={styles.webview}
          onMessage={handleMessage}
          injectedJavaScript={injectedJS.current}
          javaScriptEnabled
          domStorageEnabled
          thirdPartyCookiesEnabled
          sharedCookiesEnabled
          allowsInlineMediaPlayback
          mediaPlaybackRequiresUserAction={false}
          mixedContentMode="always"
          allowsBackForwardNavigationGestures
          allowUniversalAccessFromFileURLs
          originWhitelist={['*']}
          userAgent="Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1"
          onLoadStart={() => setIsLoading(true)}
          onLoadEnd={({ nativeEvent }) => {
            setIsLoading(false);
            setCurrentUrl(nativeEvent.url);
            setUrlInput(nativeEvent.url.replace(/^https?:\/\//, '').replace(/\/$/, ''));
            setCanGoBack(nativeEvent.canGoBack);
            setCanGoForward(nativeEvent.canGoForward);
            onLogin?.();
          }}
          onNavigationStateChange={(state) => {
            setCurrentUrl(state.url);
            setUrlInput(state.url.replace(/^https?:\/\//, '').replace(/\/$/, ''));
            setCanGoBack(state.canGoBack);
            setCanGoForward(state.canGoForward);
          }}
          onError={() => setIsLoading(false)}
          onHttpError={() => setIsLoading(false)}
        />

        <AutoSavePulse visible={processingAuto} />

        {/* Pick mode banner — shown over the WebView so user knows to tap */}
        {pickingField ? (
          <PickOverlay fieldKey={pickingField} onCancel={handleCancelPick} />
        ) : null}

        <ExtractFAB
          count={extractedBlocks.length}
          visible={!autoMode && extractedBlocks.length > 0 && !pickingField}
          onPress={() => setShowPanel(true)}
        />
      </View>

      {/* ── Selector Settings Panel (hides when pick mode is active) ── */}
      {showSelectorSettings && !pickingField ? (
        <SelectorSettings
          config={selectorConfig}
          onSave={handleSaveSelectors}
          onClose={() => { setShowSelectorSettings(false); }}
          onInspect={handleInspectSelector}
          onStartPick={handleStartPick}
          onCancelPick={handleCancelPick}
          inspectResult={inspectResult}
          pickingField={pickingField}
          pickedValues={pickedValues}
        />
      ) : null}

      <ResponsePanel
        blocks={extractedBlocks}
        visible={showPanel}
        onClose={() => setShowPanel(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  toolbar: { backgroundColor: Colors.bgSecondary, borderBottomWidth: 1, borderBottomColor: Colors.border },
  toolbarRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 7, gap: 5 },
  navBtn: { width: 32, height: 32, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  navBtnDisabled: { opacity: 0.35 },
  navBtnPressed: { backgroundColor: Colors.bgTertiary },
  urlBar: {
    flex: 1, flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: Colors.bgTertiary,
    borderWidth: 1, borderColor: Colors.borderSubtle,
    borderRadius: 9, height: 32, paddingHorizontal: 9,
  },
  urlBarFocused: { borderColor: Colors.accent, backgroundColor: Colors.bg },
  urlInput: { flex: 1, color: Colors.textPrimary, fontSize: 12, paddingVertical: 0 },
  urlText: { flex: 1, color: Colors.textSecondary, fontSize: 12 },
  webviewWrap: { flex: 1, position: 'relative' },
  webview: { flex: 1, backgroundColor: Colors.bg },
});
