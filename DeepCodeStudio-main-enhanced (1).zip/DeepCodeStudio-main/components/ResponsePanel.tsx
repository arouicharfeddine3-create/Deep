import React, { useState, useCallback, useEffect } from 'react';
import {
  View, Text, ScrollView, Pressable, StyleSheet,
  TextInput, Modal, Switch, Animated,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, Radius, Shadow } from '@/constants/theme';
import { ExtractedCodeBlock, computeDiff } from '@/services/responseParser';
import { useProjects } from '@/hooks/useProjects';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';

interface ResponsePanelProps {
  blocks: ExtractedCodeBlock[];
  onClose: () => void;
  visible: boolean;
}

export function ResponsePanel({ blocks, onClose, visible }: ResponsePanelProps) {
  const { activeProject, addFileToProject, updateFileContent, autoMode, setAutoMode } = useProjects();
  const [filenames, setFilenames] = useState<Record<string, string>>({});
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [selectedBlock, setSelectedBlock] = useState<string | null>(null);

  // Reset saved state when new blocks arrive
  useEffect(() => {
    if (visible) setSavedIds(new Set());
  }, [blocks, visible]);

  const getFilename = (block: ExtractedCodeBlock) => filenames[block.id] ?? block.suggestedFilename;

  const handleSave = useCallback(async (block: ExtractedCodeBlock) => {
    if (!activeProject) return;
    const filename = getFilename(block);
    const existingFile = activeProject.files.find(f => f.name === filename);

    if (existingFile) {
      await updateFileContent(activeProject.id, existingFile.id, block.code);
    } else {
      await addFileToProject(activeProject.id, {
        name: filename,
        language: block.language,
        content: block.code,
        sourceMessageId: block.id,
      });
    }
    setSavedIds(prev => new Set([...prev, block.id]));
  }, [activeProject, addFileToProject, updateFileContent, filenames]);

  const handleSaveAll = useCallback(async () => {
    for (const block of blocks) {
      if (!savedIds.has(block.id)) await handleSave(block);
    }
  }, [blocks, savedIds, handleSave]);

  if (!visible) return null;

  const remaining = blocks.length - savedIds.size;

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <Pressable style={styles.backdrop} onPress={onClose} />
        <View style={styles.panel}>
          {/* Header */}
          <View style={styles.header}>
            <View style={styles.headerLeft}>
              <MaterialIcons name="auto-fix-high" size={18} color={Colors.accent} />
              <Text style={styles.headerTitle}>استخراج الردود والملفات</Text>
              <Badge label={`${blocks.length} عناصر`} color={Colors.accent} size="sm" />
            </View>
            <View style={styles.headerRight}>
              {/* Auto mode quick toggle */}
              <View style={styles.autoToggleRow}>
                <MaterialIcons name="bolt" size={13} color={autoMode ? Colors.green : Colors.textMuted} />
                <Text style={[styles.autoToggleLabel, autoMode && { color: Colors.green }]}>تلقائي</Text>
                <Switch
                  value={autoMode}
                  onValueChange={setAutoMode}
                  trackColor={{ false: Colors.bgTertiary, true: Colors.green + '88' }}
                  thumbColor={autoMode ? Colors.green : Colors.textSecondary}
                  style={{ transform: [{ scaleX: 0.75 }, { scaleY: 0.75 }] }}
                />
              </View>
              <Pressable onPress={onClose} hitSlop={8}>
                <MaterialIcons name="close" size={20} color={Colors.textSecondary} />
              </Pressable>
            </View>
          </View>

          {!activeProject ? (
            <View style={styles.noProject}>
              <MaterialIcons name="folder-off" size={32} color={Colors.textMuted} />
              <Text style={styles.noProjectText}>اختر مشروعاً أولاً لحفظ الملفات</Text>
            </View>
          ) : (
            <>
              {/* Project indicator */}
              <View style={styles.projectIndicator}>
                <MaterialIcons name="folder" size={14} color={activeProject.color} />
                <Text style={styles.projectName}>{activeProject.name}</Text>
                <Text style={styles.projectFilesCount}>{activeProject.files.length} ملف حالياً</Text>
              </View>

              {/* Blocks list */}
              <ScrollView style={styles.blocksList} showsVerticalScrollIndicator={false}>
                {blocks.map((block) => {
                  const isSaved = savedIds.has(block.id);
                  const isExpanded = selectedBlock === block.id;
                  const filename = getFilename(block);
                  const existingFile = activeProject.files.find(f => f.name === filename);
                  const diff = existingFile ? computeDiff(existingFile.content, block.code) : null;

                  return (
                    <View key={block.id} style={[styles.blockCard, isSaved && styles.blockCardSaved]}>
                      <Pressable
                        onPress={() => setSelectedBlock(isExpanded ? null : block.id)}
                        style={styles.blockHeader}
                      >
                        <View style={styles.blockHeaderLeft}>
                          <Badge label={block.kind === 'markdown' ? `DOC · ${block.language}` : block.language} color={Colors.deepseek} size="sm" />
                          {existingFile ? (
                            <Badge label={`+${diff?.added ?? 0} -${diff?.removed ?? 0}`} color={Colors.yellow} size="sm" />
                          ) : (
                            <Badge label={block.kind === 'markdown' ? 'وثيقة جديدة' : 'جديد'} color={Colors.green} size="sm" />
                          )}
                        </View>
                        <MaterialIcons
                          name={isExpanded ? 'keyboard-arrow-up' : 'keyboard-arrow-down'}
                          size={16} color={Colors.textSecondary}
                        />
                      </Pressable>

                      {/* Filename input */}
                      <View style={styles.filenameRow}>
                        <MaterialIcons name="insert-drive-file" size={14} color={Colors.textSecondary} />
                        <TextInput
                          style={styles.filenameInput}
                          value={filename}
                          onChangeText={text => setFilenames(prev => ({ ...prev, [block.id]: text }))}
                          placeholder="اسم الملف..."
                          placeholderTextColor={Colors.textMuted}
                          autoCapitalize="none"
                          autoCorrect={false}
                          editable={!isSaved}
                        />
                        <Text style={styles.lineCount}>{block.code.split('\n').length} سطر</Text>
                      </View>

                      {/* Context hint */}
                      {block.context ? (
                        <Text style={styles.contextHint} numberOfLines={1}>💬 {block.context}</Text>
                      ) : null}

                      {/* Code preview */}
                      {isExpanded ? (
                        <ScrollView style={styles.codePreview} horizontal showsHorizontalScrollIndicator={false}>
                          <Text style={styles.codeText}>
                            {block.code.slice(0, 1000)}{block.code.length > 1000 ? '\n...' : ''}
                          </Text>
                        </ScrollView>
                      ) : (
                        <Text style={styles.codePreviewLine} numberOfLines={2}>
                          {block.code.split('\n')[0]}
                        </Text>
                      )}

                      {/* Action */}
                      <View style={styles.blockActions}>
                        {isSaved ? (
                          <View style={styles.savedBadge}>
                            <MaterialIcons name="check-circle" size={14} color={Colors.green} />
                            <Text style={styles.savedText}>تم الحفظ</Text>
                          </View>
                        ) : (
                          <Button
                            label={existingFile ? 'تحديث الملف' : (block.kind === 'markdown' ? 'حفظ كوثيقة' : 'حفظ كملف')}
                            onPress={() => handleSave(block)}
                            variant="primary"
                            size="sm"
                            icon={<MaterialIcons name={existingFile ? 'sync' : 'save'} size={13} color="#fff" />}
                          />
                        )}
                      </View>
                    </View>
                  );
                })}
              </ScrollView>

              {/* Footer */}
              {blocks.length > 1 && remaining > 0 && (
                <View style={styles.footer}>
                  <Button
                    label={`حفظ الكل (${remaining} متبقي)`}
                    onPress={handleSaveAll}
                    variant="secondary"
                    fullWidth
                    icon={<MaterialIcons name="save-alt" size={15} color={Colors.accent} />}
                  />
                </View>
              )}
            </>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, justifyContent: 'flex-end' },
  backdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.6)' },
  panel: {
    backgroundColor: Colors.bgCard,
    borderTopLeftRadius: Radius.xl, borderTopRightRadius: Radius.xl,
    maxHeight: '85%',
    borderTopWidth: 1, borderColor: Colors.border,
    ...Shadow.card,
  },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: Spacing.base, borderBottomWidth: 1, borderBottomColor: Colors.borderSubtle,
  },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  headerTitle: { color: Colors.textPrimary, fontSize: Typography.sizes.md, fontWeight: '600' },
  autoToggleRow: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  autoToggleLabel: { color: Colors.textMuted, fontSize: Typography.sizes.xs, fontWeight: '500' },

  noProject: { padding: Spacing.xxl, alignItems: 'center', gap: Spacing.sm },
  noProjectText: { color: Colors.textSecondary, fontSize: Typography.sizes.base, textAlign: 'center' },

  projectIndicator: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.sm,
    backgroundColor: Colors.bgSecondary,
  },
  projectName: { color: Colors.textSecondary, fontSize: Typography.sizes.sm, flex: 1 },
  projectFilesCount: { color: Colors.textMuted, fontSize: Typography.sizes.xs },

  blocksList: { maxHeight: 420 },
  blockCard: {
    margin: Spacing.sm, marginBottom: 0,
    backgroundColor: Colors.bgSecondary,
    borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border,
    overflow: 'hidden',
  },
  blockCardSaved: { borderColor: Colors.green + '55' },
  blockHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: Spacing.sm,
  },
  blockHeaderLeft: { flexDirection: 'row', gap: 6 },

  filenameRow: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: Spacing.sm, paddingBottom: Spacing.sm,
  },
  filenameInput: {
    flex: 1, color: Colors.textPrimary,
    fontSize: Typography.sizes.sm, fontFamily: 'monospace',
    borderBottomWidth: 1, borderBottomColor: Colors.border, paddingVertical: 2,
  },
  lineCount: { color: Colors.textMuted, fontSize: Typography.sizes.xs },

  contextHint: {
    color: Colors.textMuted, fontSize: Typography.sizes.xs,
    paddingHorizontal: Spacing.sm, paddingBottom: Spacing.sm,
    fontStyle: 'italic',
  },

  codePreview: {
    backgroundColor: Colors.bg, maxHeight: 120,
    borderTopWidth: 1, borderTopColor: Colors.borderSubtle,
  },
  codeText: {
    color: Colors.textSecondary, fontFamily: 'monospace',
    fontSize: Typography.sizes.xs, padding: Spacing.sm, lineHeight: 16,
  },
  codePreviewLine: {
    color: Colors.textMuted, fontFamily: 'monospace',
    fontSize: Typography.sizes.xs, paddingHorizontal: Spacing.sm, paddingBottom: Spacing.sm,
  },

  blockActions: {
    flexDirection: 'row', justifyContent: 'flex-end',
    padding: Spacing.sm, borderTopWidth: 1, borderTopColor: Colors.borderSubtle,
  },
  savedBadge: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  savedText: { color: Colors.green, fontSize: Typography.sizes.sm },

  footer: { padding: Spacing.base, borderTopWidth: 1, borderTopColor: Colors.borderSubtle },
});
