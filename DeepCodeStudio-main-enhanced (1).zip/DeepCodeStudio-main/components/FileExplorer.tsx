import React, { useState, useCallback, useRef, useEffect } from 'react';
import {
  View, Text, ScrollView, Pressable, StyleSheet,
  TextInput, Animated, Platform,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, Radius } from '@/constants/theme';
import { useProjects } from '@/hooks/useProjects';
import { useAlert } from '@/template';
import { ProjectFile } from '@/services/projectService';

// ─── File icon map ────────────────────────────────────────────────────────────

const FILE_META: Record<string, { icon: keyof typeof MaterialIcons.glyphMap; color: string }> = {
  js:   { icon: 'code',              color: '#d29922' },
  ts:   { icon: 'code',              color: '#2f81f7' },
  tsx:  { icon: 'code',              color: '#4d6aff' },
  jsx:  { icon: 'code',              color: '#d29922' },
  html: { icon: 'html',              color: '#db6d28' },
  css:  { icon: 'css',               color: '#2f81f7' },
  scss: { icon: 'css',               color: '#bc8cff' },
  json: { icon: 'data-object',       color: '#3fb950' },
  py:   { icon: 'code',              color: '#3fb950' },
  sh:   { icon: 'terminal',          color: '#8b949e' },
  md:   { icon: 'article',           color: '#58a6ff' },
  sql:  { icon: 'storage',           color: '#bc8cff' },
  go:   { icon: 'code',              color: '#39d353' },
  rs:   { icon: 'code',              color: '#db6d28' },
  dart: { icon: 'code',              color: '#2f81f7' },
  kt:   { icon: 'code',              color: '#bc8cff' },
  swift:{ icon: 'code',              color: '#db6d28' },
  yml:  { icon: 'settings',          color: '#d29922' },
  yaml: { icon: 'settings',          color: '#d29922' },
  xml:  { icon: 'code',              color: '#db6d28' },
  txt:  { icon: 'text-snippet',      color: '#8b949e' },
  env:  { icon: 'lock',              color: '#d29922' },
  gitignore: { icon: 'commit',       color: '#8b949e' },
};

function getFileMeta(filename: string) {
  const parts = filename.split('.');
  const ext = parts.length > 1 ? parts.pop()! : '';
  const base = parts.join('.');
  if (filename === '.env' || base === '.env') return { icon: 'lock' as const, color: '#d29922' };
  if (filename === '.gitignore') return { icon: 'commit' as const, color: '#8b949e' };
  if (filename === 'README.md') return { icon: 'menu-book' as const, color: '#58a6ff' };
  return FILE_META[ext.toLowerCase()] || { icon: 'insert-drive-file' as const, color: '#8b949e' };
}

function getLangColor(language: string): string {
  const map: Record<string, string> = {
    javascript: '#d29922', typescript: '#2f81f7',
    python: '#3fb950', html: '#db6d28', css: '#2f81f7',
    go: '#39d353', rust: '#db6d28', dart: '#2f81f7',
    json: '#3fb950', sql: '#bc8cff', bash: '#8b949e',
    shell: '#8b949e', markdown: '#58a6ff',
  };
  return map[language?.toLowerCase()] || '#8b949e';
}

function formatSize(content: string): string {
  const bytes = new TextEncoder().encode(content).length;
  if (bytes < 1024) return `${bytes} B`;
  return `${(bytes / 1024).toFixed(1)} KB`;
}

function formatTime(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  if (diffMins < 1) return 'الآن';
  if (diffMins < 60) return `${diffMins}د`;
  const diffH = Math.floor(diffMins / 60);
  if (diffH < 24) return `${diffH}س`;
  return d.toLocaleDateString('ar', { month: 'short', day: 'numeric' });
}

// ─── Markdown Preview ─────────────────────────────────────────────────────────

interface MarkdownToken {
  type: 'h1' | 'h2' | 'h3' | 'bold' | 'italic' | 'code_inline' | 'link' | 'list' | 'blockquote' | 'hr' | 'code_block' | 'plain';
  text: string;
  lang?: string;
}

function parseMarkdownLine(line: string): MarkdownToken {
  if (/^#{3}\s/.test(line)) return { type: 'h3', text: line.replace(/^###\s/, '') };
  if (/^#{2}\s/.test(line)) return { type: 'h2', text: line.replace(/^##\s/, '') };
  if (/^#\s/.test(line)) return { type: 'h1', text: line.replace(/^#\s/, '') };
  if (/^---+$/.test(line.trim())) return { type: 'hr', text: '' };
  if (/^>\s/.test(line)) return { type: 'blockquote', text: line.replace(/^>\s?/, '') };
  if (/^[-*+]\s/.test(line)) return { type: 'list', text: line.replace(/^[-*+]\s/, '') };
  if (/^\d+\.\s/.test(line)) return { type: 'list', text: line.replace(/^\d+\.\s/, '') };
  return { type: 'plain', text: line };
}

function renderInlineMarkdown(text: string): React.ReactNode[] {
  const parts: React.ReactNode[] = [];
  let remaining = text;
  let key = 0;

  while (remaining.length > 0) {
    // Bold+italic ***text***
    const boldItalic = remaining.match(/^\*\*\*(.+?)\*\*\*/);
    if (boldItalic) {
      parts.push(<Text key={key++} style={mdStyles.boldItalic}>{boldItalic[1]}</Text>);
      remaining = remaining.slice(boldItalic[0].length);
      continue;
    }
    // Bold **text**
    const bold = remaining.match(/^\*\*(.+?)\*\*/);
    if (bold) {
      parts.push(<Text key={key++} style={mdStyles.bold}>{bold[1]}</Text>);
      remaining = remaining.slice(bold[0].length);
      continue;
    }
    // Italic *text* or _text_
    const italic = remaining.match(/^[*_](.+?)[*_]/);
    if (italic) {
      parts.push(<Text key={key++} style={mdStyles.italic}>{italic[1]}</Text>);
      remaining = remaining.slice(italic[0].length);
      continue;
    }
    // Inline code `code`
    const code = remaining.match(/^`([^`]+)`/);
    if (code) {
      parts.push(<Text key={key++} style={mdStyles.inlineCode}>{code[1]}</Text>);
      remaining = remaining.slice(code[0].length);
      continue;
    }
    // Link [text](url)
    const link = remaining.match(/^\[(.+?)\]\((.+?)\)/);
    if (link) {
      parts.push(<Text key={key++} style={mdStyles.link}>{link[1]}</Text>);
      remaining = remaining.slice(link[0].length);
      continue;
    }
    // Plain char
    // Accumulate plain text
    let plain = '';
    while (remaining.length > 0 && !/^[\*_`\[]/.test(remaining)) {
      plain += remaining[0];
      remaining = remaining.slice(1);
    }
    if (plain) {
      parts.push(<Text key={key++} style={mdStyles.plain}>{plain}</Text>);
    } else {
      plain = remaining[0];
      remaining = remaining.slice(1);
      parts.push(<Text key={key++} style={mdStyles.plain}>{plain}</Text>);
    }
  }
  return parts;
}

interface MarkdownPreviewProps {
  content: string;
  maxLines?: number;
}

function MarkdownPreview({ content, maxLines = 40 }: MarkdownPreviewProps) {
  const lines = content.split('\n').slice(0, maxLines);
  const elements: React.ReactNode[] = [];
  let i = 0;
  let codeBlockLines: string[] = [];
  let inCodeBlock = false;
  let codeLang = '';

  while (i < lines.length) {
    const line = lines[i];

    // Code block start
    if (/^```/.test(line)) {
      if (!inCodeBlock) {
        inCodeBlock = true;
        codeLang = line.replace(/^```/, '').trim();
        codeBlockLines = [];
      } else {
        // End code block
        inCodeBlock = false;
        elements.push(
          <View key={`cb_${i}`} style={mdStyles.codeBlock}>
            {codeLang ? (
              <View style={mdStyles.codeLangBar}>
                <Text style={mdStyles.codeLang}>{codeLang}</Text>
              </View>
            ) : null}
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <Text style={mdStyles.codeBlockText}>{codeBlockLines.join('\n')}</Text>
            </ScrollView>
          </View>
        );
        codeBlockLines = [];
        codeLang = '';
      }
      i++;
      continue;
    }

    if (inCodeBlock) {
      codeBlockLines.push(line);
      i++;
      continue;
    }

    if (line.trim() === '') {
      elements.push(<View key={`sp_${i}`} style={{ height: 6 }} />);
      i++;
      continue;
    }

    const token = parseMarkdownLine(line);

    if (token.type === 'h1') {
      elements.push(
        <Text key={i} style={mdStyles.h1}>{renderInlineMarkdown(token.text)}</Text>
      );
    } else if (token.type === 'h2') {
      elements.push(
        <Text key={i} style={mdStyles.h2}>{renderInlineMarkdown(token.text)}</Text>
      );
    } else if (token.type === 'h3') {
      elements.push(
        <Text key={i} style={mdStyles.h3}>{renderInlineMarkdown(token.text)}</Text>
      );
    } else if (token.type === 'hr') {
      elements.push(<View key={i} style={mdStyles.hr} />);
    } else if (token.type === 'blockquote') {
      elements.push(
        <View key={i} style={mdStyles.blockquote}>
          <Text style={mdStyles.blockquoteText}>{renderInlineMarkdown(token.text)}</Text>
        </View>
      );
    } else if (token.type === 'list') {
      elements.push(
        <View key={i} style={mdStyles.listItem}>
          <Text style={mdStyles.listBullet}>•</Text>
          <Text style={mdStyles.listText}>{renderInlineMarkdown(token.text)}</Text>
        </View>
      );
    } else {
      elements.push(
        <Text key={i} style={mdStyles.paragraph}>{renderInlineMarkdown(token.text)}</Text>
      );
    }
    i++;
  }

  // Truncation notice
  if (content.split('\n').length > maxLines) {
    elements.push(
      <Text key="trunc" style={mdStyles.truncNote}>
        ... {content.split('\n').length - maxLines} سطر إضافي
      </Text>
    );
  }

  return <View style={mdStyles.container}>{elements}</View>;
}

const mdStyles = StyleSheet.create({
  container: { padding: Spacing.sm },
  h1: {
    color: '#e6edf3', fontSize: 15, fontWeight: '700',
    marginBottom: 4, borderBottomWidth: 1, borderBottomColor: Colors.borderSubtle,
    paddingBottom: 4,
  },
  h2: { color: '#cdd9e5', fontSize: 13, fontWeight: '700', marginBottom: 3 },
  h3: { color: '#adbac7', fontSize: 12, fontWeight: '600', marginBottom: 2 },
  hr: { height: 1, backgroundColor: Colors.border, marginVertical: 6 },
  blockquote: {
    borderLeftWidth: 3, borderLeftColor: Colors.accent,
    paddingLeft: 8, marginVertical: 2,
    backgroundColor: Colors.accentGlow,
    borderRadius: 2,
  },
  blockquoteText: { color: Colors.textSecondary, fontSize: 11, fontStyle: 'italic' },
  listItem: { flexDirection: 'row', alignItems: 'flex-start', gap: 6, marginBottom: 2 },
  listBullet: { color: Colors.accent, fontSize: 11, lineHeight: 17 },
  listText: { color: Colors.textSecondary, fontSize: 11, flex: 1, lineHeight: 17 },
  paragraph: { color: Colors.textSecondary, fontSize: 11, lineHeight: 17, marginBottom: 2 },
  codeBlock: {
    backgroundColor: Colors.bg, borderRadius: Radius.sm,
    borderWidth: 1, borderColor: Colors.border,
    marginVertical: 4, overflow: 'hidden',
  },
  codeLangBar: {
    backgroundColor: Colors.bgTertiary,
    paddingHorizontal: 8, paddingVertical: 3,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  codeLang: { color: Colors.accent, fontSize: 9, fontFamily: 'monospace', fontWeight: '700' },
  codeBlockText: {
    color: '#a5d6ff', fontSize: 10, fontFamily: 'monospace',
    lineHeight: 16, padding: 6,
  },
  // Inline
  plain: { color: Colors.textSecondary, fontSize: 11 },
  bold: { color: '#e6edf3', fontWeight: '700', fontSize: 11 },
  italic: { color: Colors.textSecondary, fontStyle: 'italic', fontSize: 11 },
  boldItalic: { color: '#e6edf3', fontWeight: '700', fontStyle: 'italic', fontSize: 11 },
  inlineCode: {
    color: '#ff7b72', backgroundColor: Colors.bgTertiary,
    fontFamily: 'monospace', fontSize: 10,
    borderRadius: 3, paddingHorizontal: 3,
  },
  link: { color: Colors.accent, fontSize: 11, textDecorationLine: 'underline' },
  truncNote: { color: Colors.textMuted, fontSize: 10, fontStyle: 'italic', marginTop: 4 },
});

// ─── Markdown File Preview Panel ──────────────────────────────────────────────

function MarkdownPreviewPanel({ file, onClose }: { file: ProjectFile; onClose: () => void }) {
  const slideAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.spring(slideAnim, { toValue: 1, useNativeDriver: true, tension: 150, friction: 10 }).start();
  }, []);

  const handleClose = () => {
    Animated.timing(slideAnim, { toValue: 0, duration: 180, useNativeDriver: true }).start(onClose);
  };

  const translateY = slideAnim.interpolate({ inputRange: [0, 1], outputRange: [20, 0] });

  return (
    <Animated.View style={[previewStyles.container, { opacity: slideAnim, transform: [{ translateY }] }]}>
      {/* Panel header */}
      <View style={previewStyles.header}>
        <MaterialIcons name="article" size={13} color={Colors.accent} />
        <Text style={previewStyles.title} numberOfLines={1}>{file.name}</Text>
        <Pressable onPress={handleClose} hitSlop={8} style={({ pressed }) => [pressed && { opacity: 0.6 }]}>
          <MaterialIcons name="close" size={15} color={Colors.textSecondary} />
        </Pressable>
      </View>
      <ScrollView style={previewStyles.scroll} showsVerticalScrollIndicator={false}>
        <MarkdownPreview content={file.content} maxLines={80} />
        <View style={{ height: 16 }} />
      </ScrollView>
    </Animated.View>
  );
}

const previewStyles = StyleSheet.create({
  container: {
    position: 'absolute', top: 0, bottom: 0, left: 0, right: 0,
    backgroundColor: Colors.bg, zIndex: 200,
  },
  header: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: Spacing.sm, paddingVertical: 7,
    backgroundColor: Colors.bgSecondary,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  title: {
    flex: 1, color: Colors.textPrimary,
    fontSize: Typography.sizes.xs, fontFamily: 'monospace', fontWeight: '600',
  },
  scroll: { flex: 1 },
});

// ─── Sort options ─────────────────────────────────────────────────────────────

type SortMode = 'name' | 'updated' | 'created' | 'size' | 'type';
type ViewMode = 'tree' | 'list' | 'grid';

function sortFiles(files: ProjectFile[], mode: SortMode): ProjectFile[] {
  return [...files].sort((a, b) => {
    if (mode === 'name') return a.name.localeCompare(b.name);
    if (mode === 'updated') return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
    if (mode === 'created') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    if (mode === 'size') return b.content.length - a.content.length;
    if (mode === 'type') {
      const extA = a.name.split('.').pop() || '';
      const extB = b.name.split('.').pop() || '';
      return extA.localeCompare(extB);
    }
    return 0;
  });
}

// ─── New File Inline Form ─────────────────────────────────────────────────────

function NewFileForm({ onSubmit, onCancel }: { onSubmit: (name: string) => void; onCancel: () => void }) {
  const [name, setName] = useState('');
  return (
    <View style={formStyles.row}>
      <MaterialIcons name="insert-drive-file" size={13} color={Colors.accent} />
      <TextInput
        style={formStyles.input}
        value={name}
        onChangeText={setName}
        autoFocus
        autoCapitalize="none"
        autoCorrect={false}
        placeholder="filename.ts"
        placeholderTextColor={Colors.textMuted}
        returnKeyType="done"
        onSubmitEditing={() => name.trim() && onSubmit(name.trim())}
        onBlur={() => !name.trim() && onCancel()}
      />
      <Pressable onPress={() => name.trim() && onSubmit(name.trim())} hitSlop={6}>
        <MaterialIcons name="check" size={15} color={Colors.green} />
      </Pressable>
      <Pressable onPress={onCancel} hitSlop={6}>
        <MaterialIcons name="close" size={15} color={Colors.error} />
      </Pressable>
    </View>
  );
}

const formStyles = StyleSheet.create({
  row: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: Spacing.sm, paddingVertical: 4,
    marginLeft: 20, marginRight: 6, marginBottom: 2,
    backgroundColor: Colors.bgCard,
    borderRadius: Radius.sm,
    borderWidth: 1, borderColor: Colors.accent + '66',
  },
  input: {
    flex: 1, color: Colors.textPrimary,
    fontSize: Typography.sizes.sm, fontFamily: 'monospace',
    paddingVertical: 2,
  },
});

// ─── Rename Inline Form ───────────────────────────────────────────────────────

function RenameForm({
  currentName,
  onSubmit,
  onCancel,
}: { currentName: string; onSubmit: (name: string) => void; onCancel: () => void }) {
  const [name, setName] = useState(currentName);
  return (
    <View style={[formStyles.row, { borderColor: Colors.yellow + '66' }]}>
      <TextInput
        style={formStyles.input}
        value={name}
        onChangeText={setName}
        autoFocus
        selectTextOnFocus
        autoCapitalize="none"
        autoCorrect={false}
        returnKeyType="done"
        onSubmitEditing={() => name.trim() && onSubmit(name.trim())}
        onBlur={() => onCancel()}
      />
      <Pressable onPress={() => name.trim() && onSubmit(name.trim())} hitSlop={6}>
        <MaterialIcons name="check" size={15} color={Colors.green} />
      </Pressable>
    </View>
  );
}

// ─── File Context Menu ────────────────────────────────────────────────────────

interface ContextMenuProps {
  file: ProjectFile;
  onClose: () => void;
  onDelete: () => void;
  onRename: () => void;
  onCopy: () => void;
  onPreview?: () => void;
}

function ContextMenu({ file, onClose, onDelete, onRename, onCopy, onPreview }: ContextMenuProps) {
  const scale = useRef(new Animated.Value(0.85)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const isMarkdown = file.name.endsWith('.md') || file.language === 'markdown';

  useEffect(() => {
    Animated.parallel([
      Animated.spring(scale, { toValue: 1, useNativeDriver: true, tension: 200, friction: 12 }),
      Animated.timing(opacity, { toValue: 1, duration: 120, useNativeDriver: true }),
    ]).start();
  }, []);

  const actions = [
    ...(isMarkdown && onPreview ? [
      { icon: 'preview' as const, label: 'معاينة Markdown', color: Colors.accent, onPress: onPreview },
    ] : []),
    { icon: 'edit' as const, label: 'إعادة تسمية', color: Colors.accent, onPress: onRename },
    { icon: 'content-copy' as const, label: 'نسخ المحتوى', color: Colors.textSecondary, onPress: onCopy },
    { icon: 'delete-outline' as const, label: 'حذف الملف', color: Colors.error, onPress: onDelete },
  ];

  return (
    <Animated.View style={[cmStyles.container, { transform: [{ scale }], opacity }]}>
      <View style={cmStyles.fileInfo}>
        <Text style={cmStyles.fileName} numberOfLines={1}>{file.name}</Text>
        <Text style={cmStyles.fileMeta}>{formatSize(file.content)} · {file.language.toUpperCase()}</Text>
      </View>
      <View style={cmStyles.divider} />
      {actions.map((a, i) => (
        <Pressable
          key={i}
          onPress={() => { a.onPress(); onClose(); }}
          style={({ pressed }) => [cmStyles.action, pressed && { backgroundColor: Colors.bgHover }]}
        >
          <MaterialIcons name={a.icon} size={16} color={a.color} />
          <Text style={[cmStyles.actionText, { color: a.color }]}>{a.label}</Text>
        </Pressable>
      ))}
    </Animated.View>
  );
}

const cmStyles = StyleSheet.create({
  container: {
    backgroundColor: Colors.bgCard, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border,
    minWidth: 170, overflow: 'hidden',
    shadowColor: '#000', shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.5, shadowRadius: 16, elevation: 12,
  },
  fileInfo: { padding: Spacing.sm, paddingBottom: 6 },
  fileName: { color: Colors.textPrimary, fontSize: Typography.sizes.sm, fontFamily: 'monospace', fontWeight: '600' },
  fileMeta: { color: Colors.textMuted, fontSize: 10, marginTop: 2 },
  divider: { height: 1, backgroundColor: Colors.borderSubtle },
  action: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    paddingHorizontal: Spacing.sm, paddingVertical: 9,
  },
  actionText: { fontSize: Typography.sizes.sm, fontWeight: '500' },
});

// ─── Inline Markdown Preview Tooltip ─────────────────────────────────────────

function MarkdownTooltip({ file }: { file: ProjectFile }) {
  const lines = file.content.split('\n').slice(0, 5);
  const firstH = lines.find(l => /^#+\s/.test(l))?.replace(/^#+\s/, '') || '';
  const firstPara = lines.find(l => l.trim() && !/^#+/.test(l) && !/^```/.test(l)) || '';
  const hasCode = file.content.includes('```');

  return (
    <View style={ttStyles.container}>
      {firstH ? (
        <Text style={ttStyles.h1} numberOfLines={1}># {firstH}</Text>
      ) : null}
      {firstPara ? (
        <Text style={ttStyles.para} numberOfLines={2}>{firstPara}</Text>
      ) : null}
      <View style={ttStyles.chips}>
        <View style={ttStyles.chip}>
          <MaterialIcons name="format-list-bulleted" size={9} color={Colors.textMuted} />
          <Text style={ttStyles.chipText}>{file.content.split('\n').length} سطر</Text>
        </View>
        {hasCode ? (
          <View style={ttStyles.chip}>
            <MaterialIcons name="code" size={9} color={Colors.accent} />
            <Text style={[ttStyles.chipText, { color: Colors.accent }]}>يحتوي كود</Text>
          </View>
        ) : null}
      </View>
    </View>
  );
}

const ttStyles = StyleSheet.create({
  container: {
    backgroundColor: Colors.bgCard, borderRadius: Radius.sm,
    borderWidth: 1, borderColor: Colors.accent + '33',
    marginLeft: 24, marginRight: 4, marginBottom: 2,
    padding: 7,
  },
  h1: { color: Colors.accent, fontSize: 10, fontWeight: '700', marginBottom: 2 },
  para: { color: Colors.textMuted, fontSize: 10, lineHeight: 14, marginBottom: 4 },
  chips: { flexDirection: 'row', gap: 5 },
  chip: {
    flexDirection: 'row', alignItems: 'center', gap: 2,
    backgroundColor: Colors.bgTertiary, borderRadius: 3,
    paddingHorizontal: 4, paddingVertical: 2,
  },
  chipText: { color: Colors.textMuted, fontSize: 9 },
});

// ─── File Row (Tree mode) ─────────────────────────────────────────────────────

interface FileRowProps {
  file: ProjectFile;
  isActive: boolean;
  isRenaming: boolean;
  showContextMenu: boolean;
  showTooltip: boolean;
  onPress: () => void;
  onLongPress: () => void;
  onRenameSubmit: (name: string) => void;
  onRenameCancel: () => void;
  onContextClose: () => void;
  onDelete: () => void;
  onRename: () => void;
  onCopy: () => void;
  onPreview: () => void;
  isNew?: boolean;
}

function FileRow({
  file, isActive, isRenaming, showContextMenu, showTooltip,
  onPress, onLongPress, onRenameSubmit, onRenameCancel,
  onContextClose, onDelete, onRename, onCopy, onPreview, isNew,
}: FileRowProps) {
  const { icon, color } = getFileMeta(file.name);
  const highlightAnim = useRef(new Animated.Value(isNew ? 1 : 0)).current;
  const isMarkdown = file.name.endsWith('.md') || file.language === 'markdown';

  useEffect(() => {
    if (isNew) {
      Animated.sequence([
        Animated.timing(highlightAnim, { toValue: 1, duration: 0, useNativeDriver: false }),
        Animated.delay(200),
        Animated.timing(highlightAnim, { toValue: 0, duration: 1500, useNativeDriver: false }),
      ]).start();
    }
  }, [isNew]);

  const bgColor = highlightAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['transparent', Colors.green + '22'],
  });

  if (isRenaming) {
    return (
      <RenameForm
        currentName={file.name}
        onSubmit={onRenameSubmit}
        onCancel={onRenameCancel}
      />
    );
  }

  return (
    <View>
      <Pressable
        onPress={onPress}
        onLongPress={onLongPress}
        delayLongPress={400}
        style={({ pressed }) => [pressed && styles.fileRowPressed]}
      >
        <Animated.View style={[
          styles.fileRow,
          isActive && styles.fileRowActive,
          { backgroundColor: isActive ? Colors.accentGlow : bgColor as any },
        ]}>
          <View style={styles.fileRowInner}>
            <MaterialIcons name={icon} size={14} color={isActive ? Colors.accent : color} />
            <Text
              style={[styles.fileName, isActive && styles.fileNameActive]}
              numberOfLines={1}
            >
              {file.name}
            </Text>
            {isMarkdown ? (
              <View style={styles.mdBadge}>
                <Text style={styles.mdBadgeText}>MD</Text>
              </View>
            ) : null}
          </View>
          <View style={styles.fileRowMeta}>
            <Text style={styles.fileTime}>{formatTime(file.updatedAt)}</Text>
            {isActive ? <View style={styles.activeDot} /> : null}
          </View>
        </Animated.View>
      </Pressable>

      {/* Markdown tooltip when active */}
      {isActive && isMarkdown && showTooltip ? (
        <MarkdownTooltip file={file} />
      ) : null}

      {showContextMenu ? (
        <View style={styles.contextMenuWrap}>
          <ContextMenu
            file={file}
            onClose={onContextClose}
            onDelete={onDelete}
            onRename={onRename}
            onCopy={onCopy}
            onPreview={isMarkdown ? onPreview : undefined}
          />
        </View>
      ) : null}
    </View>
  );
}

// ─── Grid Card ────────────────────────────────────────────────────────────────

function GridCard({ file, isActive, onPress, onLongPress }: {
  file: ProjectFile;
  isActive: boolean;
  onPress: () => void;
  onLongPress: () => void;
}) {
  const { icon, color } = getFileMeta(file.name);
  const lines = file.content.split('\n').length;
  const isMarkdown = file.name.endsWith('.md') || file.language === 'markdown';

  return (
    <Pressable
      onPress={onPress}
      onLongPress={onLongPress}
      delayLongPress={400}
      style={({ pressed }) => [
        gridStyles.card,
        isActive && gridStyles.cardActive,
        pressed && { opacity: 0.8 },
      ]}
    >
      <View style={[gridStyles.iconWrap, { backgroundColor: color + '22' }]}>
        <MaterialIcons name={icon} size={22} color={color} />
      </View>
      <View style={gridStyles.nameRow}>
        <Text style={[gridStyles.name, isActive && { color: Colors.accent }]} numberOfLines={2}>
          {file.name}
        </Text>
        {isMarkdown ? <View style={gridStyles.mdBadge}><Text style={gridStyles.mdBadgeText}>MD</Text></View> : null}
      </View>
      <Text style={gridStyles.meta}>{lines} سطر · {formatSize(file.content)}</Text>
    </Pressable>
  );
}

const gridStyles = StyleSheet.create({
  card: {
    width: '48%', backgroundColor: Colors.bgCard,
    borderRadius: Radius.md, padding: Spacing.sm,
    borderWidth: 1, borderColor: Colors.border,
    gap: 6, alignItems: 'flex-start',
  },
  cardActive: { borderColor: Colors.accent + '88', backgroundColor: Colors.accentGlow },
  iconWrap: {
    width: 38, height: 38, borderRadius: Radius.sm,
    alignItems: 'center', justifyContent: 'center',
  },
  nameRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 4, flexWrap: 'wrap' },
  name: {
    color: Colors.textPrimary, fontSize: Typography.sizes.xs,
    fontFamily: 'monospace', fontWeight: '600', lineHeight: 15, flex: 1,
  },
  meta: { color: Colors.textMuted, fontSize: 10 },
  mdBadge: {
    backgroundColor: Colors.accent + '22', borderRadius: 3,
    paddingHorizontal: 4, paddingVertical: 1,
    borderWidth: 1, borderColor: Colors.accent + '44',
  },
  mdBadgeText: { color: Colors.accent, fontSize: 8, fontWeight: '700' },
});

// ─── Search bar ───────────────────────────────────────────────────────────────

function SearchBar({ value, onChange, onClose }: { value: string; onChange: (v: string) => void; onClose: () => void }) {
  return (
    <View style={searchStyles.container}>
      <MaterialIcons name="search" size={14} color={Colors.textMuted} />
      <TextInput
        style={searchStyles.input}
        value={value}
        onChangeText={onChange}
        autoFocus
        placeholder="بحث في الملفات..."
        placeholderTextColor={Colors.textMuted}
        autoCapitalize="none"
        autoCorrect={false}
      />
      {value ? (
        <Pressable onPress={() => onChange('')} hitSlop={6}>
          <MaterialIcons name="close" size={14} color={Colors.textMuted} />
        </Pressable>
      ) : (
        <Pressable onPress={onClose} hitSlop={6}>
          <MaterialIcons name="keyboard-arrow-up" size={14} color={Colors.textMuted} />
        </Pressable>
      )}
    </View>
  );
}

const searchStyles = StyleSheet.create({
  container: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: Colors.bg,
    borderBottomWidth: 1, borderBottomColor: Colors.borderSubtle,
    paddingHorizontal: Spacing.sm, paddingVertical: 5,
  },
  input: {
    flex: 1, color: Colors.textPrimary,
    fontSize: Typography.sizes.sm, paddingVertical: 2,
  },
});

// ─── Sort Menu ────────────────────────────────────────────────────────────────

function SortMenu({ current, onSelect, onClose }: { current: SortMode; onSelect: (s: SortMode) => void; onClose: () => void }) {
  const opts: { key: SortMode; label: string; icon: keyof typeof MaterialIcons.glyphMap }[] = [
    { key: 'name', label: 'الاسم', icon: 'sort-by-alpha' },
    { key: 'updated', label: 'آخر تعديل', icon: 'update' },
    { key: 'created', label: 'تاريخ الإنشاء', icon: 'schedule' },
    { key: 'size', label: 'الحجم', icon: 'data-usage' },
    { key: 'type', label: 'النوع', icon: 'category' },
  ];

  return (
    <View style={sortStyles.menu}>
      {opts.map(o => (
        <Pressable
          key={o.key}
          onPress={() => { onSelect(o.key); onClose(); }}
          style={({ pressed }) => [sortStyles.item, pressed && { backgroundColor: Colors.bgHover }]}
        >
          <MaterialIcons name={o.icon} size={14} color={current === o.key ? Colors.accent : Colors.textSecondary} />
          <Text style={[sortStyles.label, current === o.key && { color: Colors.accent }]}>{o.label}</Text>
          {current === o.key ? <MaterialIcons name="check" size={12} color={Colors.accent} /> : null}
        </Pressable>
      ))}
    </View>
  );
}

const sortStyles = StyleSheet.create({
  menu: {
    position: 'absolute', top: 34, right: 0, zIndex: 100,
    backgroundColor: Colors.bgCard, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border, minWidth: 150,
    shadowColor: '#000', shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4, shadowRadius: 12, elevation: 10,
  },
  item: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    paddingHorizontal: Spacing.sm, paddingVertical: 8,
  },
  label: { color: Colors.textSecondary, fontSize: Typography.sizes.sm, flex: 1 },
});

// ─── Stats bar ────────────────────────────────────────────────────────────────

function StatsBar({ files }: { files: ProjectFile[] }) {
  const langCounts: Record<string, number> = {};
  files.forEach(f => {
    const lang = f.language || f.name.split('.').pop() || 'other';
    langCounts[lang] = (langCounts[lang] || 0) + 1;
  });
  const topLangs = Object.entries(langCounts).sort((a, b) => b[1] - a[1]).slice(0, 3);

  return (
    <View style={statsStyles.container}>
      <Text style={statsStyles.count}>{files.length} ملف</Text>
      <View style={statsStyles.divider} />
      {topLangs.map(([lang, count]) => (
        <View key={lang} style={statsStyles.langChip}>
          <View style={[statsStyles.dot, { backgroundColor: getLangColor(lang) }]} />
          <Text style={statsStyles.langText}>{lang.toUpperCase()}</Text>
          <Text style={statsStyles.langCount}>{count}</Text>
        </View>
      ))}
    </View>
  );
}

const statsStyles = StyleSheet.create({
  container: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: Spacing.sm, paddingVertical: 5,
    gap: 6, flexWrap: 'wrap',
    borderTopWidth: 1, borderTopColor: Colors.borderSubtle,
  },
  count: { color: Colors.textMuted, fontSize: 10, fontWeight: '600' },
  divider: { width: 1, height: 10, backgroundColor: Colors.borderSubtle },
  langChip: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: Colors.bgTertiary, borderRadius: Radius.sm,
    paddingHorizontal: 5, paddingVertical: 2,
  },
  dot: { width: 5, height: 5, borderRadius: 2.5 },
  langText: { color: Colors.textSecondary, fontSize: 9, fontWeight: '600' },
  langCount: { color: Colors.textMuted, fontSize: 9 },
});

// ─── Main FileExplorer ────────────────────────────────────────────────────────

export function FileExplorer() {
  const {
    activeProject, activeFile, setActiveFile,
    deleteFile, addFileToProject, updateFileContent,
  } = useProjects();
  const { showAlert } = useAlert();

  const [expanded, setExpanded] = useState(true);
  const [viewMode, setViewMode] = useState<ViewMode>('tree');
  const [sortMode, setSortMode] = useState<SortMode>('updated');
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSortMenu, setShowSortMenu] = useState(false);
  const [showNewFile, setShowNewFile] = useState(false);
  const [contextMenuFile, setContextMenuFile] = useState<string | null>(null);
  const [renamingFile, setRenamingFile] = useState<string | null>(null);
  const [newlyCreated, setNewlyCreated] = useState<string | null>(null);
  const [previewFile, setPreviewFile] = useState<ProjectFile | null>(null);

  const handleNewFile = useCallback(async (name: string) => {
    if (!activeProject) return;
    const ext = name.split('.').pop() || '';
    const lang = ext === 'ts' || ext === 'tsx' ? 'typescript'
      : ext === 'js' || ext === 'jsx' ? 'javascript'
      : ext === 'py' ? 'python'
      : ext === 'html' ? 'html'
      : ext === 'css' ? 'css'
      : ext === 'json' ? 'json'
      : ext === 'md' ? 'markdown' : 'text';

    const exists = activeProject.files.find(f => f.name === name);
    if (exists) {
      showAlert('تنبيه', `الملف "${name}" موجود بالفعل`);
      return;
    }

    try {
      const newFile = await addFileToProject(activeProject.id, {
        name,
        language: lang,
        content: ext === 'md' ? `# ${name.replace('.md', '')}\n\n` : `// ${name}\n`,
      });
      setShowNewFile(false);
      setNewlyCreated(newFile.id);
      setActiveFile(newFile);
      setTimeout(() => setNewlyCreated(null), 2000);
    } catch {
      showAlert('خطأ', 'فشل إنشاء الملف');
    }
  }, [activeProject, addFileToProject, setActiveFile, showAlert]);

  const handleDelete = useCallback((file: ProjectFile) => {
    showAlert(
      'حذف الملف',
      `هل تريد حذف "${file.name}"؟ لا يمكن التراجع.`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف', style: 'destructive',
          onPress: async () => {
            await deleteFile(activeProject!.id, file.id);
            if (activeFile?.id === file.id) setActiveFile(null);
          },
        },
      ]
    );
  }, [activeProject, activeFile, deleteFile, setActiveFile, showAlert]);

  const handleRename = useCallback(async (file: ProjectFile, newName: string) => {
    if (!activeProject || newName === file.name) { setRenamingFile(null); return; }
    const exists = activeProject.files.find(f => f.name === newName && f.id !== file.id);
    if (exists) {
      showAlert('تنبيه', `الاسم "${newName}" مستخدم بالفعل`);
      setRenamingFile(null);
      return;
    }
    try {
      const updatedContent = file.content;
      await deleteFile(activeProject.id, file.id);
      const lang = file.language;
      const newFile = await addFileToProject(activeProject.id, {
        name: newName,
        language: lang,
        content: updatedContent,
      });
      if (activeFile?.id === file.id) setActiveFile(newFile);
    } catch {
      showAlert('خطأ', 'فشل إعادة التسمية');
    }
    setRenamingFile(null);
  }, [activeProject, activeFile, deleteFile, addFileToProject, setActiveFile, showAlert]);

  const handleCopyContent = useCallback(async (file: ProjectFile) => {
    try {
      const Clipboard = await import('expo-clipboard');
      await Clipboard.setStringAsync(file.content);
      showAlert('تم النسخ', `تم نسخ محتوى "${file.name}" إلى الحافظة`);
    } catch {
      showAlert('تنبيه', 'فشل النسخ');
    }
  }, [showAlert]);

  if (!activeProject) {
    return (
      <View style={styles.empty}>
        <View style={styles.emptyIconWrap}>
          <MaterialIcons name="folder-open" size={34} color={Colors.textMuted} />
        </View>
        <Text style={styles.emptyTitle}>لا يوجد مشروع</Text>
        <Text style={styles.emptyHint}>اختر مشروعاً من تبويب المشاريع</Text>
      </View>
    );
  }

  const filtered = sortFiles(
    searchQuery.trim()
      ? activeProject.files.filter(f =>
          f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          f.content.toLowerCase().includes(searchQuery.toLowerCase())
        )
      : activeProject.files,
    sortMode
  );

  const searchMatchCount = searchQuery.trim() ? filtered.length : 0;

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>EXPLORER</Text>
        <View style={styles.headerActions}>
          <Pressable
            onPress={() => { setShowSearch(!showSearch); if (showSearch) setSearchQuery(''); }}
            hitSlop={6}
            style={({ pressed }) => [styles.headerBtn, showSearch && styles.headerBtnActive, pressed && { opacity: 0.7 }]}
          >
            <MaterialIcons name="search" size={15} color={showSearch ? Colors.accent : Colors.textSecondary} />
          </Pressable>

          <Pressable
            onPress={() => setViewMode(v => v === 'tree' ? 'list' : v === 'list' ? 'grid' : 'tree')}
            hitSlop={6}
            style={({ pressed }) => [styles.headerBtn, pressed && { opacity: 0.7 }]}
          >
            <MaterialIcons
              name={viewMode === 'tree' ? 'account-tree' : viewMode === 'list' ? 'view-list' : 'grid-view'}
              size={15} color={Colors.textSecondary}
            />
          </Pressable>

          <View style={{ position: 'relative' }}>
            <Pressable
              onPress={() => setShowSortMenu(!showSortMenu)}
              hitSlop={6}
              style={({ pressed }) => [styles.headerBtn, showSortMenu && styles.headerBtnActive, pressed && { opacity: 0.7 }]}
            >
              <MaterialIcons name="sort" size={15} color={showSortMenu ? Colors.accent : Colors.textSecondary} />
            </Pressable>
            {showSortMenu ? (
              <SortMenu current={sortMode} onSelect={setSortMode} onClose={() => setShowSortMenu(false)} />
            ) : null}
          </View>

          <Pressable
            onPress={() => { setShowNewFile(true); setExpanded(true); }}
            hitSlop={6}
            style={({ pressed }) => [styles.headerBtn, styles.headerBtnNew, pressed && { opacity: 0.7 }]}
          >
            <MaterialIcons name="add" size={16} color={Colors.accent} />
          </Pressable>
        </View>
      </View>

      {/* Search */}
      {showSearch ? (
        <SearchBar
          value={searchQuery}
          onChange={setSearchQuery}
          onClose={() => { setShowSearch(false); setSearchQuery(''); }}
        />
      ) : null}

      {/* Project label */}
      <Pressable
        onPress={() => setExpanded(!expanded)}
        style={({ pressed }) => [styles.projectRow, pressed && { opacity: 0.7 }]}
      >
        <MaterialIcons
          name={expanded ? 'keyboard-arrow-down' : 'keyboard-arrow-right'}
          size={15} color={Colors.textSecondary}
        />
        <MaterialIcons name="folder-special" size={14} color={activeProject.color} />
        <Text style={[styles.projectName, { color: activeProject.color }]} numberOfLines={1}>
          {activeProject.name}
        </Text>
        {searchQuery ? (
          <View style={styles.matchBadge}>
            <Text style={styles.matchBadgeText}>{searchMatchCount}</Text>
          </View>
        ) : (
          <Text style={styles.fileCount}>{activeProject.files.length}</Text>
        )}
      </Pressable>

      {/* File list */}
      {expanded ? (
        <ScrollView
          style={styles.fileList}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {showNewFile ? (
            <NewFileForm
              onSubmit={handleNewFile}
              onCancel={() => setShowNewFile(false)}
            />
          ) : null}

          {filtered.length === 0 ? (
            <View style={styles.emptyFiles}>
              {searchQuery ? (
                <>
                  <MaterialIcons name="search-off" size={24} color={Colors.textMuted} />
                  <Text style={styles.emptyFilesText}>لا نتائج لـ "{searchQuery}"</Text>
                </>
              ) : (
                <>
                  <MaterialIcons name="insert-drive-file" size={24} color={Colors.textMuted} />
                  <Text style={styles.emptyFilesText}>لا توجد ملفات بعد</Text>
                  <Text style={styles.emptyFilesHint}>ابدأ محادثة مع DeepSeek أو أنشئ ملفاً</Text>
                  <Pressable
                    onPress={() => setShowNewFile(true)}
                    style={({ pressed }) => [styles.createFirstBtn, pressed && { opacity: 0.8 }]}
                  >
                    <MaterialIcons name="add" size={14} color={Colors.accent} />
                    <Text style={styles.createFirstBtnText}>إنشاء ملف جديد</Text>
                  </Pressable>
                </>
              )}
            </View>
          ) : viewMode === 'grid' ? (
            <View style={styles.gridWrap}>
              {filtered.map(file => (
                <GridCard
                  key={file.id}
                  file={file}
                  isActive={activeFile?.id === file.id}
                  onPress={() => { setContextMenuFile(null); setActiveFile(file); }}
                  onLongPress={() => setContextMenuFile(file.id)}
                />
              ))}
            </View>
          ) : (
            filtered.map(file => (
              <FileRow
                key={file.id}
                file={file}
                isActive={activeFile?.id === file.id}
                isRenaming={renamingFile === file.id}
                showContextMenu={contextMenuFile === file.id}
                showTooltip={activeFile?.id === file.id}
                isNew={newlyCreated === file.id}
                onPress={() => { setContextMenuFile(null); setActiveFile(file); }}
                onLongPress={() => { setContextMenuFile(contextMenuFile === file.id ? null : file.id); }}
                onRenameSubmit={(name) => handleRename(file, name)}
                onRenameCancel={() => setRenamingFile(null)}
                onContextClose={() => setContextMenuFile(null)}
                onDelete={() => handleDelete(file)}
                onRename={() => { setContextMenuFile(null); setRenamingFile(file.id); }}
                onCopy={() => handleCopyContent(file)}
                onPreview={() => { setContextMenuFile(null); setPreviewFile(file); }}
              />
            ))
          )}

          <View style={{ height: Spacing.base }} />
        </ScrollView>
      ) : null}

      {/* Stats bar */}
      <StatsBar files={activeProject.files} />

      {/* Markdown full preview overlay */}
      {previewFile ? (
        <MarkdownPreviewPanel
          file={previewFile}
          onClose={() => setPreviewFile(null)}
        />
      ) : null}
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bgSecondary },

  empty: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
    gap: 8, padding: Spacing.lg,
  },
  emptyIconWrap: {
    width: 60, height: 60, borderRadius: 14,
    backgroundColor: Colors.bgTertiary,
    alignItems: 'center', justifyContent: 'center',
  },
  emptyTitle: { color: Colors.textSecondary, fontSize: Typography.sizes.base, fontWeight: '600' },
  emptyHint: { color: Colors.textMuted, fontSize: Typography.sizes.xs, textAlign: 'center' },

  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: Spacing.sm, paddingVertical: 6,
    borderBottomWidth: 1, borderBottomColor: Colors.borderSubtle,
  },
  headerTitle: {
    flex: 1, color: Colors.textMuted, fontSize: 10,
    fontWeight: '700', letterSpacing: 1.4,
  },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  headerBtn: {
    width: 26, height: 26,
    alignItems: 'center', justifyContent: 'center',
    borderRadius: Radius.sm,
  },
  headerBtnActive: { backgroundColor: Colors.accentGlow },
  headerBtnNew: {
    backgroundColor: Colors.accent + '18',
    borderWidth: 1, borderColor: Colors.accent + '44',
    borderRadius: Radius.sm,
  },

  projectRow: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    paddingHorizontal: Spacing.sm, paddingVertical: 6,
    borderBottomWidth: 1, borderBottomColor: Colors.borderSubtle,
  },
  projectName: { flex: 1, fontSize: Typography.sizes.xs, fontWeight: '700' },
  fileCount: {
    color: Colors.textMuted, fontSize: 10,
    backgroundColor: Colors.bgTertiary, borderRadius: 8,
    paddingHorizontal: 5, paddingVertical: 1,
  },
  matchBadge: {
    backgroundColor: Colors.accent + '33', borderRadius: 8,
    paddingHorizontal: 5, paddingVertical: 1,
  },
  matchBadgeText: { color: Colors.accent, fontSize: 10, fontWeight: '700' },

  fileList: { flex: 1 },
  gridWrap: {
    flexDirection: 'row', flexWrap: 'wrap',
    gap: Spacing.sm, padding: Spacing.sm,
  },

  fileRow: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: Spacing.sm, paddingVertical: 5,
    borderRadius: Radius.sm, marginHorizontal: 4, marginBottom: 1,
  },
  fileRowActive: {},
  fileRowPressed: { backgroundColor: Colors.bgHover },
  fileRowInner: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 6 },
  fileName: {
    color: Colors.textSecondary, fontSize: Typography.sizes.xs,
    fontFamily: 'monospace', flex: 1,
  },
  fileNameActive: { color: Colors.accent, fontWeight: '600' },
  fileRowMeta: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  fileTime: { color: Colors.textMuted, fontSize: 9, fontFamily: 'monospace' },
  activeDot: { width: 5, height: 5, borderRadius: 2.5, backgroundColor: Colors.accent },
  contextMenuWrap: {
    marginLeft: Spacing.sm, marginRight: Spacing.sm,
    marginBottom: Spacing.sm, zIndex: 50,
  },
  mdBadge: {
    backgroundColor: Colors.accent + '18', borderRadius: 3,
    paddingHorizontal: 3, paddingVertical: 1,
    borderWidth: 1, borderColor: Colors.accent + '33',
  },
  mdBadgeText: { color: Colors.accent, fontSize: 7, fontWeight: '800' },

  emptyFiles: {
    paddingVertical: Spacing.xl, paddingHorizontal: Spacing.sm,
    alignItems: 'center', gap: 6,
  },
  emptyFilesText: { color: Colors.textMuted, fontSize: Typography.sizes.xs, textAlign: 'center' },
  emptyFilesHint: { color: Colors.textMuted, fontSize: 10, textAlign: 'center', fontStyle: 'italic' },
  createFirstBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: Colors.accentGlow, borderRadius: Radius.sm,
    paddingHorizontal: Spacing.sm, paddingVertical: 6,
    borderWidth: 1, borderColor: Colors.accent + '44',
    marginTop: 4,
  },
  createFirstBtnText: { color: Colors.accent, fontSize: Typography.sizes.xs, fontWeight: '600' },
});
