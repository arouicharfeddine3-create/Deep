import React, { useState, useCallback, useEffect } from 'react';
import {
  View, Text, ScrollView, Pressable, StyleSheet, TextInput,
  Platform,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, Radius } from '@/constants/theme';
import { useProjects } from '@/hooks/useProjects';

// Basic syntax coloring tokens
const KEYWORDS: Record<string, string[]> = {
  js: ['const', 'let', 'var', 'function', 'return', 'if', 'else', 'for', 'while', 'import', 'export', 'default', 'class', 'new', 'async', 'await', 'try', 'catch', 'typeof', 'null', 'undefined', 'true', 'false'],
  ts: ['const', 'let', 'var', 'function', 'return', 'if', 'else', 'for', 'while', 'import', 'export', 'default', 'class', 'new', 'async', 'await', 'try', 'catch', 'interface', 'type', 'extends', 'implements', 'public', 'private', 'readonly'],
  py: ['def', 'class', 'return', 'if', 'else', 'elif', 'for', 'while', 'import', 'from', 'as', 'in', 'not', 'and', 'or', 'True', 'False', 'None', 'with', 'try', 'except', 'lambda', 'yield'],
  go: ['func', 'var', 'const', 'if', 'else', 'for', 'return', 'package', 'import', 'struct', 'interface', 'go', 'chan', 'nil', 'true', 'false'],
};

function getKeywords(language: string): string[] {
  const lang = language?.toLowerCase();
  if (lang === 'typescript' || lang === 'tsx') return KEYWORDS.ts;
  if (lang === 'javascript' || lang === 'jsx') return KEYWORDS.js;
  if (lang === 'python') return KEYWORDS.py;
  if (lang === 'go') return KEYWORDS.go;
  return KEYWORDS.js;
}

// Simple line-based syntax highlighter
function SyntaxLine({ line, keywords }: { line: string; keywords: string[] }) {
  const parts: { text: string; type: 'keyword' | 'string' | 'comment' | 'number' | 'plain' }[] = [];

  // Comment line
  if (line.trimStart().startsWith('//') || line.trimStart().startsWith('#')) {
    return <Text style={synStyles.comment}>{line}</Text>;
  }

  // Tokenize
  let remaining = line;
  while (remaining.length > 0) {
    // String
    const strMatch = remaining.match(/^(['"`])(.*?)\1/);
    if (strMatch) {
      parts.push({ text: strMatch[0], type: 'string' });
      remaining = remaining.slice(strMatch[0].length);
      continue;
    }
    // Number
    const numMatch = remaining.match(/^\b\d+(\.\d+)?\b/);
    if (numMatch) {
      parts.push({ text: numMatch[0], type: 'number' });
      remaining = remaining.slice(numMatch[0].length);
      continue;
    }
    // Keyword
    const wordMatch = remaining.match(/^[A-Za-z_][A-Za-z0-9_]*/);
    if (wordMatch) {
      const word = wordMatch[0];
      parts.push({ text: word, type: keywords.includes(word) ? 'keyword' : 'plain' });
      remaining = remaining.slice(word.length);
      continue;
    }
    // Other char
    parts.push({ text: remaining[0], type: 'plain' });
    remaining = remaining.slice(1);
  }

  return (
    <Text>
      {parts.map((p, i) => (
        <Text key={i} style={[synStyles.base, synStyles[p.type]]}>{p.text}</Text>
      ))}
    </Text>
  );
}

const synStyles = StyleSheet.create({
  base: { fontFamily: 'monospace', fontSize: 12, lineHeight: 20 },
  keyword: { color: '#ff7b72' },
  string: { color: '#a5d6ff' },
  comment: { color: '#8b949e', fontFamily: 'monospace', fontSize: 12, lineHeight: 20, fontStyle: 'italic' },
  number: { color: '#79c0ff' },
  plain: { color: '#e6edf3' },
});

export function CodeEditor() {
  const { activeFile, activeProject, updateFileContent } = useProjects();
  const [content, setContent] = useState('');
  const [isDirty, setIsDirty] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [viewMode, setViewMode] = useState<'editor' | 'highlighted'>('editor');
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (activeFile) {
      setContent(activeFile.content);
      setIsDirty(false);
      setIsEditing(false);
      setSaved(false);
    }
  }, [activeFile]);

  const handleChange = useCallback((text: string) => {
    setContent(text);
    setIsDirty(text !== activeFile?.content);
    setSaved(false);
  }, [activeFile]);

  const handleSave = useCallback(async () => {
    if (!activeFile || !activeProject) return;
    await updateFileContent(activeProject.id, activeFile.id, content);
    setIsDirty(false);
    setIsEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }, [activeFile, activeProject, content, updateFileContent]);

  if (!activeFile) {
    return (
      <View style={styles.empty}>
        <View style={styles.emptyIconWrap}>
          <MaterialIcons name="code" size={42} color={Colors.accent} />
        </View>
        <Text style={styles.emptyTitle}>محرر الكود</Text>
        <Text style={styles.emptyHint}>اختر ملفاً من المستكشف أو استخرج كوداً من DeepSeek</Text>
        <View style={styles.emptyTips}>
          {[
            { icon: 'auto-fix-high' as const, text: 'فعّل المود التلقائي من تبويب بيئة العمل' },
            { icon: 'bolt' as const, text: 'سيحفظ التطبيق الكود تلقائياً بمجرد رده' },
            { icon: 'folder-open' as const, text: 'تأكد من اختيار مشروع نشط أولاً' },
          ].map((tip, i) => (
            <View key={i} style={styles.tipRow}>
              <MaterialIcons name={tip.icon} size={14} color={Colors.accent} />
              <Text style={styles.tipText}>{tip.text}</Text>
            </View>
          ))}
        </View>
      </View>
    );
  }

  const ext = activeFile.name.split('.').pop()?.toLowerCase() || '';
  const keywords = getKeywords(activeFile.language || ext);
  const lines = content.split('\n');
  const lineCount = lines.length;

  return (
    <View style={styles.container}>
      {/* Tab bar */}
      <View style={styles.tabBar}>
        <View style={styles.tab}>
          <MaterialIcons name="insert-drive-file" size={13} color={Colors.accent} />
          <Text style={styles.tabName}>{activeFile.name}</Text>
          {isDirty ? <View style={styles.dirtyDot} /> : null}
          {saved ? <MaterialIcons name="check" size={12} color={Colors.green} /> : null}
        </View>
        <View style={styles.tabActions}>
          {/* View mode toggle */}
          <Pressable
            onPress={() => setViewMode(viewMode === 'editor' ? 'highlighted' : 'editor')}
            hitSlop={8}
            style={({ pressed }) => [
              styles.actionBtn,
              viewMode === 'highlighted' && styles.actionBtnActive,
              pressed && { opacity: 0.7 },
            ]}
          >
            <MaterialIcons
              name="palette"
              size={15}
              color={viewMode === 'highlighted' ? Colors.accent : Colors.textSecondary}
            />
          </Pressable>

          {isDirty ? (
            <Pressable onPress={handleSave} style={({ pressed }) => [styles.actionBtn, styles.saveBtn, pressed && { opacity: 0.7 }]}>
              <MaterialIcons name="save" size={13} color="#fff" />
              <Text style={styles.saveBtnText}>حفظ</Text>
            </Pressable>
          ) : null}
          <Pressable
            onPress={() => setIsEditing(!isEditing)}
            style={({ pressed }) => [styles.actionBtn, isEditing && styles.actionBtnActive, pressed && { opacity: 0.7 }]}
          >
            <MaterialIcons name={isEditing ? 'lock-open' : 'edit'} size={15} color={isEditing ? Colors.accent : Colors.textSecondary} />
          </Pressable>
        </View>
      </View>

      {/* Code area */}
      {viewMode === 'highlighted' ? (
        <ScrollView style={styles.codeScroll} showsVerticalScrollIndicator={false}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.codeContainer}>
              {/* Line numbers */}
              <View style={styles.lineNumbers}>
                {lines.map((_, i) => (
                  <Text key={i} style={styles.lineNum}>{i + 1}</Text>
                ))}
              </View>
              {/* Highlighted code */}
              <View style={styles.highlightedCode}>
                {lines.map((line, i) => (
                  <View key={i} style={styles.codeLine}>
                    <SyntaxLine line={line || ' '} keywords={keywords} />
                  </View>
                ))}
              </View>
            </View>
          </ScrollView>
        </ScrollView>
      ) : (
        <ScrollView style={styles.codeScroll} horizontal showsHorizontalScrollIndicator={false}>
          <View style={styles.codeContainer}>
            {/* Line numbers */}
            <View style={styles.lineNumbers}>
              {lines.map((_, i) => (
                <Text key={i} style={styles.lineNum}>{i + 1}</Text>
              ))}
            </View>
            {/* Raw editor */}
            <TextInput
              style={styles.codeInput}
              value={content}
              onChangeText={handleChange}
              multiline
              editable={isEditing}
              scrollEnabled={false}
              autoCapitalize="none"
              autoCorrect={false}
              spellCheck={false}
              textAlignVertical="top"
              placeholder="// الكود سيظهر هنا..."
              placeholderTextColor={Colors.textMuted}
              selectionColor={Colors.primary + '88'}
            />
          </View>
        </ScrollView>
      )}

      {/* Status bar */}
      <View style={styles.statusBar}>
        <View style={styles.statusLeft}>
          <View style={styles.statusLang}>
            <Text style={styles.statusLangText}>{(activeFile.language || ext).toUpperCase()}</Text>
          </View>
          <Text style={styles.statusText}>{lineCount} سطر</Text>
          <Text style={styles.statusText}>{content.length} حرف</Text>
        </View>
        <View style={styles.statusRight}>
          {isDirty ? (
            <View style={styles.statusChip}>
              <View style={[styles.statusDot, { backgroundColor: Colors.yellow }]} />
              <Text style={[styles.statusChipText, { color: Colors.yellow }]}>تعديلات</Text>
            </View>
          ) : null}
          <View style={styles.statusChip}>
            <View style={[styles.statusDot, { backgroundColor: isEditing ? Colors.green : Colors.textMuted }]} />
            <Text style={[styles.statusChipText, { color: isEditing ? Colors.green : Colors.textMuted }]}>
              {isEditing ? 'تحرير' : 'قراءة'}
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },

  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 14, padding: Spacing.xxl },
  emptyIconWrap: {
    width: 80, height: 80, borderRadius: 20,
    backgroundColor: Colors.accentGlow,
    alignItems: 'center', justifyContent: 'center',
  },
  emptyTitle: { color: Colors.textSecondary, fontSize: Typography.sizes.lg, fontWeight: '600' },
  emptyHint: { color: Colors.textMuted, fontSize: Typography.sizes.base, textAlign: 'center', lineHeight: 22 },
  emptyTips: { gap: 8, alignSelf: 'stretch', marginTop: Spacing.sm },
  tipRow: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: Colors.bgSecondary, borderRadius: Radius.md,
    padding: Spacing.sm, borderWidth: 1, borderColor: Colors.borderSubtle,
  },
  tipText: { color: Colors.textSecondary, fontSize: Typography.sizes.sm, flex: 1 },

  tabBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: Colors.bgSecondary, borderBottomWidth: 1, borderBottomColor: Colors.borderSubtle,
    paddingHorizontal: Spacing.sm, height: 36,
  },
  tab: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  tabName: { color: Colors.textPrimary, fontSize: Typography.sizes.sm, fontFamily: 'monospace' },
  dirtyDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.yellow },
  tabActions: { flexDirection: 'row', gap: 4, alignItems: 'center' },
  actionBtn: { width: 28, height: 28, alignItems: 'center', justifyContent: 'center', borderRadius: 4 },
  actionBtnActive: { backgroundColor: Colors.accentGlow },
  saveBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: Colors.green, borderRadius: Radius.sm,
    paddingHorizontal: 8, height: 24, width: 'auto',
  },
  saveBtnText: { color: '#fff', fontSize: Typography.sizes.xs, fontWeight: '600' },

  codeScroll: { flex: 1 },
  codeContainer: { flexDirection: 'row', minWidth: '100%' },
  lineNumbers: {
    paddingHorizontal: Spacing.sm, paddingTop: Spacing.sm,
    backgroundColor: Colors.bgSecondary, borderRightWidth: 1, borderRightColor: Colors.borderSubtle,
    minWidth: 40, alignItems: 'flex-end',
  },
  lineNum: { color: Colors.textMuted, fontSize: 11, lineHeight: 20, fontFamily: 'monospace' },
  highlightedCode: { padding: Spacing.sm, flex: 1 },
  codeLine: { minHeight: 20 },
  codeInput: {
    flex: 1, padding: Spacing.sm,
    color: Colors.textPrimary, fontSize: 12,
    fontFamily: 'monospace', lineHeight: 20, minHeight: 400,
  },

  statusBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: Colors.bgSecondary,
    paddingHorizontal: Spacing.sm, paddingVertical: 4,
    borderTopWidth: 1, borderTopColor: Colors.borderSubtle,
  },
  statusLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  statusRight: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  statusLang: {
    backgroundColor: Colors.primary + '33', borderRadius: 3,
    paddingHorizontal: 5, paddingVertical: 1,
  },
  statusLangText: { color: Colors.accent, fontSize: 10, fontWeight: '600', fontFamily: 'monospace' },
  statusText: { color: Colors.textMuted, fontSize: 10, fontFamily: 'monospace' },
  statusChip: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  statusDot: { width: 5, height: 5, borderRadius: 2.5 },
  statusChipText: { fontSize: 10, fontFamily: 'monospace' },
});
