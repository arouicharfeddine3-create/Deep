import React from 'react';
import { Pressable, Text, StyleSheet, ActivityIndicator, View } from 'react-native';
import { Colors, Typography, Spacing, Radius } from '@/constants/theme';

interface ButtonProps {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  disabled?: boolean;
  icon?: React.ReactNode;
  fullWidth?: boolean;
}

export function Button({ label, onPress, variant = 'primary', size = 'md', loading, disabled, icon, fullWidth }: ButtonProps) {
  const isDisabled = disabled || loading;

  return (
    <Pressable
      onPress={onPress}
      disabled={isDisabled}
      style={({ pressed }) => [
        styles.base,
        styles[variant],
        styles[size],
        fullWidth && styles.fullWidth,
        pressed && styles.pressed,
        isDisabled && styles.disabled,
      ]}
    >
      {loading ? (
        <ActivityIndicator size="small" color={variant === 'primary' ? '#fff' : Colors.primary} />
      ) : (
        <View style={styles.row}>
          {icon ? <View style={styles.iconWrap}>{icon}</View> : null}
          <Text style={[styles.label, styles[`label_${variant}`], styles[`label_${size}`]]}>{label}</Text>
        </View>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    borderRadius: Radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  row: { flexDirection: 'row', alignItems: 'center' },
  iconWrap: { marginRight: 6 },

  // Variants
  primary: { backgroundColor: Colors.primary },
  secondary: { backgroundColor: Colors.bgTertiary, borderWidth: 1, borderColor: Colors.border },
  ghost: { backgroundColor: 'transparent' },
  danger: { backgroundColor: Colors.error + '22', borderWidth: 1, borderColor: Colors.error + '55' },

  // Sizes
  sm: { paddingHorizontal: Spacing.sm, paddingVertical: 5, minHeight: 30 },
  md: { paddingHorizontal: Spacing.base, paddingVertical: 9, minHeight: 38 },
  lg: { paddingHorizontal: Spacing.xl, paddingVertical: 13, minHeight: 48 },

  // Labels
  label: { fontWeight: Typography.weights.semibold },
  label_primary: { color: '#fff' },
  label_secondary: { color: Colors.textPrimary },
  label_ghost: { color: Colors.accent },
  label_danger: { color: Colors.error },
  label_sm: { fontSize: Typography.sizes.sm },
  label_md: { fontSize: Typography.sizes.base },
  label_lg: { fontSize: Typography.sizes.md },

  fullWidth: { width: '100%' },
  pressed: { opacity: 0.75 },
  disabled: { opacity: 0.45 },
});
