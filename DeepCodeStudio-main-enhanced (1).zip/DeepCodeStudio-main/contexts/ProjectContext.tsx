import React, { createContext, useState, useEffect, useCallback, ReactNode, useRef } from 'react';
import { projectService, Project, ProjectFile } from '@/services/projectService';
import { AutoModeLog } from '@/services/autoModeService';

interface ProjectContextType {
  projects: Project[];
  activeProject: Project | null;
  activeFile: ProjectFile | null;
  loading: boolean;
  // Auto mode
  autoMode: boolean;
  setAutoMode: (enabled: boolean) => void;
  autoLogs: AutoModeLog[];
  addAutoLog: (log: AutoModeLog) => void;
  clearLogs: () => void;
  autoSavedCount: number;
  incrementAutoSaved: (n: number) => void;
  // Project actions
  setActiveProject: (project: Project | null) => void;
  setActiveFile: (file: ProjectFile | null) => void;
  createProject: (name: string, description?: string) => Promise<Project>;
  deleteProject: (id: string) => Promise<void>;
  addFileToProject: (projectId: string, file: Omit<ProjectFile, 'id' | 'createdAt' | 'updatedAt'>) => Promise<ProjectFile>;
  updateFileContent: (projectId: string, fileId: string, content: string) => Promise<void>;
  deleteFile: (projectId: string, fileId: string) => Promise<void>;
  refreshProjects: () => Promise<void>;
  importProject: (json: string) => Promise<Project>;
}

export const ProjectContext = createContext<ProjectContextType | undefined>(undefined);

export function ProjectProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProject, setActiveProjectState] = useState<Project | null>(null);
  const [activeFile, setActiveFile] = useState<ProjectFile | null>(null);
  const [loading, setLoading] = useState(true);

  // Auto mode state
  const [autoMode, setAutoModeState] = useState(false);
  const [autoLogs, setAutoLogs] = useState<AutoModeLog[]>([]);
  const [autoSavedCount, setAutoSavedCount] = useState(0);

  const setAutoMode = useCallback((enabled: boolean) => {
    setAutoModeState(enabled);
  }, []);

  const addAutoLog = useCallback((log: AutoModeLog) => {
    setAutoLogs(prev => [log, ...prev].slice(0, 100)); // Keep last 100 logs
  }, []);

  const clearLogs = useCallback(() => setAutoLogs([]), []);

  const incrementAutoSaved = useCallback((n: number) => {
    setAutoSavedCount(prev => prev + n);
  }, []);

  const refreshProjects = useCallback(async () => {
    const data = await projectService.getAll();
    setProjects(data);
    setActiveProjectState(prev => {
      if (!prev) return null;
      const updated = data.find(p => p.id === prev.id);
      return updated || null;
    });
  }, []);

  useEffect(() => {
    refreshProjects().finally(() => setLoading(false));
  }, []);

  const setActiveProject = useCallback((project: Project | null) => {
    setActiveProjectState(project);
    setActiveFile(null);
  }, []);

  const createProject = useCallback(async (name: string, description = '') => {
    const project = await projectService.create(name, description);
    await refreshProjects();
    return project;
  }, [refreshProjects]);

  const deleteProject = useCallback(async (id: string) => {
    await projectService.delete(id);
    if (activeProject?.id === id) setActiveProject(null);
    await refreshProjects();
  }, [activeProject, refreshProjects, setActiveProject]);

  const addFileToProject = useCallback(async (projectId: string, file: Omit<ProjectFile, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newFile = await projectService.addFile(projectId, file);
    await refreshProjects();
    return newFile;
  }, [refreshProjects]);

  const updateFileContent = useCallback(async (projectId: string, fileId: string, content: string) => {
    await projectService.updateFile(projectId, fileId, content);
    setActiveFile(prev => (prev?.id === fileId ? { ...prev, content, updatedAt: new Date().toISOString() } : prev));
    await refreshProjects();
  }, [refreshProjects]);

  const deleteFile = useCallback(async (projectId: string, fileId: string) => {
    await projectService.deleteFile(projectId, fileId);
    setActiveFile(prev => (prev?.id === fileId ? null : prev));
    await refreshProjects();
  }, [refreshProjects]);

  const importProject = useCallback(async (json: string) => {
    const project = await projectService.importProject(json);
    await refreshProjects();
    return project;
  }, [refreshProjects]);

  return (
    <ProjectContext.Provider value={{
      projects,
      activeProject,
      activeFile,
      loading,
      autoMode,
      setAutoMode,
      autoLogs,
      addAutoLog,
      clearLogs,
      autoSavedCount,
      incrementAutoSaved,
      setActiveProject,
      setActiveFile,
      createProject,
      deleteProject,
      addFileToProject,
      updateFileContent,
      deleteFile,
      refreshProjects,
      importProject,
    }}>
      {children}
    </ProjectContext.Provider>
  );
}
